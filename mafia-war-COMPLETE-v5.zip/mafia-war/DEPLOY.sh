#!/bin/bash
# ================================================================
# MAFIA WAR v5.0 — FINAL PRODUCTION DEPLOYMENT
# © 2026 Aussi-Nexus Group (ABN 76 947 108 181)
# Domain: mafia.nexusonlinegames.com | Port: 3110
# Phases 1–5 complete
# ================================================================
set -e

APP_DIR="/var/www/mafia-war"
PORT=3110
PM2_NAME="mafia-war"
DOMAIN="mafia.nexusonlinegames.com"
DB_USER="mafia_war_user"
DB_NAME="mafia_war"
DB_PASS="MafiaWar2026Secure!"

echo ""
echo "🔫 MAFIA WAR v5.0 — FINAL DEPLOYMENT"
echo "======================================="

# ── 1. DIRECTORIES ───────────────────────────────────────────
echo "[1/9] Preparing directories..."
mkdir -p "$APP_DIR/backend/src"
mkdir -p "$APP_DIR/backend/logs"
mkdir -p "$APP_DIR/frontend/dist"

# ── 2. UPLOAD REMINDER ───────────────────────────────────────
echo ""
echo "[2/9] Upload files via FileZilla before continuing."
echo "   backend/        → $APP_DIR/backend/"
echo "   frontend/dist/  → $APP_DIR/frontend/dist/"
echo ""
echo "Press ENTER when done..."
read -r

# ── 3. BACKEND DEPS ──────────────────────────────────────────
echo "[3/9] Installing backend dependencies..."
cd "$APP_DIR/backend"
npm install --production
echo "Dependencies installed."

# ── 4. DATABASE ──────────────────────────────────────────────
echo "[4/9] Setting up MySQL database..."
echo -n "MySQL root password: "
read -rs MYSQL_ROOT_PASS
echo ""

mysql -u root -p"$MYSQL_ROOT_PASS" << SQLEOF
CREATE DATABASE IF NOT EXISTS $DB_NAME CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_NAME.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;
SQLEOF

mysql -u root -p"$MYSQL_ROOT_PASS" "$DB_NAME" < "$APP_DIR/backend/src/db/schema.sql"
echo "Database ready."

# ── 5. ENV ────────────────────────────────────────────────────
if [ ! -f "$APP_DIR/backend/.env" ]; then
  echo "[5/9] Creating .env..."
  echo -n "Stripe Secret Key: "; read -rs SK; echo ""
  echo -n "Stripe Webhook Secret: "; read -rs WH; echo ""
  echo -n "Stripe Premium Price ID: "; read -rs PRICE; echo ""

  JWT=$(openssl rand -hex 32)
  cat > "$APP_DIR/backend/.env" << ENVEOF
PORT=$PORT
NODE_ENV=production
DB_HOST=localhost
DB_PORT=3306
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASS=$DB_PASS
JWT_SECRET=$JWT
STRIPE_SECRET_KEY=$SK
STRIPE_WEBHOOK_SECRET=$WH
STRIPE_PREMIUM_PRICE_ID=$PRICE
FRONTEND_URL=https://$DOMAIN
ADMIN_EMAIL=admin@nexusonlinegames.com
ENVEOF
  echo ".env created."
else
  echo "[5/9] .env exists — skipping."
fi

# ── 6. PM2 ───────────────────────────────────────────────────
echo "[6/9] Starting with PM2..."
pm2 delete "$PM2_NAME" 2>/dev/null || true
pm2 start "$APP_DIR/backend/src/server.js" \
  --name "$PM2_NAME" \
  --env production \
  --max-memory-restart 512M \
  --restart-delay 3000
pm2 save
echo "PM2 started on port $PORT."

# ── 7. NGINX ─────────────────────────────────────────────────
echo "[7/9] Configuring Nginx..."
cat > "/etc/nginx/sites-available/$DOMAIN" << 'NGINXEOF'
server {
    listen 80;
    server_name mafia.nexusonlinegames.com www.mafia.nexusonlinegames.com;

    location /socket.io/ {
        proxy_pass http://127.0.0.1:3110;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400s;
    }

    location /api/payment/webhook {
        proxy_pass http://127.0.0.1:3110;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 30s;
    }

    location / {
        proxy_pass http://127.0.0.1:3110;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        client_max_body_size 2M;
        gzip on;
        gzip_types text/plain text/css application/json application/javascript;
    }
}
NGINXEOF

ln -sf "/etc/nginx/sites-available/$DOMAIN" "/etc/nginx/sites-enabled/$DOMAIN"
nginx -t && systemctl reload nginx
echo "Nginx configured."

# ── 8. SSL ───────────────────────────────────────────────────
echo "[8/9] SSL..."
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
  -m "admin@nexusonlinegames.com" --redirect 2>/dev/null && echo "SSL OK." || echo "Run certbot manually."

# ── 9. CRON ──────────────────────────────────────────────────
echo "[9/9] Cron jobs..."
# Weekly reset: Monday 2am AEST (Sunday 4pm UTC)
CRON_WEEKLY="0 16 * * 0 curl -s -X POST https://$DOMAIN/api/season-admin/weekly-reset -H 'x-owner-bypass: manas724' >> /var/log/mafia-war-cron.log 2>&1"
# Achievement check: hourly
CRON_ACHIEV="0 * * * * curl -s https://$DOMAIN/api/health >> /dev/null 2>&1"
(crontab -l 2>/dev/null | grep -v 'mafia-war'; echo "$CRON_WEEKLY"; echo "$CRON_ACHIEV") | crontab -
echo "Cron configured."

echo ""
echo "✅ ══════════════════════════════════════════"
echo "   MAFIA WAR v5.0 — DEPLOYED"
echo "   URL:          https://$DOMAIN"
echo "   Health:       https://$DOMAIN/api/health"
echo "   Admin:        https://$DOMAIN/admin"
echo "   Analytics:    https://$DOMAIN/analytics"
echo "   PM2 status:   pm2 status"
echo "   Logs:         pm2 logs mafia-war"
echo "══════════════════════════════════════════════"
echo ""
echo "POST-DEPLOY CHECKLIST:"
echo "  1. Register at /register"
echo "  2. Run in MySQL:"
echo "     UPDATE users SET role='owner' WHERE email='your@email.com';"
echo "  3. Visit /admin → Health tab → verify all green"
echo "  4. Visit /admin → Season tab → confirm Season 1 active"
echo "  5. Set Stripe webhook: https://$DOMAIN/api/payment/webhook"
echo "  6. Test age gate, registration, first kill, heist"
echo "  7. Upload 192x512 icons to $APP_DIR/frontend/dist/ for PWA"
echo ""
