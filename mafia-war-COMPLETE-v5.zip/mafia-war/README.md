# 🔫 MAFIA WAR
### Full-Stack Multiplayer Crime Game
**© 2026 Aussi-Nexus Group (ABN 76 947 108 181)**

---

## Phase 1 Complete ✅

This is Phase 1 of the Mafia War game build. Everything below is fully built and functional.

---

## What's Built

### Backend (`/backend`)
- `src/server.js` — Express + Socket.io server (port 3110)
- `src/db/schema.sql` — Full MySQL schema (12 tables)
- `src/db/pool.js` — MySQL connection pool
- `src/middleware/auth.js` — JWT auth (bcryptjs + jose), owner bypass
- `src/routes/auth.js` — Register, login, refresh, logout
- `src/routes/player.js` — Profile, stats, leaderboard, faction, weapons, maps
- `src/routes/game.js` — Room CRUD, maps, ranks
- `src/routes/payment.js` — Stripe subscription + in-game cash + webhook
- `src/routes/admin.js` — Ban/unban, stats, reports, promote
- `src/socket/gameEngine.js` — Full real-time game engine

### Frontend (`/frontend`)
- Age gate (18+ DOB verification — exits to Google if underage)
- Register / Login pages with age confirmation checkbox
- Game Lobby (room list, create room, leaderboard, profile)
- Faction chooser (Ghost/Viper/Iron/Shadow)
- **Playable game canvas** (WASD movement, mouse aim, click to shoot)
- Real-time multiplayer (Socket.io)
- Kill feed, particle effects, bullet rendering, respawn system
- Chat system (room/faction channels)
- Admin dashboard (users, bans, reports, stats)
- Payment success/cancel pages
- Legal/Terms page

### Database Tables
users, sessions, game_rooms, match_history, heist_missions,
heist_participants, weapons_inventory, leaderboard, payments,
player_reports, chat_log, rank_definitions (15 ranks), map_definitions (12 maps)

### Game Features Built
- 12 maps (downtown, chinatown, harbour, casino, penthouse, suburbs, underground, warehouse, federal_bank, casino_vault, armoured_car, city_hall)
- 15 player ranks (Street Rat → Godfather)
- 4 factions (Ghost, Viper, Iron, Shadow)
- 12 weapons (pistol, SMG, shotgun, rifle, sniper, explosive, special)
- 4 game modes (deathmatch, team, heist, territory)
- XP + cash system, rank-up on match end
- Kill streaks, respawn timers
- Rate-limited shooting (per weapon fire rate)
- Stripe subscription (premium) + in-game cash packs
- Owner bypass (x-owner-bypass: manas724 header)

---

## Deployment

### Step 1 — Build Frontend Locally
```bash
cd frontend
npm install
npm run build
# dist/ folder is created — upload to VPS
```

### Step 2 — Upload via FileZilla
- `backend/` → `/var/www/mafia-war/backend/`
- `frontend/dist/` → `/var/www/mafia-war/frontend/dist/`

### Step 3 — Run Deploy Script on VPS
```bash
chmod +x DEPLOY.sh
./DEPLOY.sh
```

### Manual PuTTY Commands (if not using deploy script)
```bash
# Database
mysql -u root -p -e "CREATE DATABASE mafia_war; CREATE USER 'mafia_war_user'@'localhost' IDENTIFIED BY 'MafiaWar2026!Secure'; GRANT ALL ON mafia_war.* TO 'mafia_war_user'@'localhost';"
mysql -u root -p mafia_war < /var/www/mafia-war/backend/src/db/schema.sql

# Backend deps
cd /var/www/mafia-war/backend && npm install --production

# PM2
pm2 start /var/www/mafia-war/backend/src/server.js --name mafia-war
pm2 save

# Health check
curl http://localhost:3110/api/health
```

---

## Environment Variables (`.env`)
Copy `.env.example` to `.env` and fill in:
- `DB_PASS` — your MySQL password
- `JWT_SECRET` — random 32+ char string
- `STRIPE_SECRET_KEY` — from Stripe dashboard
- `STRIPE_WEBHOOK_SECRET` — from Stripe webhook settings
- `STRIPE_PREMIUM_PRICE_ID` — create a recurring price in Stripe

---

## What's Next (Phase 2)
- Enhanced game canvas (Phaser.js renderer with real sprites)
- Heist mission full implementation
- Territory control timer loop
- Weapon shop in lobby
- Faction leaderboard per week/month
- Voice chat (optional)

---

## Domain
- Marketing site: `nexusonlinegames.com` (landing page — static)
- Game app: `mafia.nexusonlinegames.com` (this app — port 3110)

---

*Mafia War is a work of fiction. Strictly 18+. © 2026 Aussi-Nexus Group.*
