const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:            process.env.DB_HOST || 'localhost',
  port:            parseInt(process.env.DB_PORT) || 3306,
  database:        process.env.DB_NAME || 'mafia_war',
  user:            process.env.DB_USER,
  password:        process.env.DB_PASS,
  waitForConnections: true,
  connectionLimit:    20,
  queueLimit:         0,
  enableKeepAlive:    true,
  keepAliveInitialDelay: 0,
});

pool.on && pool.on('error', (err) => {
  console.error('[DB] Pool error:', err.message);
});

async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

module.exports = { pool, query, queryOne };
