const { SignJWT, jwtVerify } = require('jose');
const { query, queryOne } = require('../db/pool');

const SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'mafia-war-secret-change-in-production');
const ACCESS_TTL  = '15m';
const REFRESH_TTL = '7d';

async function signAccess(payload) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(ACCESS_TTL)
    .sign(SECRET);
}

async function signRefresh(payload) {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(REFRESH_TTL)
    .sign(SECRET);
}

async function verifyToken(token) {
  const { payload } = await jwtVerify(token, SECRET);
  return payload;
}

// Middleware: require valid access token
async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = header.slice(7);
    const payload = await verifyToken(token);
    
    // Fetch fresh user data
    const user = await queryOne(
      'SELECT id, uuid, username, email, role, faction, rank_level, xp, kills, deaths, cash, is_banned, subscription_status FROM users WHERE id = ?',
      [payload.sub]
    );
    if (!user) return res.status(401).json({ error: 'User not found' });
    if (user.is_banned) return res.status(403).json({ error: 'Account suspended' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Middleware: require admin or owner
async function requireAdmin(req, res, next) {
  await requireAuth(req, res, () => {
    if (!['admin', 'owner'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    next();
  });
}

// Middleware: require premium or admin
async function requirePremium(req, res, next) {
  await requireAuth(req, res, () => {
    if (!['premium', 'admin', 'owner'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Premium subscription required' });
    }
    next();
  });
}

// Owner bypass: faded purple dot, password manas724
async function ownerBypass(req, res, next) {
  const bypassPw = req.headers['x-owner-bypass'];
  if (bypassPw === 'manas724') {
    req.user = { id: 1, uuid: 'owner', username: 'owner', role: 'owner', is_banned: 0 };
    return next();
  }
  next();
}

module.exports = { signAccess, signRefresh, verifyToken, requireAuth, requireAdmin, requirePremium, ownerBypass };
