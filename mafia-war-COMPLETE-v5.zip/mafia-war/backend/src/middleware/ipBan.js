const { queryOne, query } = require('../db/pool');

// Cache bans in memory for 60s to avoid DB hit every request
const banCache   = new Map(); // ip → { banned, expires }
const CACHE_TTL  = 60 * 1000;

async function ipBanMiddleware(req, res, next) {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const now = Date.now();

  // Check memory cache first
  const cached = banCache.get(ip);
  if (cached && now - cached.ts < CACHE_TTL) {
    if (cached.banned) return res.status(403).json({ error: 'Your IP address has been banned.' });
    return next();
  }

  // Check DB
  try {
    const ban = await queryOne(
      "SELECT id, expires_at FROM ip_bans WHERE ip_address = ? AND (expires_at IS NULL OR expires_at > NOW())",
      [ip]
    );
    const banned = !!ban;
    banCache.set(ip, { banned, ts: now });
    if (banned) return res.status(403).json({ error: 'Your IP address has been banned.' });
  } catch {
    // If DB fails, allow through (don't block legitimate players on DB error)
  }
  next();
}

// Clear cache entry so next request re-checks DB (called after admin bans/unbans)
function invalidateBanCache(ip) {
  banCache.delete(ip);
}

module.exports = { ipBanMiddleware, invalidateBanCache };
