const { query } = require('../db/pool');

const SLOW_THRESHOLD_MS = 2000; // log requests slower than 2s
const ERROR_LOG_ROUTES  = ['/api/']; // only log API routes

function requestLogger(req, res, next) {
  const start = Date.now();
  const ip    = req.ip || req.connection?.remoteAddress || 'unknown';

  res.on('finish', async () => {
    const duration = Date.now() - start;
    const status   = res.statusCode;
    const path     = req.path?.substring(0, 255);
    const userId   = req.user?.id || null;

    // Only log errors (4xx/5xx) and slow requests
    const shouldLog = status >= 400 || duration >= SLOW_THRESHOLD_MS;
    const isApiRoute= ERROR_LOG_ROUTES.some(r => req.path.startsWith(r));

    if (shouldLog && isApiRoute) {
      query(
        'INSERT INTO request_log (method, path, status, duration_ms, ip, user_id) VALUES (?,?,?,?,?,?)',
        [req.method, path, status, duration, ip, userId]
      ).catch(() => {});
    }
  });

  next();
}

async function logError(level, message, { stack, route, userId, ip } = {}) {
  try {
    await query(
      'INSERT INTO error_log (level, message, stack, route, user_id, ip) VALUES (?,?,?,?,?,?)',
      [level, String(message).substring(0, 500), stack?.substring(0, 2000), route, userId || null, ip || null]
    );
  } catch { /* silent — can't log logger errors */ }
}

module.exports = { requestLogger, logError };
