const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// ── ACHIEVEMENTS ───────────────────────────────────────────────

// GET /api/achievements — all achievements with player unlock status
router.get('/', requireAuth, async (req, res) => {
  try {
    const all     = await query('SELECT * FROM achievements ORDER BY category, rarity DESC');
    const unlocked = await query('SELECT achievement_id, unlocked_at FROM player_achievements WHERE user_id = ?', [req.user.id]);
    const progress = await query('SELECT achievement_id, current_value FROM achievement_progress WHERE user_id = ?', [req.user.id]);

    const unlockedSet  = new Map(unlocked.map(u => [u.achievement_id, u.unlocked_at]));
    const progressMap  = new Map(progress.map(p => [p.achievement_id, p.current_value]));

    res.json({
      achievements: all.map(a => ({
        ...a,
        unlocked:      unlockedSet.has(a.achievement_id),
        unlocked_at:   unlockedSet.get(a.achievement_id) || null,
        current_value: progressMap.get(a.achievement_id) || 0,
        pct:           Math.min(100, Math.round(((progressMap.get(a.achievement_id) || 0) / a.condition_value) * 100)),
      })),
      total:    all.length,
      unlocked: unlockedSet.size,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load achievements.' });
  }
});

// POST /api/achievements/check — trigger achievement check for current user
router.post('/check', requireAuth, async (req, res) => {
  try {
    const newlyUnlocked = await checkAchievements(req.user.id);
    res.json({ newly_unlocked: newlyUnlocked });
  } catch (err) {
    res.status(500).json({ error: 'Failed to check achievements.' });
  }
});

// GET /api/achievements/notifications — pending unlock notifications
router.get('/notifications', requireAuth, async (req, res) => {
  try {
    const notifs = await query(
      `SELECT pa.achievement_id, pa.unlocked_at, a.name, a.icon, a.rarity, a.reward_cash, a.reward_xp
       FROM player_achievements pa JOIN achievements a ON a.achievement_id = pa.achievement_id
       WHERE pa.user_id = ? AND pa.notified = 0`,
      [req.user.id]
    );
    if (notifs.length > 0) {
      await query('UPDATE player_achievements SET notified=1 WHERE user_id=? AND notified=0', [req.user.id]);
    }
    res.json({ notifications: notifs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load notifications.' });
  }
});

// ── DAILY MISSIONS ─────────────────────────────────────────────

// GET /api/daily — today's missions for the player
router.get('/daily', requireAuth, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Generate today's missions if not already assigned
    let missions = await query(
      'SELECT pdm.*, dmp.title, dmp.description, dmp.condition_type, dmp.condition_value, dmp.reward_cash, dmp.reward_xp, dmp.reward_season_xp FROM player_daily_missions pdm JOIN daily_mission_pool dmp ON dmp.mission_id = pdm.mission_id WHERE pdm.user_id = ? AND pdm.mission_date = ?',
      [req.user.id, today]
    );

    if (missions.length === 0) {
      missions = await assignDailyMissions(req.user.id, today);
    }

    // Get streak
    const streak = await queryOne('SELECT * FROM daily_streaks WHERE user_id = ?', [req.user.id]) || { current_streak: 0, longest_streak: 0 };

    res.json({ missions, today, streak });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load daily missions.' });
  }
});

// POST /api/daily/claim/:missionId — claim completed mission reward
router.post('/daily/claim/:missionId', requireAuth, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const mission = await queryOne(
      `SELECT pdm.*, dmp.title, dmp.reward_cash, dmp.reward_xp, dmp.reward_season_xp
       FROM player_daily_missions pdm JOIN daily_mission_pool dmp ON dmp.mission_id = pdm.mission_id
       WHERE pdm.id = ? AND pdm.user_id = ? AND pdm.mission_date = ?`,
      [req.params.missionId, req.user.id, today]
    );

    if (!mission) return res.status(404).json({ error: 'Mission not found.' });
    if (!mission.completed) return res.status(400).json({ error: 'Mission not yet completed.' });
    if (mission.reward_claimed) return res.status(409).json({ error: 'Reward already claimed.' });

    // Pay rewards
    await query('UPDATE users SET cash=cash+?, xp=xp+? WHERE id=?', [mission.reward_cash, mission.reward_xp, req.user.id]);
    await query('UPDATE player_daily_missions SET reward_claimed=1 WHERE id=?', [mission.id]);

    // Add season XP
    if (mission.reward_season_xp > 0) {
      const season = await queryOne("SELECT id FROM seasons WHERE is_active=1 LIMIT 1");
      if (season) {
        await query(`INSERT INTO player_seasons (user_id, season_id, season_xp, rewards_claimed) VALUES (?,?,?,?)
          ON DUPLICATE KEY UPDATE season_xp=season_xp+?`,
          [req.user.id, season.id, mission.reward_season_xp, JSON.stringify([]), mission.reward_season_xp]
        ).catch(() => {});
      }
    }

    // Check if all missions complete → update streak
    const allComplete = await queryOne(
      'SELECT COUNT(*) cnt FROM player_daily_missions WHERE user_id=? AND mission_date=? AND completed=0',
      [req.user.id, today]
    );
    if (allComplete.cnt === 0) await updateStreak(req.user.id, today);

    res.json({ message: `Reward claimed: $${mission.reward_cash.toLocaleString()} + ${mission.reward_xp} XP`, reward_cash: mission.reward_cash, reward_xp: mission.reward_xp });
  } catch (err) {
    res.status(500).json({ error: 'Failed to claim reward.' });
  }
});

// ── INTERNAL HELPERS ───────────────────────────────────────────

async function assignDailyMissions(userId, date) {
  const pool = await query('SELECT * FROM daily_mission_pool');
  // Pick 3 random non-repeating missions
  const shuffled = pool.sort(() => Math.random() - 0.5).slice(0, 3);
  const missions = [];

  for (const m of shuffled) {
    await query(
      'INSERT IGNORE INTO player_daily_missions (user_id, mission_date, mission_id) VALUES (?,?,?)',
      [userId, date, m.mission_id]
    );
    missions.push({ ...m, progress: 0, completed: false, reward_claimed: false });
  }

  return missions;
}

async function updateStreak(userId, today) {
  const existing = await queryOne('SELECT * FROM daily_streaks WHERE user_id = ?', [userId]);
  if (!existing) {
    await query('INSERT INTO daily_streaks (user_id, current_streak, longest_streak, last_completed) VALUES (?,1,1,?)', [userId, today]);
    return;
  }

  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const wasYesterday = existing.last_completed === yesterday;
  const newStreak = wasYesterday ? existing.current_streak + 1 : 1;
  const longest   = Math.max(newStreak, existing.longest_streak);

  await query('UPDATE daily_streaks SET current_streak=?, longest_streak=?, last_completed=? WHERE user_id=?',
    [newStreak, longest, today, userId]);

  // Achievement checks
  if (newStreak >= 7)  await query('INSERT IGNORE INTO player_achievements (user_id,achievement_id) VALUES (?,?)', [userId, 'daily_7']).catch(() => {});
  if (newStreak >= 30) await query('INSERT IGNORE INTO player_achievements (user_id,achievement_id) VALUES (?,?)', [userId, 'daily_30']).catch(() => {});
}

// Called from game engine on match end — checks and unlocks achievements
async function checkAchievements(userId) {
  const user = await queryOne(
    'SELECT u.kills, u.deaths, u.heists_won, u.rank_level, u.cash, u.xp, COUNT(f.id) friend_count FROM users u LEFT JOIN friendships f ON (f.user_id=u.id OR f.friend_id=u.id) AND f.status="accepted" WHERE u.id=?',
    [userId]
  );
  if (!user) return [];

  const referrals = await queryOne('SELECT uses FROM referral_codes WHERE user_id=?', [userId]) || { uses: 0 };
  const marketTx  = await queryOne("SELECT COUNT(*) cnt FROM marketplace_listings WHERE (seller_id=? AND status='sold') OR buyer_id=?", [userId, userId]) || { cnt: 0 };
  const kd        = user.deaths > 0 ? Math.floor((user.kills / user.deaths) * 100) : user.kills * 100;
  const ps        = await queryOne("SELECT current_tier FROM player_seasons ps JOIN seasons s ON s.id=ps.season_id WHERE ps.user_id=? AND s.is_active=1", [userId]) || { current_tier: 0 };

  const conditions = {
    kills_total:    user.kills,
    wins_total:     await queryOne("SELECT COUNT(*) cnt FROM match_history WHERE user_id=? AND outcome='win'", [userId]).then(r => r.cnt),
    heists_total:   user.heists_won,
    rank_level:     user.rank_level,
    cash_total:     user.cash,
    friends_total:  user.friend_count,
    referrals:      referrals.uses,
    marketplace_tx: marketTx.cnt,
    kd_ratio:       kd,
    season_tier:    ps.current_tier,
  };

  const all = await query('SELECT * FROM achievements');
  const alreadyUnlocked = new Set((await query('SELECT achievement_id FROM player_achievements WHERE user_id=?', [userId])).map(a => a.achievement_id));

  const newlyUnlocked = [];
  for (const ach of all) {
    if (alreadyUnlocked.has(ach.achievement_id)) continue;
    const val = conditions[ach.condition_type] || 0;
    if (val >= ach.condition_value) {
      await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [userId, ach.achievement_id]).catch(() => {});
      if (ach.reward_cash > 0) await query('UPDATE users SET cash=cash+? WHERE id=?', [ach.reward_cash, userId]).catch(() => {});
      if (ach.reward_xp > 0)   await query('UPDATE users SET xp=xp+? WHERE id=?', [ach.reward_xp, userId]).catch(() => {});
      newlyUnlocked.push(ach);
    } else if (['kills_total','wins_total','heists_total','friends_total','referrals','marketplace_tx'].includes(ach.condition_type)) {
      // Update progress
      await query('INSERT INTO achievement_progress (user_id, achievement_id, current_value) VALUES (?,?,?) ON DUPLICATE KEY UPDATE current_value=?',
        [userId, ach.achievement_id, val, val]).catch(() => {});
    }
  }

  return newlyUnlocked;
}

// Export checkAchievements for use in game engine
module.exports = { router, checkAchievements };
