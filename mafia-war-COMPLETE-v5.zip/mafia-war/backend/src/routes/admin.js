const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');
const { invalidateBanCache } = require('../middleware/ipBan');

router.get('/users', requireAdmin, async (req, res) => {
  try {
    const { search='', page=1, limit=50, role, banned } = req.query;
    const offset = (parseInt(page)-1)*parseInt(limit);
    const like = `%${search}%`;
    const conds = ['(username LIKE ? OR email LIKE ?)'];
    const params = [like, like];
    if (role)   { conds.push('role=?'); params.push(role); }
    if (banned) { conds.push('is_banned=?'); params.push(banned==='true'?1:0); }
    const where = conds.join(' AND ');
    const users = await query(`SELECT id,uuid,username,email,role,faction,rank_level,xp,kills,deaths,cash,is_banned,ban_reason,subscription_status,last_login,created_at FROM users WHERE ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,[...params,parseInt(limit),offset]);
    const [{total}] = await query(`SELECT COUNT(*) total FROM users WHERE ${where}`,params);
    res.json({ users, total, page:parseInt(page), limit:parseInt(limit) });
  } catch(err){ res.status(500).json({error:'Failed to load users.'}); }
});

router.post('/ban', requireAdmin, async (req,res)=>{
  try{
    const {user_id,reason}=req.body;
    if(!user_id) return res.status(400).json({error:'user_id required.'});
    const target=await queryOne('SELECT role FROM users WHERE id=?',[user_id]);
    if(target&&['admin','owner'].includes(target.role)) return res.status(403).json({error:'Cannot ban admin/owner accounts.'});
    await query('UPDATE users SET is_banned=1,ban_reason=? WHERE id=?',[reason||'Violation of terms',user_id]);
    const io=global._mw_io;
    if(io){ io.sockets.sockets.forEach(socket=>{ if(socket.user?.id===parseInt(user_id)){ socket.emit('account_banned',{reason:reason||'Violation of terms'}); socket.disconnect(true); } }); }
    res.json({message:'Player banned and kicked.'});
  }catch(err){ res.status(500).json({error:'Failed to ban player.'}); }
});

router.post('/unban', requireAdmin, async(req,res)=>{
  try{
    const {user_id}=req.body;
    await query('UPDATE users SET is_banned=0,ban_reason=NULL WHERE id=?',[user_id]);
    res.json({message:'Player unbanned.'});
  }catch(err){ res.status(500).json({error:'Failed to unban player.'}); }
});

router.post('/ip-ban', requireAdmin, async(req,res)=>{
  try{
    const {ip_address,reason,hours}=req.body;
    if(!ip_address) return res.status(400).json({error:'ip_address required.'});
    const expires=hours?new Date(Date.now()+parseInt(hours)*3600000).toISOString().slice(0,19).replace('T',' '):null;
    await query('INSERT INTO ip_bans (ip_address,reason,banned_by,expires_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE reason=VALUES(reason),expires_at=VALUES(expires_at)',[ip_address,reason||'Admin action',req.user.id,expires]);
    invalidateBanCache(ip_address);
    res.json({message:`IP ${ip_address} banned${hours?` for ${hours}h`:' permanently'}.`});
  }catch(err){ res.status(500).json({error:'Failed to ban IP.'}); }
});

router.delete('/ip-ban/:ip', requireAdmin, async(req,res)=>{
  try{
    const ip=decodeURIComponent(req.params.ip);
    await query('DELETE FROM ip_bans WHERE ip_address=?',[ip]);
    invalidateBanCache(ip);
    res.json({message:`IP ${ip} unbanned.`});
  }catch(err){ res.status(500).json({error:'Failed to unban IP.'}); }
});

router.get('/ip-bans', requireAdmin, async(req,res)=>{
  try{
    const bans=await query('SELECT ib.*,u.username banned_by_name FROM ip_bans ib LEFT JOIN users u ON u.id=ib.banned_by ORDER BY ib.created_at DESC LIMIT 200');
    res.json({bans});
  }catch(err){ res.status(500).json({error:'Failed to load IP bans.'}); }
});

router.get('/stats', requireAdmin, async(req,res)=>{
  try{
    const [totals]=await query('SELECT COUNT(*) total_users,SUM(is_banned) banned_users,SUM(subscription_status="active") premium_users,SUM(role="admin") admins FROM users');
    const [rooms]=await query('SELECT COUNT(*) total_rooms,SUM(status="active") active_rooms FROM game_rooms');
    const [revenue]=await query("SELECT COALESCE(SUM(amount),0) total_revenue_cents FROM payments WHERE status='succeeded'");
    const [reports]=await query("SELECT COUNT(*) open_reports FROM player_reports WHERE status='open'");
    const [today]=await query("SELECT COUNT(*) today_signups FROM users WHERE DATE(created_at)=CURDATE()");
    const [matches]=await query("SELECT COUNT(*) total_matches FROM match_history WHERE DATE(played_at)=CURDATE()");
    res.json({...totals,...rooms,...revenue,...reports,...today,...matches});
  }catch(err){ res.status(500).json({error:'Failed to load admin stats.'}); }
});

router.get('/reports', requireAdmin, async(req,res)=>{
  try{
    const reports=await query(`SELECT pr.*,u1.username reporter_name,u2.username reported_name FROM player_reports pr JOIN users u1 ON u1.id=pr.reporter_id JOIN users u2 ON u2.id=pr.reported_id WHERE pr.status='open' ORDER BY pr.created_at DESC LIMIT 100`);
    res.json({reports});
  }catch(err){ res.status(500).json({error:'Failed to load reports.'}); }
});

router.post('/reports/:id/resolve', requireAdmin, async(req,res)=>{
  try{ await query("UPDATE player_reports SET status='resolved' WHERE id=?",[req.params.id]); res.json({message:'Report resolved.'}); }
  catch(err){ res.status(500).json({error:'Failed to resolve report.'}); }
});

router.post('/promote', requireAdmin, async(req,res)=>{
  try{
    const {user_id,role}=req.body;
    if(!['player','premium','admin'].includes(role)) return res.status(400).json({error:'Invalid role.'});
    await query('UPDATE users SET role=? WHERE id=?',[role,user_id]);
    res.json({message:`User promoted to ${role}.`});
  }catch(err){ res.status(500).json({error:'Failed to promote user.'}); }
});

router.post('/adjust-cash', requireAdmin, async(req,res)=>{
  try{
    const {user_id,amount}=req.body;
    if(!user_id||!amount) return res.status(400).json({error:'user_id and amount required.'});
    await query('UPDATE users SET cash=GREATEST(0,cash+?) WHERE id=?',[parseInt(amount),user_id]);
    res.json({message:`Cash adjusted by $${amount}.`});
  }catch(err){ res.status(500).json({error:'Failed to adjust cash.'}); }
});

router.get('/active-rooms', requireAdmin, async(req,res)=>{
  try{
    const rooms=await query(`SELECT gr.*,u.username host_name FROM game_rooms gr LEFT JOIN users u ON u.id=gr.host_id WHERE gr.status IN ('active','waiting') ORDER BY gr.started_at DESC LIMIT 50`);
    res.json({rooms});
  }catch(err){ res.status(500).json({error:'Failed to load rooms.'}); }
});

router.post('/end-room', requireAdmin, async(req,res)=>{
  try{
    const {room_code}=req.body;
    if(!room_code) return res.status(400).json({error:'room_code required.'});
    await query("UPDATE game_rooms SET status='ended',ended_at=NOW() WHERE room_code=?",[room_code]);
    const io=global._mw_io;
    if(io) io.to(room_code).emit('admin_force_end',{message:'Room ended by administrator.'});
    res.json({message:`Room ${room_code} force-ended.`});
  }catch(err){ res.status(500).json({error:'Failed to end room.'}); }
});

module.exports = router;
