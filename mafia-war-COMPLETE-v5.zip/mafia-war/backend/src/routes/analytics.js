const router = require('express').Router();
const { query } = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');

// GET /api/analytics/revenue — daily revenue for last 30 days
router.get('/revenue', requireAdmin, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const rows = await query(
      `SELECT DATE(created_at) stat_date,
        COUNT(*) transactions,
        SUM(amount) total_cents,
        SUM(CASE WHEN type='subscription' THEN amount ELSE 0 END) subscription_cents,
        SUM(CASE WHEN type='in_game' THEN amount ELSE 0 END) ingame_cents
       FROM payments
       WHERE status='succeeded' AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE(created_at)
       ORDER BY stat_date`,
      [days]
    );
    res.json({ revenue: rows, days });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load revenue analytics.' });
  }
});

// GET /api/analytics/players — new registrations + active users over time
router.get('/players', requireAdmin, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const newUsers = await query(
      `SELECT DATE(created_at) stat_date, COUNT(*) new_users
       FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE(created_at) ORDER BY stat_date`,
      [days]
    );
    const activeUsers = await query(
      `SELECT DATE(last_login) stat_date, COUNT(*) active_users
       FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE(last_login) ORDER BY stat_date`,
      [days]
    );
    res.json({ new_users: newUsers, active_users: activeUsers, days });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load player analytics.' });
  }
});

// GET /api/analytics/matches — matches played, kills, heists over time
router.get('/matches', requireAdmin, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const matches = await query(
      `SELECT DATE(played_at) stat_date,
        COUNT(DISTINCT room_id) matches_played,
        SUM(kills) total_kills,
        SUM(xp_earned) total_xp
       FROM match_history WHERE played_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE(played_at) ORDER BY stat_date`,
      [days]
    );
    const heists = await query(
      `SELECT DATE(completed_at) stat_date, COUNT(*) heists, status
       FROM heist_missions WHERE completed_at IS NOT NULL AND completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE(completed_at), status ORDER BY stat_date`,
      [days]
    );
    res.json({ matches, heists, days });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load match analytics.' });
  }
});

// GET /api/analytics/weapons — most used weapons
router.get('/weapons', requireAdmin, async (req, res) => {
  try {
    const popular = await query(
      `SELECT weapon_name, weapon_type, COUNT(*) owned_by_players, SUM(ammo) total_ammo
       FROM weapons_inventory
       GROUP BY weapon_id, weapon_name, weapon_type
       ORDER BY owned_by_players DESC`
    );
    const shop = await query(
      `SELECT weapon_name, COUNT(*) times_purchased
       FROM marketplace_listings WHERE status='sold'
       GROUP BY weapon_id, weapon_name ORDER BY times_purchased DESC`
    );
    res.json({ popular_weapons: popular, marketplace_sales: shop });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load weapon analytics.' });
  }
});

// GET /api/analytics/maps — map popularity
router.get('/maps', requireAdmin, async (req, res) => {
  try {
    const maps = await query(
      `SELECT map_id, mode,
        COUNT(*) total_rooms,
        AVG(current_players) avg_players,
        SUM(CASE WHEN status='ended' THEN 1 ELSE 0 END) completed_rooms
       FROM game_rooms
       GROUP BY map_id, mode
       ORDER BY total_rooms DESC`
    );
    res.json({ maps });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load map analytics.' });
  }
});

// GET /api/analytics/retention — D1/D7/D30 retention
router.get('/retention', requireAdmin, async (req, res) => {
  try {
    const [total] = await query('SELECT COUNT(*) total FROM users');
    const [d1]    = await query("SELECT COUNT(*) cnt FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    const [d7]    = await query("SELECT COUNT(*) cnt FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    const [d30]   = await query("SELECT COUNT(*) cnt FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
    const [premium] = await query("SELECT COUNT(*) cnt FROM users WHERE subscription_status='active'");
    const [banned]  = await query("SELECT COUNT(*) cnt FROM users WHERE is_banned=1");

    res.json({
      total_users:    total.total,
      dau:            d1.cnt,
      wau:            d7.cnt,
      mau:            d30.cnt,
      premium_users:  premium.cnt,
      banned_users:   banned.cnt,
      d1_rate:        total.total > 0 ? ((d1.cnt / total.total) * 100).toFixed(1) : 0,
      d7_rate:        total.total > 0 ? ((d7.cnt / total.total) * 100).toFixed(1) : 0,
      d30_rate:       total.total > 0 ? ((d30.cnt / total.total) * 100).toFixed(1) : 0,
      premium_rate:   total.total > 0 ? ((premium.cnt / total.total) * 100).toFixed(1) : 0,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load retention analytics.' });
  }
});

// GET /api/analytics/summary — single endpoint for admin dashboard overview
router.get('/summary', requireAdmin, async (req, res) => {
  try {
    const [rev7]  = await query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='succeeded' AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");
    const [rev30] = await query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='succeeded' AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)");
    const [matches7] = await query("SELECT COUNT(DISTINCT room_id) cnt FROM match_history WHERE played_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");
    const topMaps    = await query("SELECT map_id, COUNT(*) cnt FROM game_rooms GROUP BY map_id ORDER BY cnt DESC LIMIT 5");
    const topWeapons = await query("SELECT weapon_name, COUNT(*) cnt FROM weapons_inventory GROUP BY weapon_id ORDER BY cnt DESC LIMIT 5");
    const factions   = await query("SELECT faction, COUNT(*) cnt FROM users WHERE faction IS NOT NULL AND is_banned=0 GROUP BY faction ORDER BY cnt DESC");
    res.json({
      revenue_7d:    (rev7.total  / 100).toFixed(2),
      revenue_30d:   (rev30.total / 100).toFixed(2),
      matches_7d:    matches7.cnt,
      top_maps:      topMaps,
      top_weapons:   topWeapons,
      faction_distribution: factions,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load analytics summary.' });
  }
});

module.exports = router;
