const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { query, queryOne } = require('../db/pool');
const { signAccess, signRefresh, verifyToken } = require('../middleware/auth');
const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { error: 'Too many attempts' } });

// POST /api/auth/register
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { username, email, password, age_confirmed } = req.body;

    if (!username || !email || !password || !age_confirmed) {
      return res.status(400).json({ error: 'All fields required. You must confirm you are 18+.' });
    }
    if (!age_confirmed) {
      return res.status(400).json({ error: 'You must be 18 or older to play Mafia War.' });
    }
    if (username.length < 3 || username.length > 20) {
      return res.status(400).json({ error: 'Username must be 3–20 characters.' });
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.status(400).json({ error: 'Username: letters, numbers, underscore only.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters.' });
    }

    const existing = await queryOne('SELECT id FROM users WHERE email = ? OR username = ?', [email, username]);
    if (existing) return res.status(409).json({ error: 'Email or username already taken.' });

    const hash = await bcrypt.hash(password, 12);
    const uuid = uuidv4();

    const result = await query(
      'INSERT INTO users (uuid, username, email, password_hash, age_verified) VALUES (?, ?, ?, ?, 1)',
      [uuid, username, email.toLowerCase(), hash]
    );
    const userId = result.insertId;

    // Seed default weapon
    await query(
      'INSERT INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) VALUES (?, ?, ?, ?, ?)',
      [userId, 'pistol_basic', 'Glock 17', 'pistol', 120]
    );

    // Seed leaderboard entry
    await query(
      'INSERT INTO leaderboard (user_id, username) VALUES (?, ?)',
      [userId, username]
    );

    const accessToken  = await signAccess({ sub: userId, role: 'player' });
    const refreshToken = await signRefresh({ sub: userId });

    res.status(201).json({
      message: 'Welcome to Mafia War.',
      accessToken,
      refreshToken,
      user: { id: userId, uuid, username, role: 'player', faction: null, rank_level: 1 }
    });
  } catch (err) {
    console.error('[AUTH] Register error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

// POST /api/auth/login
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required.' });

    const user = await queryOne(
      'SELECT id, uuid, username, email, password_hash, role, faction, rank_level, xp, kills, deaths, cash, is_banned, subscription_status FROM users WHERE email = ?',
      [email.toLowerCase()]
    );

    if (!user) return res.status(401).json({ error: 'Invalid credentials.' });
    if (user.is_banned) return res.status(403).json({ error: 'Account suspended. Contact support.' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials.' });

    await query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);

    const accessToken  = await signAccess({ sub: user.id, role: user.role });
    const refreshToken = await signRefresh({ sub: user.id });

    const { password_hash, ...safeUser } = user;
    res.json({ accessToken, refreshToken, user: safeUser });
  } catch (err) {
    console.error('[AUTH] Login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: 'Refresh token required.' });
    const payload = await verifyToken(refreshToken);
    const user = await queryOne('SELECT id, role FROM users WHERE id = ? AND is_banned = 0', [payload.sub]);
    if (!user) return res.status(401).json({ error: 'Invalid refresh token.' });
    const accessToken = await signAccess({ sub: user.id, role: user.role });
    res.json({ accessToken });
  } catch {
    res.status(401).json({ error: 'Invalid or expired refresh token.' });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.json({ message: 'Logged out.' });
});

module.exports = router;
