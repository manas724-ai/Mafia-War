const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/cosmetics — list all with ownership + equipped status
router.get('/', requireAuth, async (req, res) => {
  try {
    const all      = await query('SELECT * FROM cosmetics ORDER BY type, rarity DESC, price_cash');
    const owned    = await query('SELECT cosmetic_id FROM player_cosmetics WHERE user_id = ?', [req.user.id]);
    const equipped = await query('SELECT slot_type, cosmetic_id FROM equipped_cosmetics WHERE user_id = ?', [req.user.id]);
    const user     = await queryOne('SELECT cash, rank_level FROM users WHERE id = ?', [req.user.id]);

    const ownedSet    = new Set(owned.map(o => o.cosmetic_id));
    const equippedMap = {};
    equipped.forEach(e => { equippedMap[e.slot_type] = e.cosmetic_id; });

    res.json({
      cosmetics: all.map(c => ({
        ...c,
        owned:    ownedSet.has(c.cosmetic_id),
        equipped: equippedMap[c.type] === c.cosmetic_id,
        can_buy:  !ownedSet.has(c.cosmetic_id) && user.cash >= c.price_cash && user.rank_level >= c.unlock_rank,
        locked:   user.rank_level < c.unlock_rank,
      })),
      equipped: equippedMap,
      cash:     user.cash,
      rank:     user.rank_level,
    });
  } catch (err) {
    console.error('[COSMETICS] List error:', err);
    res.status(500).json({ error: 'Failed to load cosmetics.' });
  }
});

// POST /api/cosmetics/buy
router.post('/buy', requireAuth, async (req, res) => {
  try {
    const { cosmetic_id } = req.body;
    if (!cosmetic_id) return res.status(400).json({ error: 'cosmetic_id required.' });

    const cosmetic = await queryOne('SELECT * FROM cosmetics WHERE cosmetic_id = ?', [cosmetic_id]);
    if (!cosmetic) return res.status(404).json({ error: 'Cosmetic not found.' });

    const user = await queryOne('SELECT cash, rank_level FROM users WHERE id = ?', [req.user.id]);
    if (user.rank_level < cosmetic.unlock_rank)
      return res.status(403).json({ error: `Rank ${cosmetic.unlock_rank} required.` });
    if (cosmetic.price_cash > 0 && user.cash < cosmetic.price_cash)
      return res.status(402).json({ error: `Need $${cosmetic.price_cash.toLocaleString()} in-game cash.` });

    const existing = await queryOne(
      'SELECT id FROM player_cosmetics WHERE user_id = ? AND cosmetic_id = ?',
      [req.user.id, cosmetic_id]
    );
    if (existing) return res.status(409).json({ error: 'Already owned.' });

    if (cosmetic.price_cash > 0)
      await query('UPDATE users SET cash = cash - ? WHERE id = ?', [cosmetic.price_cash, req.user.id]);

    await query('INSERT INTO player_cosmetics (user_id, cosmetic_id) VALUES (?, ?)', [req.user.id, cosmetic_id]);

    res.json({ message: `${cosmetic.name} acquired.`, cosmetic_id, cash_spent: cosmetic.price_cash });
  } catch (err) {
    res.status(500).json({ error: 'Failed to purchase cosmetic.' });
  }
});

// POST /api/cosmetics/equip
router.post('/equip', requireAuth, async (req, res) => {
  try {
    const { cosmetic_id } = req.body;
    if (!cosmetic_id) return res.status(400).json({ error: 'cosmetic_id required.' });

    const owned = await queryOne(
      'SELECT pc.cosmetic_id, c.type FROM player_cosmetics pc JOIN cosmetics c ON c.cosmetic_id = pc.cosmetic_id WHERE pc.user_id = ? AND pc.cosmetic_id = ?',
      [req.user.id, cosmetic_id]
    );
    if (!owned) return res.status(403).json({ error: 'You do not own this cosmetic.' });

    await query(
      'INSERT INTO equipped_cosmetics (user_id, slot_type, cosmetic_id) VALUES (?,?,?) ON DUPLICATE KEY UPDATE cosmetic_id = VALUES(cosmetic_id)',
      [req.user.id, owned.type, cosmetic_id]
    );

    res.json({ message: 'Equipped.', slot: owned.type, cosmetic_id });
  } catch (err) {
    res.status(500).json({ error: 'Failed to equip cosmetic.' });
  }
});

// POST /api/cosmetics/unequip
router.post('/unequip', requireAuth, async (req, res) => {
  try {
    const { slot_type } = req.body;
    await query('DELETE FROM equipped_cosmetics WHERE user_id = ? AND slot_type = ?', [req.user.id, slot_type]);
    res.json({ message: 'Unequipped.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to unequip.' });
  }
});

// GET /api/cosmetics/profile/:userId — get another player's profile card
router.get('/profile/:userId', requireAuth, async (req, res) => {
  try {
    const user = await queryOne(
      `SELECT u.id, u.username, u.faction, u.rank_level, u.xp, u.kills, u.deaths, u.heists_won, u.cash,
              r.title rank_title, u.created_at
       FROM users u
       LEFT JOIN rank_definitions r ON r.level = u.rank_level
       WHERE u.id = ? AND u.is_banned = 0`,
      [req.params.userId]
    );
    if (!user) return res.status(404).json({ error: 'Player not found.' });

    const equipped = await query(
      'SELECT ec.slot_type, c.cosmetic_id, c.name, c.css_value FROM equipped_cosmetics ec JOIN cosmetics c ON c.cosmetic_id = ec.cosmetic_id WHERE ec.user_id = ?',
      [req.params.userId]
    );

    const weapons = await query(
      'SELECT weapon_id, weapon_name, weapon_type FROM weapons_inventory WHERE user_id = ? LIMIT 5',
      [req.params.userId]
    );

    const kd = user.deaths > 0 ? (user.kills / user.deaths).toFixed(2) : user.kills;

    res.json({ user: { ...user, kd }, equipped, weapons });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load profile.' });
  }
});

module.exports = router;
