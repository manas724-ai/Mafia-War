const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/friends — list friends and pending requests
router.get('/', requireAuth, async (req, res) => {
  try {
    const friends = await query(`
      SELECT f.id, f.status, f.created_at,
        CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END AS other_id,
        u.username, u.faction, u.rank_level, u.last_login,
        CASE WHEN f.user_id = ? THEN 'sent' ELSE 'received' END AS direction
      FROM friendships f
      JOIN users u ON u.id = (CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END)
      WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status != 'blocked'
      ORDER BY f.status DESC, u.username
    `, [req.user.id, req.user.id, req.user.id, req.user.id, req.user.id]);

    res.json({ friends });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load friends.' });
  }
});

// POST /api/friends/request — send friend request
router.post('/request', requireAuth, async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ error: 'Username required.' });
    if (username === req.user.username) return res.status(400).json({ error: 'Cannot friend yourself.' });

    const target = await queryOne('SELECT id FROM users WHERE username = ?', [username]);
    if (!target) return res.status(404).json({ error: 'Player not found.' });

    const existing = await queryOne(
      'SELECT * FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)',
      [req.user.id, target.id, target.id, req.user.id]
    );
    if (existing) {
      if (existing.status === 'accepted') return res.status(409).json({ error: 'Already friends.' });
      if (existing.status === 'pending')  return res.status(409).json({ error: 'Request already pending.' });
    }

    await query('INSERT INTO friendships (user_id, friend_id) VALUES (?, ?)', [req.user.id, target.id]);
    res.json({ message: `Friend request sent to ${username}.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send request.' });
  }
});

// POST /api/friends/accept — accept incoming request
router.post('/accept', requireAuth, async (req, res) => {
  try {
    const { friendship_id } = req.body;
    const f = await queryOne('SELECT * FROM friendships WHERE id = ? AND friend_id = ? AND status = ?',
      [friendship_id, req.user.id, 'pending']);
    if (!f) return res.status(404).json({ error: 'Request not found.' });

    await query("UPDATE friendships SET status = 'accepted' WHERE id = ?", [friendship_id]);
    res.json({ message: 'Friend request accepted.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to accept request.' });
  }
});

// DELETE /api/friends/:id — remove friend
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    await query('DELETE FROM friendships WHERE id = ? AND (user_id = ? OR friend_id = ?)',
      [req.params.id, req.user.id, req.user.id]);
    res.json({ message: 'Friend removed.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to remove friend.' });
  }
});

// POST /api/friends/invite — invite friend to room
router.post('/invite', requireAuth, async (req, res) => {
  try {
    const { friend_id, room_code } = req.body;
    // Emit via socket if friend is online (handled in engine via userSockets map)
    // Here just validate the friendship
    const f = await queryOne(
      "SELECT * FROM friendships WHERE ((user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)) AND status='accepted'",
      [req.user.id, friend_id, friend_id, req.user.id]
    );
    if (!f) return res.status(403).json({ error: 'Not friends with this player.' });
    res.json({ message: 'Invite sent via socket.', room_code, friend_id });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send invite.' });
  }
});

module.exports = router;
