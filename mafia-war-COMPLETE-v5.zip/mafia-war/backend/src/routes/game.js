const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

function genCode() {
  return Math.random().toString(36).substring(2, 10).toUpperCase();
}

// GET /api/game/rooms — list open rooms
router.get('/rooms', requireAuth, async (req, res) => {
  try {
    const rooms = await query(
      `SELECT gr.*, u.username host_name
       FROM game_rooms gr
       LEFT JOIN users u ON u.id = gr.host_id
       WHERE gr.status = 'waiting'
       ORDER BY gr.created_at DESC LIMIT 30`
    );
    res.json({ rooms });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load rooms.' });
  }
});

// POST /api/game/rooms — create room
router.post('/rooms', requireAuth, async (req, res) => {
  try {
    const { name, map_id = 'downtown', mode = 'deathmatch', max_players = 20 } = req.body;
    if (!name) return res.status(400).json({ error: 'Room name required.' });

    const map = await queryOne('SELECT * FROM map_definitions WHERE map_id = ?', [map_id]);
    if (!map) return res.status(400).json({ error: 'Invalid map.' });
    if (req.user.rank_level < map.unlock_rank) {
      return res.status(403).json({ error: `Rank ${map.unlock_rank} required for ${map.name}.` });
    }

    const room_code = genCode();
    const result = await query(
      'INSERT INTO game_rooms (room_code, name, map_id, mode, max_players, host_id) VALUES (?,?,?,?,?,?)',
      [room_code, name, map_id, mode, Math.min(max_players, map.max_players), req.user.id]
    );
    const room = await queryOne('SELECT * FROM game_rooms WHERE id = ?', [result.insertId]);
    res.status(201).json({ room });
  } catch (err) {
    console.error('[GAME] Create room error:', err);
    res.status(500).json({ error: 'Failed to create room.' });
  }
});

// GET /api/game/rooms/:code
router.get('/rooms/:code', requireAuth, async (req, res) => {
  try {
    const room = await queryOne(
      `SELECT gr.*, u.username host_name FROM game_rooms gr
       LEFT JOIN users u ON u.id = gr.host_id
       WHERE gr.room_code = ?`,
      [req.params.code.toUpperCase()]
    );
    if (!room) return res.status(404).json({ error: 'Room not found.' });
    res.json({ room });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load room.' });
  }
});

// GET /api/game/maps — all maps
router.get('/maps', async (req, res) => {
  try {
    const maps = await query('SELECT * FROM map_definitions ORDER BY unlock_rank');
    res.json({ maps });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load maps.' });
  }
});

// GET /api/game/ranks — all ranks
router.get('/ranks', async (req, res) => {
  try {
    const ranks = await query('SELECT * FROM rank_definitions ORDER BY level');
    res.json({ ranks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load ranks.' });
  }
});

module.exports = router;
