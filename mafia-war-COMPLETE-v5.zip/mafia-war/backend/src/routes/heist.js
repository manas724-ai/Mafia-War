const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// Heist banks config
const BANKS = {
  federal_bank: {
    name:        'First Federal Bank',
    vault_amount: 500000,
    time_limit:   300,
    phases:       ['breach','hack','secure','extract'],
    guards:       8,
    min_players:  2,
    max_players:  6,
    xp_reward:    500,
    description:  'The city\'s largest federal reserve. Maximum security. Maximum payout.',
  },
  casino_vault: {
    name:        'Casino Vault',
    vault_amount: 350000,
    time_limit:   240,
    phases:       ['breach','hack','extract'],
    guards:       6,
    min_players:  2,
    max_players:  4,
    xp_reward:    400,
    description:  'Under the Golden Palace. Crack it before the mob enforcers arrive.',
  },
  armoured_car: {
    name:        'Armoured Car Ambush',
    vault_amount: 150000,
    time_limit:   180,
    phases:       ['breach','secure','extract'],
    guards:       4,
    min_players:  2,
    max_players:  4,
    xp_reward:    300,
    description:  'Hit it on the highway. Fast, violent, no mercy.',
  },
};

// GET /api/heist/banks — list available heist banks
router.get('/banks', requireAuth, async (req, res) => {
  try {
    res.json({
      banks: Object.entries(BANKS).map(([id, b]) => ({
        bank_id:      id,
        ...b,
        rank_required: id === 'federal_bank' ? 5 : id === 'casino_vault' ? 7 : 4,
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load banks.' });
  }
});

// POST /api/heist/start — start a heist mission for a room
router.post('/start', requireAuth, async (req, res) => {
  try {
    const { room_code, bank_id, role = 'shooter' } = req.body;
    if (!room_code || !bank_id) return res.status(400).json({ error: 'room_code and bank_id required.' });

    const bank = BANKS[bank_id];
    if (!bank) return res.status(400).json({ error: 'Invalid bank.' });

    const room = await queryOne(
      "SELECT * FROM game_rooms WHERE room_code = ? AND mode = 'heist' AND status = 'active'",
      [room_code]
    );
    if (!room) return res.status(404).json({ error: 'Active heist room not found.' });

    // Check no existing active heist
    const existing = await queryOne(
      "SELECT id FROM heist_missions WHERE room_id = ? AND status IN ('planning','active')",
      [room.id]
    );
    if (existing) return res.status(409).json({ error: 'Heist already in progress.' });

    const result = await query(
      `INSERT INTO heist_missions (room_id, bank_id, vault_amount, time_limit)
       VALUES (?, ?, ?, ?)`,
      [room.id, bank_id, bank.vault_amount, bank.time_limit]
    );
    const heistId = result.insertId;

    await query(
      'INSERT INTO heist_participants (heist_id, user_id, role) VALUES (?, ?, ?)',
      [heistId, req.user.id, role]
    );

    res.status(201).json({
      heist_id: heistId,
      bank,
      bank_id,
      message: 'Heist mission created. Waiting for crew.',
    });
  } catch (err) {
    console.error('[HEIST] Start error:', err);
    res.status(500).json({ error: 'Failed to start heist.' });
  }
});

// POST /api/heist/:id/join — join an existing heist as crew
router.post('/:id/join', requireAuth, async (req, res) => {
  try {
    const { role = 'shooter' } = req.body;
    const heist = await queryOne(
      "SELECT * FROM heist_missions WHERE id = ? AND status IN ('planning','active')",
      [req.params.id]
    );
    if (!heist) return res.status(404).json({ error: 'Heist not found or already ended.' });

    const bank = BANKS[heist.bank_id];
    const count = await queryOne('SELECT COUNT(*) cnt FROM heist_participants WHERE heist_id = ?', [req.params.id]);
    if (count.cnt >= bank.max_players) return res.status(409).json({ error: 'Heist crew is full.' });

    await query(
      'INSERT IGNORE INTO heist_participants (heist_id, user_id, role) VALUES (?, ?, ?)',
      [req.params.id, req.user.id, role]
    );

    res.json({ message: `Joined heist as ${role}.`, heist_id: heist.id });
  } catch (err) {
    res.status(500).json({ error: 'Failed to join heist.' });
  }
});

// GET /api/heist/:id — heist status
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const heist = await queryOne('SELECT * FROM heist_missions WHERE id = ?', [req.params.id]);
    if (!heist) return res.status(404).json({ error: 'Heist not found.' });

    const participants = await query(
      `SELECT hp.role, u.username, u.faction, u.rank_level
       FROM heist_participants hp
       JOIN users u ON u.id = hp.user_id
       WHERE hp.heist_id = ?`,
      [req.params.id]
    );

    const events = await query(
      `SELECT he.event_type, u.username, he.ts
       FROM heist_events he
       JOIN users u ON u.id = he.user_id
       WHERE he.heist_id = ?
       ORDER BY he.ts`,
      [req.params.id]
    );

    const bank = BANKS[heist.bank_id];
    const elapsed = heist.started_at
      ? Math.floor((Date.now() - new Date(heist.started_at).getTime()) / 1000)
      : 0;
    const timeLeft = Math.max(0, (bank?.time_limit || 300) - elapsed);

    res.json({ ...heist, bank, participants, events, time_left: timeLeft });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load heist.' });
  }
});

// Export BANKS for use in socket engine
module.exports = { router, BANKS };
