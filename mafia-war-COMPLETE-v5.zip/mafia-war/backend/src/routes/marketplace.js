const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const PLATFORM_FEE = 0.05; // 5% platform cut

// GET /api/marketplace — list active listings
router.get('/', requireAuth, async (req, res) => {
  try {
    const { weapon_type, min_price, max_price, sort = 'newest' } = req.query;
    let sql = `
      SELECT ml.*, u.username seller_name, u.faction seller_faction,
        (SELECT COUNT(*) FROM marketplace_offers mo WHERE mo.listing_id = ml.id AND mo.status = 'pending') offer_count
      FROM marketplace_listings ml JOIN users u ON u.id = ml.seller_id
      WHERE ml.status = 'active'`;
    const params = [];

    if (weapon_type) { sql += ' AND ml.weapon_id LIKE ?'; params.push(`%${weapon_type}%`); }
    if (min_price)   { sql += ' AND ml.price >= ?';       params.push(parseInt(min_price)); }
    if (max_price)   { sql += ' AND ml.price <= ?';       params.push(parseInt(max_price)); }

    sql += sort === 'price_asc'  ? ' ORDER BY ml.price ASC'
         : sort === 'price_desc' ? ' ORDER BY ml.price DESC'
         : ' ORDER BY ml.listed_at DESC';
    sql += ' LIMIT 50';

    const listings = await query(sql, params);
    const user     = await queryOne('SELECT cash FROM users WHERE id = ?', [req.user.id]);
    res.json({ listings, cash: user.cash });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load marketplace.' });
  }
});

// POST /api/marketplace/list — list a weapon for sale
router.post('/list', requireAuth, async (req, res) => {
  try {
    const { weapon_id, price } = req.body;
    if (!weapon_id || !price) return res.status(400).json({ error: 'weapon_id and price required.' });
    if (parseInt(price) < 100) return res.status(400).json({ error: 'Minimum listing price is $100.' });

    // Check ownership
    const owned = await queryOne(
      'SELECT * FROM weapons_inventory WHERE user_id = ? AND weapon_id = ?',
      [req.user.id, weapon_id]
    );
    if (!owned) return res.status(403).json({ error: 'You do not own this weapon.' });

    // Check not already listed
    const existing = await queryOne(
      "SELECT id FROM marketplace_listings WHERE seller_id = ? AND weapon_id = ? AND status = 'active'",
      [req.user.id, weapon_id]
    );
    if (existing) return res.status(409).json({ error: 'This weapon is already listed.' });

    // Prevent listing starter pistol
    if (weapon_id === 'pistol_basic') return res.status(400).json({ error: 'Cannot list the starter weapon.' });

    const result = await query(
      'INSERT INTO marketplace_listings (seller_id, weapon_id, weapon_name, price) VALUES (?,?,?,?)',
      [req.user.id, weapon_id, owned.weapon_name, parseInt(price)]
    );

    // Remove from inventory (held in escrow)
    await query('DELETE FROM weapons_inventory WHERE user_id = ? AND weapon_id = ?', [req.user.id, weapon_id]);

    res.status(201).json({ message: `${owned.weapon_name} listed for $${parseInt(price).toLocaleString()}.`, listing_id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: 'Failed to list weapon.' });
  }
});

// POST /api/marketplace/:id/buy — instant buy at listed price
router.post('/:id/buy', requireAuth, async (req, res) => {
  try {
    const listing = await queryOne("SELECT * FROM marketplace_listings WHERE id = ? AND status = 'active'", [req.params.id]);
    if (!listing) return res.status(404).json({ error: 'Listing not found or sold.' });
    if (listing.seller_id === req.user.id) return res.status(400).json({ error: 'Cannot buy your own listing.' });

    const buyer = await queryOne('SELECT cash FROM users WHERE id = ?', [req.user.id]);
    if (buyer.cash < listing.price) return res.status(402).json({ error: `Insufficient funds. Need $${listing.price.toLocaleString()}.` });

    const fee       = Math.floor(listing.price * PLATFORM_FEE);
    const sellerGet = listing.price - fee;

    // Transfer
    await query('UPDATE users SET cash = cash - ? WHERE id = ?', [listing.price, req.user.id]);
    await query('UPDATE users SET cash = cash + ? WHERE id = ?', [sellerGet, listing.seller_id]);

    // Mark sold
    await query("UPDATE marketplace_listings SET status='sold', buyer_id=?, sold_at=NOW() WHERE id=?", [req.user.id, req.params.id]);

    // Give weapon to buyer
    await query(
      'INSERT IGNORE INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) SELECT ?, weapon_id, weapon_name, weapon_type, ammo FROM weapon_shop WHERE weapon_id = ?',
      [req.user.id, listing.weapon_id]
    );

    // Cancel pending offers
    await query("UPDATE marketplace_offers SET status='rejected' WHERE listing_id=? AND status='pending'", [req.params.id]);

    // Achievement check
    await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [req.user.id, 'marketplace_1']).catch(() => {});
    await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [listing.seller_id, 'marketplace_1']).catch(() => {});

    res.json({ message: `${listing.weapon_name} purchased for $${listing.price.toLocaleString()}.`, weapon: listing.weapon_name, paid: listing.price, seller_received: sellerGet });
  } catch (err) {
    res.status(500).json({ error: 'Failed to purchase.' });
  }
});

// POST /api/marketplace/:id/offer — make a counter-offer
router.post('/:id/offer', requireAuth, async (req, res) => {
  try {
    const { offer_price } = req.body;
    if (!offer_price || parseInt(offer_price) < 1) return res.status(400).json({ error: 'Valid offer price required.' });

    const listing = await queryOne("SELECT * FROM marketplace_listings WHERE id=? AND status='active'", [req.params.id]);
    if (!listing) return res.status(404).json({ error: 'Listing not found.' });
    if (listing.seller_id === req.user.id) return res.status(400).json({ error: 'Cannot offer on your own listing.' });

    const buyer = await queryOne('SELECT cash FROM users WHERE id = ?', [req.user.id]);
    if (buyer.cash < parseInt(offer_price)) return res.status(402).json({ error: 'Insufficient funds for this offer.' });

    // Cancel previous offer from this buyer on this listing
    await query("UPDATE marketplace_offers SET status='withdrawn' WHERE listing_id=? AND buyer_id=? AND status='pending'", [req.params.id, req.user.id]);

    await query('INSERT INTO marketplace_offers (listing_id, buyer_id, offer_price) VALUES (?,?,?)', [req.params.id, req.user.id, parseInt(offer_price)]);
    res.json({ message: `Offer of $${parseInt(offer_price).toLocaleString()} submitted.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to submit offer.' });
  }
});

// POST /api/marketplace/offer/:offerId/accept — seller accepts an offer
router.post('/offer/:offerId/accept', requireAuth, async (req, res) => {
  try {
    const offer = await queryOne("SELECT * FROM marketplace_offers WHERE id=? AND status='pending'", [req.params.offerId]);
    if (!offer) return res.status(404).json({ error: 'Offer not found.' });

    const listing = await queryOne("SELECT * FROM marketplace_listings WHERE id=? AND seller_id=? AND status='active'", [offer.listing_id, req.user.id]);
    if (!listing) return res.status(403).json({ error: 'Not your listing.' });

    const buyer = await queryOne('SELECT cash FROM users WHERE id = ?', [offer.buyer_id]);
    if (buyer.cash < offer.offer_price) return res.status(402).json({ error: 'Buyer no longer has sufficient funds.' });

    const fee       = Math.floor(offer.offer_price * PLATFORM_FEE);
    const sellerGet = offer.offer_price - fee;

    await query('UPDATE users SET cash=cash-? WHERE id=?', [offer.offer_price, offer.buyer_id]);
    await query('UPDATE users SET cash=cash+? WHERE id=?', [sellerGet, req.user.id]);
    await query("UPDATE marketplace_listings SET status='sold', buyer_id=?, sold_at=NOW() WHERE id=?", [offer.buyer_id, listing.id]);
    await query("UPDATE marketplace_offers SET status='accepted' WHERE id=?", [offer.id]);
    await query("UPDATE marketplace_offers SET status='rejected' WHERE listing_id=? AND status='pending'", [listing.id]);
    await query('INSERT IGNORE INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) SELECT ?, weapon_id, weapon_name, weapon_type, ammo FROM weapon_shop WHERE weapon_id=?', [offer.buyer_id, listing.weapon_id]);

    res.json({ message: `Offer accepted. You received $${sellerGet.toLocaleString()}.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to accept offer.' });
  }
});

// DELETE /api/marketplace/:id — cancel listing (returns weapon)
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const listing = await queryOne("SELECT * FROM marketplace_listings WHERE id=? AND seller_id=? AND status='active'", [req.params.id, req.user.id]);
    if (!listing) return res.status(404).json({ error: 'Listing not found.' });

    await query("UPDATE marketplace_listings SET status='cancelled' WHERE id=?", [req.params.id]);
    await query('INSERT IGNORE INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) SELECT ?, weapon_id, weapon_name, weapon_type, ammo FROM weapon_shop WHERE weapon_id=?', [req.user.id, listing.weapon_id]);
    await query("UPDATE marketplace_offers SET status='rejected' WHERE listing_id=? AND status='pending'", [req.params.id]);

    res.json({ message: `${listing.weapon_name} removed from marketplace.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to cancel listing.' });
  }
});

// GET /api/marketplace/my — my listings + offers received
router.get('/my', requireAuth, async (req, res) => {
  try {
    const listings = await query(
      `SELECT ml.*, (SELECT COUNT(*) FROM marketplace_offers mo WHERE mo.listing_id=ml.id AND mo.status='pending') offer_count
       FROM marketplace_listings ml WHERE ml.seller_id=? ORDER BY ml.listed_at DESC LIMIT 20`,
      [req.user.id]
    );
    const offers = await query(
      `SELECT mo.*, ml.weapon_name, ml.price listing_price, u.username buyer_name
       FROM marketplace_offers mo JOIN marketplace_listings ml ON ml.id=mo.listing_id JOIN users u ON u.id=mo.buyer_id
       WHERE ml.seller_id=? AND mo.status='pending' ORDER BY mo.created_at DESC`,
      [req.user.id]
    );
    res.json({ listings, offers });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load your marketplace.' });
  }
});

module.exports = router;
