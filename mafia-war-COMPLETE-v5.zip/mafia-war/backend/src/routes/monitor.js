const router   = require('express').Router();
const os       = require('os');
const { query, queryOne, pool } = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');

// GET /api/monitor/health — live server health (admin only)
router.get('/health', requireAdmin, async (req, res) => {
  try {
    const uptimeSecs  = Math.floor(process.uptime());
    const memUsage    = process.memoryUsage();
    const cpuLoad     = os.loadavg();
    const totalMem    = os.totalmem();
    const freeMem     = os.freemem();
    const usedMemPct  = Math.round(((totalMem - freeMem) / totalMem) * 100);

    // DB metrics
    let dbOk = false;
    try { await pool.query('SELECT 1'); dbOk = true; } catch {}

    // Live game stats
    const [activeRooms]  = await query("SELECT COUNT(*) cnt FROM game_rooms WHERE status = 'active'");
    const [waitingRooms] = await query("SELECT COUNT(*) cnt FROM game_rooms WHERE status = 'waiting'");
    const [totalUsers]   = await query('SELECT COUNT(*) cnt FROM users');
    const [onlineUsers]  = await query("SELECT COUNT(*) cnt FROM users WHERE last_login > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
    const [todaySignups] = await query("SELECT COUNT(*) cnt FROM users WHERE DATE(created_at) = CURDATE()");
    const [revenueToday] = await query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='succeeded' AND DATE(created_at)=CURDATE()");
    const [revenueTotal] = await query("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='succeeded'");
    const [errorsToday]  = await query("SELECT COUNT(*) cnt FROM error_log WHERE level IN ('error','critical') AND DATE(created_at)=CURDATE()");
    const [slowReqs]     = await query("SELECT COUNT(*) cnt FROM request_log WHERE duration_ms >= 2000 AND DATE(created_at)=CURDATE()");
    const [banCount]     = await query("SELECT COUNT(*) cnt FROM ip_bans WHERE expires_at IS NULL OR expires_at > NOW()");

    res.json({
      server: {
        uptime_secs:   uptimeSecs,
        uptime_human:  formatUptime(uptimeSecs),
        node_version:  process.version,
        platform:      os.platform(),
        hostname:      os.hostname(),
      },
      memory: {
        used_mb:    Math.round(memUsage.rss / 1024 / 1024),
        heap_mb:    Math.round(memUsage.heapUsed / 1024 / 1024),
        heap_total: Math.round(memUsage.heapTotal / 1024 / 1024),
        system_pct: usedMemPct,
      },
      cpu: {
        load_1m:  cpuLoad[0].toFixed(2),
        load_5m:  cpuLoad[1].toFixed(2),
        load_15m: cpuLoad[2].toFixed(2),
        cores:    os.cpus().length,
      },
      database: {
        status:    dbOk ? 'connected' : 'error',
      },
      game: {
        active_rooms:  activeRooms.cnt,
        waiting_rooms: waitingRooms.cnt,
        online_players:onlineUsers.cnt,
        total_users:   totalUsers.cnt,
        today_signups: todaySignups.cnt,
      },
      revenue: {
        today_aud:  (revenueToday.total / 100).toFixed(2),
        total_aud:  (revenueTotal.total / 100).toFixed(2),
      },
      errors: {
        today:        errorsToday.cnt,
        slow_requests:slowReqs.cnt,
        ip_bans:      banCount.cnt,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Monitor error.' });
  }
});

// GET /api/monitor/errors — recent error log
router.get('/errors', requireAdmin, async (req, res) => {
  try {
    const { limit = 50, level } = req.query;
    let sql = 'SELECT * FROM error_log';
    const params = [];
    if (level) { sql += ' WHERE level = ?'; params.push(level); }
    sql += ' ORDER BY created_at DESC LIMIT ?';
    params.push(parseInt(limit));
    const errors = await query(sql, params);
    res.json({ errors });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load errors.' });
  }
});

// GET /api/monitor/requests — recent request log
router.get('/requests', requireAdmin, async (req, res) => {
  try {
    const rows = await query(
      'SELECT * FROM request_log ORDER BY created_at DESC LIMIT 100'
    );
    res.json({ requests: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load requests.' });
  }
});

// GET /api/monitor/chat-log — recent chat (admin moderation)
router.get('/chat', requireAdmin, async (req, res) => {
  try {
    const { room_id, limit = 100 } = req.query;
    let sql = `SELECT cl.*, u.username FROM chat_log cl JOIN users u ON u.id = cl.user_id`;
    const params = [];
    if (room_id) { sql += ' WHERE cl.room_id = ?'; params.push(room_id); }
    sql += ' ORDER BY cl.sent_at DESC LIMIT ?';
    params.push(parseInt(limit));
    const chats = await query(sql, params);
    res.json({ chats });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load chat.' });
  }
});

// POST /api/monitor/broadcast — send message to all online players
router.post('/broadcast', requireAdmin, async (req, res) => {
  try {
    const { message, channel = 'global' } = req.body;
    if (!message) return res.status(400).json({ error: 'Message required.' });

    await query('INSERT INTO admin_broadcasts (admin_id, message, channel) VALUES (?,?,?)',
      [req.user.id, message, channel]);

    // Emit via socket to all connected clients
    const io = global._mw_io;
    if (io) {
      io.emit('admin_broadcast', {
        message,
        channel,
        from:     req.user.username,
        ts:       new Date().toISOString(),
      });
    }

    res.json({ message: 'Broadcast sent.', channel });
  } catch (err) {
    res.status(500).json({ error: 'Failed to broadcast.' });
  }
});

function formatUptime(secs) {
  const d = Math.floor(secs / 86400);
  const h = Math.floor((secs % 86400) / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

module.exports = router;
