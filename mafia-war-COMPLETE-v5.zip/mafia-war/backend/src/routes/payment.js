const router = require('express').Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const FRONTEND_URL = process.env.FRONTEND_URL || 'https://mafia.nexusonlinegames.com';

// POST /api/payment/subscribe — create Stripe checkout session
router.post('/subscribe', requireAuth, async (req, res) => {
  try {
    const { plan = 'premium' } = req.body;
    const user = await queryOne('SELECT * FROM users WHERE id = ?', [req.user.id]);

    // Get or create Stripe customer
    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name:  user.username,
        metadata: { user_id: String(user.id), game: 'mafia_war' }
      });
      customerId = customer.id;
      await query('UPDATE users SET stripe_customer_id = ? WHERE id = ?', [customerId, user.id]);
    }

    const priceId = plan === 'premium'
      ? process.env.STRIPE_PREMIUM_PRICE_ID
      : process.env.STRIPE_LICENSE_PRICE_ID;

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      mode: 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${FRONTEND_URL}/payment/cancel`,
      metadata: { user_id: String(user.id), plan }
    });

    res.json({ url: session.url, sessionId: session.id });
  } catch (err) {
    console.error('[PAYMENT] Subscribe error:', err);
    res.status(500).json({ error: 'Failed to create payment session.' });
  }
});

// POST /api/payment/buy-cash — one-time in-game cash purchase
router.post('/buy-cash', requireAuth, async (req, res) => {
  try {
    const PACKS = {
      starter: { amount: 999,  cash: 10000,  label: 'Starter Pack — $10k' },
      soldier: { amount: 2499, cash: 30000,  label: 'Soldier Pack — $30k' },
      boss:    { amount: 4999, cash: 75000,  label: 'Boss Pack — $75k' },
      godfather:{ amount: 9999,cash: 200000, label: 'Godfather Pack — $200k' }
    };
    const { pack = 'starter' } = req.body;
    const selected = PACKS[pack];
    if (!selected) return res.status(400).json({ error: 'Invalid pack.' });

    const user = await queryOne('SELECT stripe_customer_id FROM users WHERE id = ?', [req.user.id]);
    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: req.user.email });
      customerId = customer.id;
      await query('UPDATE users SET stripe_customer_id = ? WHERE id = ?', [customerId, req.user.id]);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'aud',
          product_data: { name: `Mafia War — ${selected.label}` },
          unit_amount: selected.amount
        },
        quantity: 1
      }],
      success_url: `${FRONTEND_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:  `${FRONTEND_URL}/payment/cancel`,
      metadata: { user_id: String(req.user.id), type: 'in_game_cash', pack, cash: String(selected.cash) }
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('[PAYMENT] Buy cash error:', err);
    res.status(500).json({ error: 'Failed to create payment session.' });
  }
});

// POST /api/payment/webhook — Stripe webhook
router.post('/webhook', require('express').raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).json({ error: `Webhook error: ${err.message}` });
  }

  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const userId = parseInt(session.metadata.user_id);

      if (session.metadata.type === 'in_game_cash') {
        const cash = parseInt(session.metadata.cash);
        await query('UPDATE users SET cash = cash + ? WHERE id = ?', [cash, userId]);
        await query(
          'INSERT INTO payments (user_id, stripe_payment_id, stripe_session_id, amount, type, status, description) VALUES (?,?,?,?,?,?,?)',
          [userId, session.payment_intent || session.id, session.id, session.amount_total, 'in_game', 'succeeded', `In-game cash: ${session.metadata.pack}`]
        );
      }

      if (session.mode === 'subscription') {
        await query(
          'UPDATE users SET subscription_status = ?, role = ?, subscription_id = ? WHERE id = ?',
          ['active', 'premium', session.subscription, userId]
        );
        await query(
          'INSERT INTO payments (user_id, stripe_payment_id, stripe_session_id, amount, type, status, description) VALUES (?,?,?,?,?,?,?)',
          [userId, session.subscription, session.id, session.amount_total, 'subscription', 'succeeded', `Premium subscription: ${session.metadata.plan}`]
        );
      }
    }

    if (event.type === 'customer.subscription.deleted') {
      const sub = event.data.object;
      await query(
        "UPDATE users SET subscription_status = 'cancelled', role = 'player' WHERE subscription_id = ?",
        [sub.id]
      );
    }

    if (event.type === 'invoice.payment_failed') {
      const invoice = event.data.object;
      await query(
        "UPDATE users SET subscription_status = 'past_due' WHERE subscription_id = ?",
        [invoice.subscription]
      );
    }

    res.json({ received: true });
  } catch (err) {
    console.error('[WEBHOOK] Error:', err);
    res.status(500).json({ error: 'Webhook processing failed.' });
  }
});

// GET /api/payment/status
router.get('/status', requireAuth, async (req, res) => {
  try {
    const user = await queryOne('SELECT subscription_status, role FROM users WHERE id = ?', [req.user.id]);
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Failed to check payment status.' });
  }
});

module.exports = router;
