const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/player/profile
router.get('/profile', requireAuth, async (req, res) => {
  try {
    const user = await queryOne(
      `SELECT u.id, u.uuid, u.username, u.email, u.role, u.faction, u.rank_level,
              u.xp, u.kills, u.deaths, u.heists_won, u.cash, u.subscription_status,
              u.created_at, u.last_login,
              r.title as rank_title,
              r2.xp_required as next_rank_xp
       FROM users u
       LEFT JOIN rank_definitions r  ON r.level  = u.rank_level
       LEFT JOIN rank_definitions r2 ON r2.level = u.rank_level + 1
       WHERE u.id = ?`,
      [req.user.id]
    );
    const weapons = await query('SELECT * FROM weapons_inventory WHERE user_id = ?', [req.user.id]);
    res.json({ ...user, weapons });
  } catch (err) {
    console.error('[PLAYER] Profile error:', err);
    res.status(500).json({ error: 'Failed to load profile.' });
  }
});

// GET /api/player/stats
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const history = await query(
      `SELECT mh.*, gr.map_id, gr.mode, gr.ended_at
       FROM match_history mh
       JOIN game_rooms gr ON gr.id = mh.room_id
       WHERE mh.user_id = ?
       ORDER BY mh.played_at DESC LIMIT 20`,
      [req.user.id]
    );
    const totals = await queryOne(
      `SELECT SUM(kills) total_kills, SUM(deaths) total_deaths,
              SUM(xp_earned) total_xp, SUM(cash_earned) total_cash,
              COUNT(*) total_matches,
              SUM(outcome='win') wins
       FROM match_history WHERE user_id = ?`,
      [req.user.id]
    );
    res.json({ history, totals });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load stats.' });
  }
});

// GET /api/player/leaderboard
router.get('/leaderboard', requireAuth, async (req, res) => {
  try {
    const { by = 'total_kills', limit = 50 } = req.query;
    const allowed = ['total_kills', 'kd_ratio', 'heists_won', 'total_cash'];
    const col = allowed.includes(by) ? by : 'total_kills';
    const rows = await query(
      `SELECT l.*, r.title rank_title
       FROM leaderboard l
       LEFT JOIN rank_definitions r ON r.level = l.rank_level
       ORDER BY l.${col} DESC LIMIT ?`,
      [parseInt(limit)]
    );
    res.json({ leaderboard: rows, sortedBy: col });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load leaderboard.' });
  }
});

// POST /api/player/faction
router.post('/faction', requireAuth, async (req, res) => {
  try {
    const { faction } = req.body;
    const valid = ['ghost', 'viper', 'iron', 'shadow'];
    if (!valid.includes(faction)) return res.status(400).json({ error: 'Invalid faction.' });

    const user = await queryOne('SELECT faction FROM users WHERE id = ?', [req.user.id]);
    if (user.faction) return res.status(409).json({ error: 'Faction already chosen. Cannot switch.' });

    await query('UPDATE users SET faction = ? WHERE id = ?', [faction, req.user.id]);
    await query('UPDATE leaderboard SET faction = ? WHERE user_id = ?', [faction, req.user.id]);
    res.json({ message: `You have joined the ${faction.toUpperCase()} faction.`, faction });
  } catch (err) {
    res.status(500).json({ error: 'Failed to set faction.' });
  }
});

// GET /api/player/weapons
router.get('/weapons', requireAuth, async (req, res) => {
  try {
    const weapons = await query('SELECT * FROM weapons_inventory WHERE user_id = ?', [req.user.id]);
    res.json({ weapons });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load weapons.' });
  }
});

// GET /api/player/maps
router.get('/maps', requireAuth, async (req, res) => {
  try {
    const maps = await query(
      'SELECT * FROM map_definitions WHERE unlock_rank <= ? ORDER BY unlock_rank',
      [req.user.rank_level]
    );
    res.json({ maps });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load maps.' });
  }
});

module.exports = router;
