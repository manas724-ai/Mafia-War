const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const REFERRER_REWARD = 3000;  // cash for referrer
const REFERRED_REWARD = 1500;  // cash for new player

function genCode(userId) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  const seed = userId * 7919 + Date.now();
  for (let i = 0; i < 8; i++) code += chars[(seed * (i + 1) * 31337) % chars.length];
  return code.substring(0, 8);
}

// GET /api/referral/my — get or create my referral code
router.get('/my', requireAuth, async (req, res) => {
  try {
    let rec = await queryOne('SELECT * FROM referral_codes WHERE user_id = ?', [req.user.id]);
    if (!rec) {
      let code = genCode(req.user.id);
      // Ensure uniqueness
      while (await queryOne('SELECT id FROM referral_codes WHERE code = ?', [code])) {
        code = genCode(req.user.id + Math.random() * 1000);
      }
      await query('INSERT INTO referral_codes (user_id, code) VALUES (?,?)', [req.user.id, code]);
      rec = { user_id: req.user.id, code, uses: 0, total_earned: 0 };
    }

    const referred = await query(
      `SELECT u.username, u.created_at, r.created_at referred_at
       FROM referrals r JOIN users u ON u.id = r.referred_id
       WHERE r.referrer_id = ? ORDER BY r.created_at DESC`,
      [req.user.id]
    );

    res.json({
      code:         rec.code,
      uses:         rec.uses,
      total_earned: rec.total_earned,
      referrer_reward: REFERRER_REWARD,
      referred_reward: REFERRED_REWARD,
      referred_players: referred,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load referral info.' });
  }
});

// POST /api/referral/apply — apply a referral code (called after registration)
router.post('/apply', requireAuth, async (req, res) => {
  try {
    const { code } = req.body;
    if (!code) return res.status(400).json({ error: 'Code required.' });

    // Check already used a code
    const alreadyReferred = await queryOne('SELECT id FROM referrals WHERE referred_id = ?', [req.user.id]);
    if (alreadyReferred) return res.status(409).json({ error: 'You already used a referral code.' });

    const refCode = await queryOne('SELECT * FROM referral_codes WHERE code = ?', [code.toUpperCase()]);
    if (!refCode) return res.status(404).json({ error: 'Invalid referral code.' });
    if (refCode.user_id === req.user.id) return res.status(400).json({ error: 'Cannot refer yourself.' });

    // Pay rewards
    await query('UPDATE users SET cash = cash + ? WHERE id = ?', [REFERRER_REWARD, refCode.user_id]);
    await query('UPDATE users SET cash = cash + ? WHERE id = ?', [REFERRED_REWARD, req.user.id]);

    // Log referral
    await query('INSERT INTO referrals (referrer_id, referred_id, code, reward_paid) VALUES (?,?,?,1)',
      [refCode.user_id, req.user.id, code.toUpperCase()]);

    // Update code stats
    await query('UPDATE referral_codes SET uses = uses + 1, total_earned = total_earned + ? WHERE user_id = ?',
      [REFERRER_REWARD, refCode.user_id]);

    // Check referral achievements
    const refCount = await queryOne('SELECT COUNT(*) cnt FROM referrals WHERE referrer_id = ?', [refCode.user_id]);
    if (refCount.cnt >= 1) await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [refCode.user_id, 'referral_1']).catch(() => {});
    if (refCount.cnt >= 5) await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [refCode.user_id, 'referral_5']).catch(() => {});

    res.json({
      message:         `Referral applied! You received $${REFERRED_REWARD.toLocaleString()} bonus cash.`,
      your_reward:     REFERRED_REWARD,
      referrer_reward: REFERRER_REWARD,
    });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Referral already applied.' });
    res.status(500).json({ error: 'Failed to apply referral code.' });
  }
});

// GET /api/referral/leaderboard — top referrers
router.get('/leaderboard', requireAuth, async (req, res) => {
  try {
    const leaders = await query(
      `SELECT rc.code, rc.uses, rc.total_earned, u.username, u.faction
       FROM referral_codes rc JOIN users u ON u.id = rc.user_id
       WHERE rc.uses > 0
       ORDER BY rc.uses DESC, rc.total_earned DESC
       LIMIT 20`
    );
    res.json({ leaderboard: leaders });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load leaderboard.' });
  }
});

module.exports = router;
