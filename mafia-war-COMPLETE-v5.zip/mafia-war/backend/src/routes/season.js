const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/season/current — get active season with player progress
router.get('/current', requireAuth, async (req, res) => {
  try {
    const season = await queryOne("SELECT * FROM seasons WHERE is_active = 1 ORDER BY starts_at DESC LIMIT 1");
    if (!season) return res.json({ season: null });

    const tiers = await query('SELECT * FROM season_tiers WHERE season_id = ? ORDER BY tier', [season.id]);

    // Get or create player season record
    let playerSeason = await queryOne(
      'SELECT * FROM player_seasons WHERE user_id = ? AND season_id = ?',
      [req.user.id, season.id]
    );
    if (!playerSeason) {
      await query(
        'INSERT INTO player_seasons (user_id, season_id, rewards_claimed) VALUES (?, ?, ?)',
        [req.user.id, season.id, JSON.stringify([])]
      );
      playerSeason = { user_id: req.user.id, season_id: season.id, season_xp: 0, current_tier: 0, has_premium: 0, rewards_claimed: '[]' };
    }

    const claimed = JSON.parse(playerSeason.rewards_claimed || '[]');
    const now     = new Date();
    const daysLeft= Math.max(0, Math.ceil((new Date(season.ends_at) - now) / 86400000));

    res.json({
      season: { ...season, days_left: daysLeft },
      tiers:  tiers.map(t => ({ ...t, claimed: claimed.includes(t.tier) })),
      player: { ...playerSeason, rewards_claimed: claimed },
    });
  } catch (err) {
    console.error('[SEASON] Current error:', err);
    res.status(500).json({ error: 'Failed to load season.' });
  }
});

// POST /api/season/claim/:tier — claim tier reward
router.post('/claim/:tier', requireAuth, async (req, res) => {
  try {
    const tierNum = parseInt(req.params.tier);
    const season  = await queryOne("SELECT * FROM seasons WHERE is_active = 1 LIMIT 1");
    if (!season) return res.status(404).json({ error: 'No active season.' });

    const tier = await queryOne('SELECT * FROM season_tiers WHERE season_id = ? AND tier = ?', [season.id, tierNum]);
    if (!tier)  return res.status(404).json({ error: 'Tier not found.' });

    const ps = await queryOne('SELECT * FROM player_seasons WHERE user_id = ? AND season_id = ?', [req.user.id, season.id]);
    if (!ps) return res.status(404).json({ error: 'Not enrolled in this season.' });

    if (ps.current_tier < tierNum) return res.status(403).json({ error: `Reach tier ${tierNum} first.` });

    const claimed = JSON.parse(ps.rewards_claimed || '[]');
    if (claimed.includes(tierNum)) return res.status(409).json({ error: 'Already claimed.' });

    // Determine reward track
    const isPremium = ps.has_premium === 1;
    const rewardKey = isPremium ? tier.paid_reward : tier.free_reward;

    // Apply reward
    if (tier.reward_type === 'cash' && isPremium) {
      const cashAmt = parseInt(tier.reward_value) || 1000;
      await query('UPDATE users SET cash = cash + ? WHERE id = ?', [cashAmt, req.user.id]);
    } else if (tier.reward_type === 'weapon' && isPremium) {
      // Add weapon to inventory if not already owned
      const weaponId = tier.reward_value;
      const owned = await queryOne('SELECT id FROM weapons_inventory WHERE user_id = ? AND weapon_id = ?', [req.user.id, weaponId]);
      if (!owned) {
        await query(
          "INSERT IGNORE INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) SELECT ?, weapon_id, weapon_name, weapon_type, ammo FROM weapon_shop WHERE weapon_id = ?",
          [req.user.id, weaponId]
        );
      }
    } else if (tier.reward_type === 'cash') {
      // Free track: always give free cash reward
      const cashMatch = tier.free_reward.match(/\$?([\d,]+)/);
      if (cashMatch) {
        const cashAmt = parseInt(cashMatch[1].replace(',',''));
        await query('UPDATE users SET cash = cash + ? WHERE id = ?', [cashAmt, req.user.id]);
      }
    }

    // Mark claimed
    claimed.push(tierNum);
    await query('UPDATE player_seasons SET rewards_claimed = ? WHERE user_id = ? AND season_id = ?',
      [JSON.stringify(claimed), req.user.id, season.id]);

    res.json({ message: `Tier ${tierNum} reward claimed: ${rewardKey}`, reward: rewardKey });
  } catch (err) {
    console.error('[SEASON] Claim error:', err);
    res.status(500).json({ error: 'Failed to claim reward.' });
  }
});

// POST /api/season/buy-premium — upgrade to premium season pass
router.post('/buy-premium', requireAuth, async (req, res) => {
  try {
    const PREMIUM_COST = 5000; // in-game cash
    const season = await queryOne("SELECT * FROM seasons WHERE is_active = 1 LIMIT 1");
    if (!season) return res.status(404).json({ error: 'No active season.' });

    const user = await queryOne('SELECT cash FROM users WHERE id = ?', [req.user.id]);
    if (user.cash < PREMIUM_COST) return res.status(402).json({ error: `Need $${PREMIUM_COST} in-game cash for premium pass.` });

    let ps = await queryOne('SELECT * FROM player_seasons WHERE user_id = ? AND season_id = ?', [req.user.id, season.id]);
    if (!ps) {
      await query('INSERT INTO player_seasons (user_id, season_id, rewards_claimed) VALUES (?,?,?)', [req.user.id, season.id, '[]']);
    }
    if (ps?.has_premium) return res.status(409).json({ error: 'Already have premium pass.' });

    await query('UPDATE users SET cash = cash - ? WHERE id = ?', [PREMIUM_COST, req.user.id]);
    await query('UPDATE player_seasons SET has_premium = 1 WHERE user_id = ? AND season_id = ?', [req.user.id, season.id]);

    res.json({ message: 'Premium Season Pass activated! All premium rewards unlocked.', cost: PREMIUM_COST });
  } catch (err) {
    res.status(500).json({ error: 'Failed to activate premium pass.' });
  }
});

// POST /api/season/add-xp — internal: add season XP (called from game engine)
router.post('/add-xp', requireAuth, async (req, res) => {
  try {
    const { xp } = req.body;
    if (!xp || xp <= 0) return res.status(400).json({ error: 'Invalid XP.' });

    const season = await queryOne("SELECT * FROM seasons WHERE is_active = 1 LIMIT 1");
    if (!season) return res.json({ message: 'No active season.' });

    const tiers = await query('SELECT * FROM season_tiers WHERE season_id = ? ORDER BY tier', [season.id]);

    let ps = await queryOne('SELECT * FROM player_seasons WHERE user_id = ? AND season_id = ?', [req.user.id, season.id]);
    if (!ps) {
      await query('INSERT INTO player_seasons (user_id, season_id, season_xp, rewards_claimed) VALUES (?,?,?,?)', [req.user.id, season.id, 0, '[]']);
      ps = { season_xp: 0, current_tier: 0 };
    }

    const newXp = ps.season_xp + xp;
    let newTier = ps.current_tier;
    tiers.forEach(t => { if (newXp >= t.xp_required && t.tier > newTier) newTier = t.tier; });

    await query('UPDATE player_seasons SET season_xp = ?, current_tier = ? WHERE user_id = ? AND season_id = ?',
      [newXp, newTier, req.user.id, season.id]);

    res.json({ season_xp: newXp, current_tier: newTier, tier_up: newTier > ps.current_tier });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add season XP.' });
  }
});

module.exports = router;
