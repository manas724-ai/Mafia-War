const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');

// GET /api/season/hall-of-fame
router.get('/hall-of-fame', async (req, res) => {
  try {
    const { season_id } = req.query;
    let rows;
    if (season_id) {
      rows = await query('SELECT * FROM season_hall_of_fame WHERE season_id = ? ORDER BY rank', [season_id]);
    } else {
      rows = await query('SELECT * FROM season_hall_of_fame ORDER BY archived_at DESC, rank LIMIT 100');
    }
    res.json({ hall_of_fame: rows });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load hall of fame.' });
  }
});

// POST /api/season/reset — admin: end current season, archive results, start new season
router.post('/reset', requireAdmin, async (req, res) => {
  try {
    const { new_season_name, new_season_theme } = req.body;

    // Get current season
    const current = await queryOne("SELECT * FROM seasons WHERE is_active = 1 LIMIT 1");
    if (!current) return res.status(404).json({ error: 'No active season.' });

    // Archive top players into hall of fame
    const topPlayers = await query(`
      SELECT ps.user_id, u.username, u.faction, ps.current_tier, ps.season_xp,
             u.kills total_kills, u.heists_won,
             ROW_NUMBER() OVER (ORDER BY ps.season_xp DESC) AS rank_num
      FROM player_seasons ps
      JOIN users u ON u.id = ps.user_id
      WHERE ps.season_id = ?
      ORDER BY ps.season_xp DESC
      LIMIT 100
    `, [current.id]);

    for (const p of topPlayers) {
      await query(
        'INSERT INTO season_hall_of_fame (season_id, season_name, user_id, username, faction, final_tier, total_kills, heists_won, season_xp, rank) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [current.id, current.name, p.user_id, p.username, p.faction, p.current_tier, p.total_kills, p.heists_won, p.season_xp, p.rank_num]
      );
    }

    // Award Season Champion badge to top player
    if (topPlayers.length > 0) {
      const champ = topPlayers[0];
      await query(
        'INSERT IGNORE INTO player_cosmetics (user_id, cosmetic_id) VALUES (?, ?)',
        [champ.user_id, 'badge_season_champ']
      ).catch(() => {});
    }

    // End current season
    await query("UPDATE seasons SET is_active = 0, ends_at = NOW() WHERE id = ?", [current.id]);

    // Create new season if name provided
    let newSeason = null;
    if (new_season_name) {
      const result = await query(
        'INSERT INTO seasons (name, theme, starts_at, ends_at, is_active) VALUES (?,?,NOW(),DATE_ADD(NOW(),INTERVAL 90 DAY),1)',
        [new_season_name, new_season_theme || 'New Season']
      );
      newSeason = result.insertId;

      // Seed tiers for new season (copy from season 1 template)
      const tiers = await query('SELECT * FROM season_tiers WHERE season_id = 1 ORDER BY tier');
      for (const t of tiers) {
        await query(
          'INSERT INTO season_tiers (season_id, tier, xp_required, free_reward, paid_reward, reward_type, reward_value) VALUES (?,?,?,?,?,?,?)',
          [newSeason, t.tier, t.xp_required, t.free_reward, t.paid_reward, t.reward_type, t.reward_value]
        ).catch(() => {});
      }
    }

    // Reset weekly faction standings
    await query('DELETE FROM faction_standings WHERE week_start < DATE_SUB(NOW(), INTERVAL 90 DAY)');

    res.json({
      message:       `Season "${current.name}" ended. ${topPlayers.length} players archived.`,
      champion:      topPlayers[0]?.username || null,
      new_season_id: newSeason,
    });
  } catch (err) {
    console.error('[SEASON] Reset error:', err);
    res.status(500).json({ error: 'Failed to reset season.' });
  }
});

// GET /api/season/weekly-reset — auto weekly leaderboard reset (called by cron)
router.post('/weekly-reset', requireAdmin, async (req, res) => {
  try {
    // Archive current week's faction standings
    const week = new Date();
    week.setDate(week.getDate() - 7);
    const weekStr = week.toISOString().split('T')[0];

    // Get weekly champion faction
    const [topFaction] = await query(
      'SELECT faction, total_kills FROM faction_standings WHERE week_start = ? ORDER BY total_kills DESC LIMIT 1',
      [weekStr]
    );

    // Clear old weeks (keep last 12 weeks)
    await query('DELETE FROM faction_standings WHERE week_start < DATE_SUB(NOW(), INTERVAL 84 DAY)');

    res.json({
      message:         'Weekly reset complete.',
      weekly_champion: topFaction?.faction || null,
      week:            weekStr,
    });
  } catch (err) {
    res.status(500).json({ error: 'Weekly reset failed.' });
  }
});

module.exports = router;
