const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/shop/weapons — list all weapons with ownership status
router.get('/weapons', requireAuth, async (req, res) => {
  try {
    const owned = await query(
      'SELECT weapon_id FROM weapons_inventory WHERE user_id = ?',
      [req.user.id]
    );
    const ownedSet = new Set(owned.map(w => w.weapon_id));

    const weapons = await query(
      'SELECT * FROM weapon_shop ORDER BY unlock_rank, price_cash'
    );

    const user = await queryOne('SELECT cash, rank_level FROM users WHERE id = ?', [req.user.id]);

    res.json({
      weapons: weapons.map(w => ({
        ...w,
        owned:    ownedSet.has(w.weapon_id),
        can_buy:  !ownedSet.has(w.weapon_id) && user.cash >= w.price_cash && user.rank_level >= w.unlock_rank,
        locked:   user.rank_level < w.unlock_rank,
      })),
      cash: user.cash,
      rank: user.rank_level,
    });
  } catch (err) {
    console.error('[SHOP] List weapons error:', err);
    res.status(500).json({ error: 'Failed to load weapon shop.' });
  }
});

// POST /api/shop/buy — purchase weapon with in-game cash
router.post('/buy', requireAuth, async (req, res) => {
  try {
    const { weapon_id } = req.body;
    if (!weapon_id) return res.status(400).json({ error: 'weapon_id required.' });

    const weapon = await queryOne('SELECT * FROM weapon_shop WHERE weapon_id = ?', [weapon_id]);
    if (!weapon) return res.status(404).json({ error: 'Weapon not found.' });

    const user = await queryOne('SELECT cash, rank_level FROM users WHERE id = ?', [req.user.id]);
    if (!user) return res.status(404).json({ error: 'User not found.' });

    if (user.rank_level < weapon.unlock_rank) {
      return res.status(403).json({ error: `Rank ${weapon.unlock_rank} required to unlock ${weapon.weapon_name}.` });
    }
    if (weapon.price_cash === 0) {
      return res.status(400).json({ error: 'This weapon is issued for free — check your inventory.' });
    }

    const existing = await queryOne(
      'SELECT id FROM weapons_inventory WHERE user_id = ? AND weapon_id = ?',
      [req.user.id, weapon_id]
    );
    if (existing) return res.status(409).json({ error: 'You already own this weapon.' });

    if (user.cash < weapon.price_cash) {
      return res.status(402).json({
        error: `Insufficient funds. You need $${weapon.price_cash.toLocaleString()}, you have $${user.cash.toLocaleString()}.`
      });
    }

    // Deduct cash and add weapon
    await query('UPDATE users SET cash = cash - ? WHERE id = ?', [weapon.price_cash, req.user.id]);
    await query(
      'INSERT INTO weapons_inventory (user_id, weapon_id, weapon_name, weapon_type, ammo) VALUES (?, ?, ?, ?, ?)',
      [req.user.id, weapon.weapon_id, weapon.weapon_name, weapon.weapon_type, weapon.ammo]
    );

    const newCash = user.cash - weapon.price_cash;
    res.json({
      message:    `${weapon.weapon_name} acquired.`,
      weapon_id:  weapon.weapon_id,
      cash_spent: weapon.price_cash,
      cash_left:  newCash,
    });
  } catch (err) {
    console.error('[SHOP] Buy weapon error:', err);
    res.status(500).json({ error: 'Failed to purchase weapon.' });
  }
});

// GET /api/shop/faction — faction standings leaderboard
router.get('/faction', requireAuth, async (req, res) => {
  try {
    // Current week standings
    const standings = await query(`
      SELECT faction,
        SUM(u.kills)       total_kills,
        COUNT(u.id)        total_members,
        AVG(u.rank_level)  avg_rank,
        SUM(u.heists_won)  total_heists,
        SUM(u.cash)        total_cash
      FROM users u
      WHERE u.faction IS NOT NULL AND u.is_banned = 0
      GROUP BY u.faction
      ORDER BY total_kills DESC
    `);
    res.json({ standings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load faction standings.' });
  }
});

module.exports = router;
