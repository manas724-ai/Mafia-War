const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

// GET /api/spectate/rooms — list rooms available to spectate
router.get('/rooms', requireAuth, async (req, res) => {
  try {
    const rooms = await query(`
      SELECT gr.room_code, gr.name, gr.map_id, gr.mode, gr.current_players,
             gr.max_players, gr.started_at, u.username host_name
      FROM game_rooms gr
      LEFT JOIN users u ON u.id = gr.host_id
      WHERE gr.status = 'active'
      ORDER BY gr.current_players DESC LIMIT 20
    `);
    res.json({ rooms });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load spectatable rooms.' });
  }
});

// POST /api/spectate/join/:code — log spectator session start
router.post('/join/:code', requireAuth, async (req, res) => {
  try {
    const room = await queryOne("SELECT * FROM game_rooms WHERE room_code = ? AND status = 'active'", [req.params.code]);
    if (!room) return res.status(404).json({ error: 'Room not active.' });

    await query('INSERT INTO spectator_sessions (user_id, room_id) VALUES (?, ?)', [req.user.id, room.id]);
    res.json({ message: 'Spectating.', room_code: req.params.code });
  } catch (err) {
    res.status(500).json({ error: 'Failed to join spectator.' });
  }
});

module.exports = router;
