const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAuth, requireAdmin } = require('../middleware/auth');

// ── HELPERS ───────────────────────────────────────────────────
function genCode() { return Math.random().toString(36).substring(2, 10).toUpperCase(); }

function buildBracket(participants) {
  // Power-of-2 bracket — pad with byes if needed
  const count = participants.length;
  const size  = Math.pow(2, Math.ceil(Math.log2(count)));
  const seeded = [...participants];
  while (seeded.length < size) seeded.push(null); // bye slots

  const matches = [];
  for (let i = 0; i < size / 2; i++) {
    matches.push({
      round:     1,
      match_num: i + 1,
      player1_id: seeded[i * 2]?.user_id || null,
      player2_id: seeded[i * 2 + 1]?.user_id || null,
      // Auto-advance if bye
      winner_id: !seeded[i * 2] ? seeded[i * 2 + 1]?.user_id : !seeded[i * 2 + 1] ? seeded[i * 2]?.user_id : null,
    });
  }
  return { matches, rounds: Math.log2(size), size };
}

// GET /api/tournament — list tournaments
router.get('/', requireAuth, async (req, res) => {
  try {
    const { status } = req.query;
    let sql = `SELECT t.*, u.username creator_name,
      (SELECT COUNT(*) FROM tournament_participants tp WHERE tp.tournament_id = t.id) participant_count
      FROM tournaments t JOIN users u ON u.id = t.created_by`;
    const params = [];
    if (status) { sql += ' WHERE t.status = ?'; params.push(status); }
    sql += ' ORDER BY t.created_at DESC LIMIT 30';
    const tournaments = await query(sql, params);
    res.json({ tournaments });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load tournaments.' });
  }
});

// GET /api/tournament/:id — full tournament with bracket
router.get('/:id', requireAuth, async (req, res) => {
  try {
    const t = await queryOne(
      `SELECT t.*, u.username creator_name FROM tournaments t JOIN users u ON u.id = t.created_by WHERE t.id = ?`,
      [req.params.id]
    );
    if (!t) return res.status(404).json({ error: 'Tournament not found.' });

    const participants = await query(
      `SELECT tp.*, u.username, u.faction, u.rank_level FROM tournament_participants tp JOIN users u ON u.id = tp.user_id WHERE tp.tournament_id = ? ORDER BY tp.seed`,
      [req.params.id]
    );
    const matches = await query(
      `SELECT tm.*,
        u1.username player1_name, u2.username player2_name, uw.username winner_name
       FROM tournament_matches tm
       LEFT JOIN users u1 ON u1.id = tm.player1_id
       LEFT JOIN users u2 ON u2.id = tm.player2_id
       LEFT JOIN users uw ON uw.id = tm.winner_id
       WHERE tm.tournament_id = ? ORDER BY tm.round, tm.match_num`,
      [req.params.id]
    );

    const myEntry = participants.find(p => p.user_id === req.user.id);
    res.json({ tournament: t, participants, matches, my_entry: myEntry || null });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load tournament.' });
  }
});

// POST /api/tournament — create tournament (admin or rank 8+)
router.post('/', requireAuth, async (req, res) => {
  try {
    const { name, mode = 'deathmatch', map_id = 'downtown', max_players = 16, entry_fee = 0 } = req.body;
    if (!name) return res.status(400).json({ error: 'Tournament name required.' });
    if (!['admin','owner'].includes(req.user.role) && req.user.rank_level < 8)
      return res.status(403).json({ error: 'Rank 8+ or admin required to create tournaments.' });

    const validSizes = [4, 8, 16, 32];
    const size = validSizes.includes(parseInt(max_players)) ? parseInt(max_players) : 16;

    const result = await query(
      'INSERT INTO tournaments (name, mode, map_id, max_players, entry_fee, created_by) VALUES (?,?,?,?,?,?)',
      [name, mode, map_id, size, Math.max(0, parseInt(entry_fee) || 0), req.user.id]
    );
    const t = await queryOne('SELECT * FROM tournaments WHERE id = ?', [result.insertId]);
    res.status(201).json({ tournament: t });
  } catch (err) {
    console.error('[TOURNAMENT] Create error:', err);
    res.status(500).json({ error: 'Failed to create tournament.' });
  }
});

// POST /api/tournament/:id/join
router.post('/:id/join', requireAuth, async (req, res) => {
  try {
    const t = await queryOne("SELECT * FROM tournaments WHERE id = ? AND status = 'open'", [req.params.id]);
    if (!t) return res.status(404).json({ error: 'Tournament not found or not open.' });

    const count = await queryOne('SELECT COUNT(*) cnt FROM tournament_participants WHERE tournament_id = ?', [req.params.id]);
    if (count.cnt >= t.max_players) return res.status(409).json({ error: 'Tournament is full.' });

    if (t.entry_fee > 0) {
      const user = await queryOne('SELECT cash FROM users WHERE id = ?', [req.user.id]);
      if (user.cash < t.entry_fee) return res.status(402).json({ error: `Need $${t.entry_fee} entry fee.` });
      await query('UPDATE users SET cash = cash - ? WHERE id = ?', [t.entry_fee, req.user.id]);
      await query('UPDATE tournaments SET prize_pool = prize_pool + ? WHERE id = ?', [t.entry_fee, req.params.id]);
    }

    await query('INSERT INTO tournament_participants (tournament_id, user_id) VALUES (?,?)', [req.params.id, req.user.id]);
    const newCount = count.cnt + 1;

    // Auto-seed when full
    if (newCount >= t.max_players) {
      await seedTournament(req.params.id, t.max_players);
    }

    res.json({ message: 'Joined tournament.', participant_count: newCount });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Already registered.' });
    res.status(500).json({ error: 'Failed to join tournament.' });
  }
});

// POST /api/tournament/:id/seed — admin: manually seed and generate bracket
router.post('/:id/seed', requireAdmin, async (req, res) => {
  try {
    const t = await queryOne("SELECT * FROM tournaments WHERE id = ?", [req.params.id]);
    if (!t) return res.status(404).json({ error: 'Tournament not found.' });

    const participants = await query(
      'SELECT tp.user_id, u.rank_level, u.kills FROM tournament_participants tp JOIN users u ON u.id = tp.user_id WHERE tp.tournament_id = ?',
      [req.params.id]
    );
    if (participants.length < 2) return res.status(400).json({ error: 'Need at least 2 participants.' });

    await seedTournament(req.params.id, t.max_players, participants);
    res.json({ message: 'Tournament seeded and bracket generated.', participants: participants.length });
  } catch (err) {
    res.status(500).json({ error: 'Failed to seed tournament.' });
  }
});

// POST /api/tournament/:id/match/:matchId/result — report match result
router.post('/:id/match/:matchId/result', requireAuth, async (req, res) => {
  try {
    const { winner_id } = req.body;
    if (!winner_id) return res.status(400).json({ error: 'winner_id required.' });

    const match = await queryOne(
      "SELECT * FROM tournament_matches WHERE id = ? AND tournament_id = ? AND status != 'complete'",
      [req.params.matchId, req.params.id]
    );
    if (!match) return res.status(404).json({ error: 'Match not found or already complete.' });

    // Verify winner is a participant
    if (![match.player1_id, match.player2_id].includes(parseInt(winner_id)))
      return res.status(400).json({ error: 'Winner must be a participant of this match.' });

    // Mark match complete
    await query(
      "UPDATE tournament_matches SET winner_id=?, status='complete', completed_at=NOW() WHERE id=?",
      [winner_id, req.params.matchId]
    );

    // Eliminate loser
    const loserId = parseInt(winner_id) === match.player1_id ? match.player2_id : match.player1_id;
    if (loserId) await query('UPDATE tournament_participants SET eliminated=1 WHERE tournament_id=? AND user_id=?', [req.params.id, loserId]);

    // Advance winner in bracket
    await advanceWinner(req.params.id, match.round, match.match_num, winner_id);

    // Check if tournament is complete
    const remaining = await queryOne(
      'SELECT COUNT(*) cnt FROM tournament_matches WHERE tournament_id=? AND round=(SELECT MAX(round) FROM tournament_matches WHERE tournament_id=?) AND status!="complete"',
      [req.params.id, req.params.id]
    );

    if (remaining.cnt === 0) {
      await finalizeTournament(req.params.id, winner_id);
    }

    res.json({ message: 'Match result recorded.', winner_id, loser_id: loserId });
  } catch (err) {
    console.error('[TOURNAMENT] Result error:', err);
    res.status(500).json({ error: 'Failed to record result.' });
  }
});

// ── INTERNAL HELPERS ──────────────────────────────────────────
async function seedTournament(tournamentId, maxPlayers, participants) {
  if (!participants) {
    participants = await query(
      'SELECT tp.user_id, u.rank_level, u.kills FROM tournament_participants tp JOIN users u ON u.id = tp.user_id WHERE tp.tournament_id = ?',
      [tournamentId]
    );
  }

  // Seed by rank then kills (highest first)
  const sorted = [...participants].sort((a, b) => b.rank_level - a.rank_level || b.kills - a.kills);
  for (let i = 0; i < sorted.length; i++) {
    await query('UPDATE tournament_participants SET seed=? WHERE tournament_id=? AND user_id=?', [i + 1, tournamentId, sorted[i].user_id]);
  }

  const { matches } = buildBracket(sorted);
  for (const m of matches) {
    await query(
      'INSERT INTO tournament_matches (tournament_id, round, match_num, player1_id, player2_id, winner_id) VALUES (?,?,?,?,?,?)',
      [tournamentId, m.round, m.match_num, m.player1_id, m.player2_id, m.winner_id || null]
    );
  }

  await query("UPDATE tournaments SET status='seeded' WHERE id=?", [tournamentId]);
}

async function advanceWinner(tournamentId, completedRound, matchNum, winnerId) {
  const nextRound = completedRound + 1;
  const nextMatch = Math.ceil(matchNum / 2);
  const isPlayer1 = matchNum % 2 === 1;

  const existing = await queryOne(
    'SELECT * FROM tournament_matches WHERE tournament_id=? AND round=? AND match_num=?',
    [tournamentId, nextRound, nextMatch]
  );

  if (existing) {
    const field = isPlayer1 ? 'player1_id' : 'player2_id';
    await query(`UPDATE tournament_matches SET ${field}=? WHERE id=?`, [winnerId, existing.id]);
  } else {
    // Create next round match
    const p1 = isPlayer1 ? winnerId : null;
    const p2 = isPlayer1 ? null : winnerId;
    await query(
      'INSERT INTO tournament_matches (tournament_id, round, match_num, player1_id, player2_id) VALUES (?,?,?,?,?)',
      [tournamentId, nextRound, nextMatch, p1, p2]
    );
  }
}

async function finalizeTournament(tournamentId, winnerId) {
  const t = await queryOne('SELECT * FROM tournaments WHERE id=?', [tournamentId]);
  if (!t) return;

  // Prize distribution: 60% winner, 30% runner-up, 10% semis
  const prize = t.prize_pool;
  const winnerPrize = Math.floor(prize * 0.6);
  if (winnerId && winnerPrize > 0) {
    await query('UPDATE users SET cash=cash+? WHERE id=?', [winnerPrize, winnerId]);
    await query('UPDATE tournament_participants SET prize_earned=? WHERE tournament_id=? AND user_id=?', [winnerPrize, tournamentId, winnerId]);
  }

  await query("UPDATE tournaments SET status='complete', winner_id=?, ended_at=NOW() WHERE id=?", [winnerId, tournamentId]);

  // Grant achievement
  await query('INSERT IGNORE INTO player_achievements (user_id, achievement_id) VALUES (?,?)', [winnerId, 'tournament_win']).catch(() => {});
  await query('UPDATE users SET cash=cash+50000 WHERE id=?', [winnerId]).catch(() => {});
}

module.exports = router;
