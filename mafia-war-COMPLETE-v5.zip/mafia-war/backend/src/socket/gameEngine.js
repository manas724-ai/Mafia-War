const { query, queryOne } = require('../db/pool');
let checkAchievements = null;
try { checkAchievements = require('../routes/achievements').checkAchievements; } catch(e) {}
const { verifyToken } = require('../middleware/auth');

const WEAPONS = {
  pistol_basic:      { name: 'Glock 17',      damage: 25,  firerate: 400,  range: 300, ammo: 15,  type: 'pistol',    spread: 0.05 },
  pistol_desert:     { name: 'Desert Eagle',  damage: 55,  firerate: 600,  range: 350, ammo: 7,   type: 'pistol',    spread: 0.08 },
  smg_micro:         { name: 'Micro SMG',     damage: 18,  firerate: 100,  range: 200, ammo: 30,  type: 'smg',       spread: 0.15 },
  smg_mp5:           { name: 'MP5',           damage: 22,  firerate: 120,  range: 250, ammo: 30,  type: 'smg',       spread: 0.10 },
  shotgun_pump:      { name: 'Pump Shotgun',  damage: 80,  firerate: 800,  range: 100, ammo: 8,   type: 'shotgun',   spread: 0.30 },
  shotgun_auto:      { name: 'Auto Shotgun',  damage: 60,  firerate: 400,  range: 120, ammo: 10,  type: 'shotgun',   spread: 0.25 },
  rifle_ak:          { name: 'AK-47',         damage: 35,  firerate: 150,  range: 400, ammo: 30,  type: 'rifle',     spread: 0.07 },
  rifle_m16:         { name: 'M16',           damage: 30,  firerate: 130,  range: 450, ammo: 30,  type: 'rifle',     spread: 0.05 },
  sniper_basic:      { name: 'Sniper Rifle',  damage: 120, firerate: 1500, range: 900, ammo: 5,   type: 'sniper',    spread: 0.01 },
  explosive_grenade: { name: 'Grenade',       damage: 150, firerate: 2000, range: 200, ammo: 3,   type: 'explosive', spread: 0    },
  special_minigun:   { name: 'Minigun',       damage: 20,  firerate: 80,   range: 300, ammo: 100, type: 'special',   spread: 0.20 },
  special_rocket:    { name: 'RPG',           damage: 250, firerate: 3000, range: 600, ammo: 2,   type: 'special',   spread: 0    },
};

const BANKS = {
  federal_bank: { vault: 500000, time: 300, phases: ['breach','hack','secure','extract'], guards: 8,  xp: 500 },
  casino_vault: { vault: 350000, time: 240, phases: ['breach','hack','extract'],          guards: 6,  xp: 400 },
  armoured_car: { vault: 150000, time: 180, phases: ['breach','secure','extract'],        guards: 4,  xp: 300 },
};

const TERRITORY_ZONES    = ['Alpha','Bravo','Charlie','Delta'];
const ZONE_CAPTURE_TIME  = 10;
const TERRITORY_WIN_PTS  = 100;
const RANK_XP = [0,500,1500,3500,7000,13000,22000,35000,55000,80000,115000,160000,220000,300000,420000];
const RANK_TITLES = ['','Street Rat','Thug','Runner','Enforcer','Soldier','Made Man','Lieutenant','Capo','Underboss','Consigliere','Boss','Don','Crime Lord','Kingpin','Godfather'];

const rooms       = new Map();
const userSockets = new Map();

function createRoomState(roomData) {
  return {
    id: roomData.id, code: roomData.room_code, name: roomData.name,
    map_id: roomData.map_id, mode: roomData.mode, maxPlayers: roomData.max_players,
    status: 'waiting', players: new Map(), startedAt: null,
    timer: null, heist: null, territory: initTerritory(), guards: [], matchTimer: null,
  };
}

function initTerritory() {
  const t = {};
  TERRITORY_ZONES.forEach(z => {
    t[z] = { owner: null, progress: 0, capturer: null, points: { ghost:0, viper:0, iron:0, shadow:0 } };
  });
  return t;
}

function createPlayerState(user, socketId, weapon) {
  const spawns = [{x:100,y:100},{x:700,y:100},{x:100,y:500},{x:700,y:500},{x:400,y:300},{x:200,y:400},{x:600,y:200},{x:350,y:150}];
  const spawn = spawns[Math.floor(Math.random() * spawns.length)];
  const wp = WEAPONS[weapon] || WEAPONS.pistol_basic;
  return {
    userId: user.id, socketId, username: user.username, faction: user.faction || 'ghost',
    rank: user.rank_level, x: spawn.x, y: spawn.y, hp: 100, maxHp: 100,
    kills: 0, deaths: 0, assists: 0, xpEarned: 0, cashEarned: 0,
    weapon: wp, weaponId: weapon, ammo: wp.ammo, reserveAmmo: wp.ammo * 3,
    lastShot: 0, isAlive: true, respawnAt: null, killStreak: 0, inZone: null,
    heistPhasesDone: [], angle: 0,
  };
}

function createGuard(mapId, index) {
  const spawns = {
    federal_bank: [{x:400,y:100},{x:600,y:200},{x:200,y:300},{x:500,y:400},{x:300,y:150},{x:650,y:350},{x:150,y:450},{x:450,y:500}],
    casino_vault: [{x:300,y:120},{x:500,y:150},{x:200,y:300},{x:600,y:280},{x:400,y:420},{x:350,y:200}],
    armoured_car: [{x:250,y:200},{x:450,y:200},{x:350,y:350},{x:550,y:350}],
  };
  const sp = (spawns[mapId] || spawns.federal_bank)[index % (spawns[mapId] || spawns.federal_bank).length];
  return { id:`guard_${index}`, x:sp.x, y:sp.y, hp:60, maxHp:60, isAlive:true, patrolX:sp.x, patrolY:sp.y, aggroTarget:null, lastShot:0, firerate:1200, damage:20, range:180, angle:0 };
}

function getZoneBounds(zone) {
  return { Alpha:{x:60,y:60,w:120,h:100}, Bravo:{x:620,y:60,w:120,h:100}, Charlie:{x:60,y:440,w:120,h:100}, Delta:{x:620,y:440,w:120,h:100} }[zone] || {x:60,y:60,w:120,h:100};
}

function calcDamage(weapon, sx, sy, tx, ty) {
  const dist = Math.hypot(tx-sx, ty-sy);
  const falloff = Math.max(0.3, 1-(dist/weapon.range));
  return Math.round(weapon.damage * falloff);
}

function calcRank(xp) {
  let rank = 1;
  for(let i=RANK_XP.length-1;i>=0;i--){if(xp>=RANK_XP[i]){rank=i+1;break;}}
  return Math.min(rank,15);
}

function getWeekStart() {
  const d=new Date(); d.setDate(d.getDate()-d.getDay()); return d.toISOString().split('T')[0];
}

function serializePlayers(room) {
  const out=[];
  room.players.forEach(p=>out.push({socketId:p.socketId,username:p.username,faction:p.faction,rank:p.rank,x:p.x,y:p.y,hp:p.hp,isAlive:p.isAlive,kills:p.kills,deaths:p.deaths,weaponType:p.weapon.type,angle:p.angle||0,inZone:p.inZone,killStreak:p.killStreak}));
  return out;
}

function serializeTerritory(territory) {
  const out={};
  Object.entries(territory).forEach(([zone,z])=>{out[zone]={owner:z.owner,progress:Math.round(z.progress),capturer:z.capturer,bounds:getZoneBounds(zone)};});
  return out;
}

function serializeGuards(guards) {
  return guards.map(g=>({id:g.id,x:g.x,y:g.y,hp:g.hp,maxHp:g.maxHp,isAlive:g.isAlive,angle:g.angle||0,aggroTarget:g.aggroTarget}));
}

async function handlePlayerKill(io, room, room_code, killer, victim, killerSocket) {
  victim.hp=0; victim.isAlive=false; victim.deaths++;
  if(killer.socketId!=='guard'){
    killer.kills++; killer.killStreak++;
    const streakBonus=killer.killStreak>=5?100:killer.killStreak>=3?50:0;
    killer.xpEarned+=50+streakBonus; killer.cashEarned+=500+(streakBonus*2);
    if(killerSocket) killerSocket.emit('stats_update',{kills:killer.kills,xp:killer.xpEarned,cash:killer.cashEarned,ammo:killer.ammo,killStreak:killer.killStreak});
  }
  victim.killStreak=0;
  io.to(room_code).emit('player_killed',{killerId:killer.socketId,killerName:killer.username,killerFaction:killer.faction,victimId:victim.socketId,victimName:victim.username,weapon:killer.weapon?.name||'Guard',killerKills:killer.kills,killStreak:killer.killStreak});
  const vs=io.sockets?.sockets?.get(victim.socketId);
  if(vs) vs.emit('you_died',{killedBy:killer.username,respawnIn:5});
  setTimeout(()=>{
    if(!room.players.has(victim.socketId)) return;
    const sp=[{x:100,y:100},{x:700,y:100},{x:100,y:500},{x:700,y:500}][Math.floor(Math.random()*4)];
    victim.x=sp.x; victim.y=sp.y; victim.hp=100; victim.isAlive=true; victim.ammo=victim.weapon.ammo;
    if(vs) vs.emit('respawned',{x:sp.x,y:sp.y,hp:100,ammo:victim.ammo});
    io.to(room_code).emit('player_respawned',{socketId:victim.socketId,x:sp.x,y:sp.y});
  },5000);
}

async function completeHeist(io, room, room_code, success) {
  if(!room.heist) return;
  const bank=BANKS[room.heist.bank_id];
  if(!bank) return;
  await query("UPDATE heist_missions SET status=?,completed_at=NOW() WHERE id=?",[success?'success':'failed',room.heist.id]).catch(()=>{});
  if(success){
    const living=[...room.players.values()].filter(p=>p.isAlive);
    const share=living.length>0?Math.floor(bank.vault/living.length):0;
    for(const p of living){
      p.xpEarned+=bank.xp; p.cashEarned+=share;
      await query('UPDATE users SET cash=cash+?,heists_won=heists_won+1 WHERE id=?',[share,p.userId]).catch(()=>{});
      const ps=io.sockets?.sockets?.get(p.socketId);
      if(ps) ps.emit('heist_loot',{share,xp:bank.xp});
    }
    io.to(room_code).emit('heist_complete',{success:true,vault:bank.vault,share,message:`Heist complete! Each crew member receives $${share.toLocaleString()}.`});
  } else {
    io.to(room_code).emit('heist_complete',{success:false,message:'Heist failed. Time ran out.'});
  }
  setTimeout(()=>endMatch(io,room_code),5000);
}

function cleanupRoom(room) {
  if(room.matchTimer) clearTimeout(room.matchTimer);
  if(room.timer) clearTimeout(room.timer);
}

function startCountdown(io, room_code) {
  const room=rooms.get(room_code);
  if(!room||room.status!=='waiting') return;
  room.status='countdown';
  let count=5;
  io.to(room_code).emit('countdown',{seconds:count});
  const tick=setInterval(()=>{
    count--;
    if(count<=0){clearInterval(tick);startMatch(io,room_code);}
    else io.to(room_code).emit('countdown',{seconds:count});
  },1000);
}

async function startMatch(io, room_code) {
  const room=rooms.get(room_code);
  if(!room) return;
  room.status='active'; room.startedAt=Date.now();
  if(room.mode==='heist'){
    const bank=BANKS[room.map_id]||BANKS.federal_bank;
    room.guards=Array.from({length:bank.guards},(_,i)=>createGuard(room.map_id,i));
    const roomRow=await queryOne('SELECT id FROM game_rooms WHERE room_code=?',[room_code]);
    if(roomRow){
      const res=await query('INSERT INTO heist_missions (room_id,bank_id,vault_amount,time_limit,status,started_at) VALUES (?,?,?,?,?,NOW())',[roomRow.id,room.map_id,bank.vault,bank.time,'active']).catch(()=>null);
      if(res) room.heist={id:res.insertId,bank_id:room.map_id,phasesDone:[]};
    }
  }
  await query("UPDATE game_rooms SET status='active',started_at=NOW() WHERE room_code=?",[room_code]);
  const duration=room.mode==='heist'?(BANKS[room.map_id]?.time||300)*1000:room.mode==='territory'?600000:480000;
  io.to(room_code).emit('match_started',{mode:room.mode,map_id:room.map_id,players:serializePlayers(room),territory:serializeTerritory(room.territory),guards:serializeGuards(room.guards),duration:duration/1000});
  room.matchTimer=setTimeout(()=>{
    if(room.mode==='heist'&&room.heist) completeHeist(io,room,room_code,false);
    else endMatch(io,room_code);
  },duration);
}

async function endMatch(io, room_code, winningFaction=null) {
  const room=rooms.get(room_code);
  if(!room||room.status==='ended') return;
  room.status='ended';
  if(room.matchTimer) clearTimeout(room.matchTimer);
  let winner=null,topKills=-1;
  room.players.forEach(p=>{if(p.kills>topKills){topKills=p.kills;winner=p;}});
  const roomRow=await queryOne('SELECT id FROM game_rooms WHERE room_code=?',[room_code]);
  for(const[,player] of room.players){
    const isWinner=winningFaction?player.faction===winningFaction:player.socketId===winner?.socketId;
    const totalXp=player.xpEarned+(isWinner?200:50);
    const totalCash=player.cashEarned+(isWinner?2000:500);
    const outcome=isWinner?'win':'loss';
    if(roomRow) await query('INSERT INTO match_history (room_id,user_id,kills,deaths,assists,xp_earned,cash_earned,outcome) VALUES (?,?,?,?,?,?,?,?)',[roomRow.id,player.userId,player.kills,player.deaths,player.assists,totalXp,totalCash,outcome]).catch(()=>{});
    const userRow=await queryOne('SELECT xp,rank_level FROM users WHERE id=?',[player.userId]);
    if(userRow){
      const newXp=userRow.xp+totalXp;
      const newRank=calcRank(newXp);
      const rankUp=newRank>userRow.rank_level;
      await query('UPDATE users SET xp=?,rank_level=?,kills=kills+?,deaths=deaths+?,cash=cash+? WHERE id=?',[newXp,newRank,player.kills,player.deaths,totalCash,player.userId]).catch(()=>{});
      if(checkAchievements) checkAchievements(player.userId).catch(()=>{});
      await query('INSERT INTO faction_standings (week_start,faction,total_kills,total_wins) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE total_kills=total_kills+VALUES(total_kills),total_wins=total_wins+VALUES(total_wins)',[getWeekStart(),player.faction,player.kills,isWinner?1:0]).catch(()=>{});
      const ps=io.sockets?.sockets?.get(player.socketId);
      if(ps) ps.emit('match_result',{outcome,kills:player.kills,deaths:player.deaths,xpEarned:totalXp,cashEarned:totalCash,newXp,newRank,rankedUp:rankUp,rankTitle:RANK_TITLES[newRank]||'Godfather',winningFaction});
    }
  }
  io.to(room_code).emit('match_ended',{winner:winner?{username:winner.username,kills:winner.kills,faction:winner.faction}:null,winningFaction,scoreboard:serializePlayers(room)});
  await query("UPDATE game_rooms SET status='ended',ended_at=NOW() WHERE room_code=?",[room_code]);
  cleanupRoom(room);
  rooms.delete(room_code);
}

function initSocketEngine(io) {
  global._mw_io = io;

  io.use(async(socket,next)=>{
    try{
      const token=socket.handshake.auth?.token;
      if(!token) return next(new Error('No token'));
      const payload=await verifyToken(token);
      const user=await queryOne('SELECT id,username,role,faction,rank_level,xp,kills,deaths,cash,heists_won,is_banned FROM users WHERE id=?',[payload.sub]);
      if(!user||user.is_banned) return next(new Error('Unauthorized'));
      socket.user=user; next();
    }catch{next(new Error('Auth failed'));}
  });

  io.on('connection',(socket)=>{
    const user=socket.user;
    userSockets.set(user.id,socket.id);

    socket.on('join_room',async({room_code,weapon_id='pistol_basic'})=>{
      try{
        const roomData=await queryOne("SELECT * FROM game_rooms WHERE room_code=? AND status!='ended'",[room_code]);
        if(!roomData) return socket.emit('error',{message:'Room not found.'});
        if(roomData.current_players>=roomData.max_players) return socket.emit('error',{message:'Room is full.'});
        const owned=await queryOne('SELECT weapon_id FROM weapons_inventory WHERE user_id=? AND weapon_id=?',[user.id,weapon_id]);
        const finalWeapon=owned?weapon_id:'pistol_basic';
        if(!rooms.has(room_code)) rooms.set(room_code,createRoomState(roomData));
        const room=rooms.get(room_code);
        const playerState=createPlayerState(user,socket.id,finalWeapon);
        room.players.set(socket.id,playerState);
        socket.join(room_code); socket.currentRoom=room_code;
        await query('UPDATE game_rooms SET current_players=? WHERE id=?',[room.players.size,roomData.id]);
        socket.emit('room_joined',{room:{...roomData,current_players:room.players.size},player:playerState,players:serializePlayers(room),territory:serializeTerritory(room.territory),guards:serializeGuards(room.guards),mode:room.mode});
        socket.to(room_code).emit('player_joined',{player:playerState,count:room.players.size});
        if(room.players.size>=2&&room.status==='waiting') startCountdown(io,room_code);
      }catch(err){console.error('[SOCKET] join_room:',err);socket.emit('error',{message:'Failed to join room.'});}
    });

    socket.on('move',({x,y,angle})=>{
      const room=rooms.get(socket.currentRoom);
      if(!room) return;
      const p=room.players.get(socket.id);
      if(!p||!p.isAlive) return;
      p.x=Math.max(20,Math.min(780,x)); p.y=Math.max(20,Math.min(580,y)); p.angle=angle;
      if(room.mode==='territory'){
        p.inZone=null;
        TERRITORY_ZONES.forEach(zone=>{const zb=getZoneBounds(zone);if(p.x>=zb.x&&p.x<=zb.x+zb.w&&p.y>=zb.y&&p.y<=zb.y+zb.h) p.inZone=zone;});
      }
      socket.to(socket.currentRoom).emit('player_moved',{socketId:socket.id,x:p.x,y:p.y,angle});
    });

    socket.on('shoot',({targetId,targetType='player',angle})=>{
      const room_code=socket.currentRoom;
      const room=rooms.get(room_code);
      if(!room||room.status!=='active') return;
      const shooter=room.players.get(socket.id);
      if(!shooter||!shooter.isAlive) return;
      const now=Date.now();
      if(now-shooter.lastShot<shooter.weapon.firerate) return;
      if(shooter.ammo<=0){socket.emit('out_of_ammo',{weapon:shooter.weaponId});return;}
      shooter.lastShot=now; shooter.ammo--;
      io.to(room_code).emit('bullet_fired',{shooterId:socket.id,x:shooter.x,y:shooter.y,angle,weaponType:shooter.weapon.type,spread:shooter.weapon.spread});
      if(targetType==='player'&&targetId){
        const target=room.players.get(targetId);
        if(target&&target.isAlive&&targetId!==socket.id){
          if(room.mode==='team'&&shooter.faction===target.faction) return;
          const dmg=calcDamage(shooter.weapon,shooter.x,shooter.y,target.x,target.y);
          target.hp=Math.max(0,target.hp-dmg);
          io.to(room_code).emit('player_hit',{targetId,shooterId:socket.id,damage:dmg,hp:target.hp});
          io.to(room_code).emit('blood_particles',{x:target.x,y:target.y,count:6,color:'#8b0000'});
          if(target.hp<=0) handlePlayerKill(io,room,room_code,shooter,target,socket);
        }
      }
      if(targetType==='guard'&&targetId){
        const guard=room.guards.find(g=>g.id===targetId);
        if(guard&&guard.isAlive){
          guard.hp=Math.max(0,guard.hp-shooter.weapon.damage);
          io.to(room_code).emit('guard_hit',{guardId:guard.id,hp:guard.hp,maxHp:guard.maxHp});
          if(guard.hp<=0){
            guard.isAlive=false;
            shooter.xpEarned+=30; shooter.cashEarned+=200;
            io.to(room_code).emit('guard_killed',{guardId:guard.id,killerName:shooter.username});
            if(room.heist) query('INSERT INTO heist_events (heist_id,user_id,event_type) VALUES (?,?,?)',[room.heist.id,user.id,'guard_kill']).catch(()=>{});
          }
        }
      }
    });

    socket.on('reload',()=>{
      const room=rooms.get(socket.currentRoom);
      if(!room) return;
      const p=room.players.get(socket.id);
      if(!p||p.ammo===p.weapon.ammo) return;
      const refill=Math.min(p.reserveAmmo,p.weapon.ammo-p.ammo);
      p.ammo+=refill; p.reserveAmmo-=refill;
      socket.emit('reloaded',{ammo:p.ammo,reserve:p.reserveAmmo});
    });

    socket.on('heist_action',async({action})=>{
      const room_code=socket.currentRoom;
      const room=rooms.get(room_code);
      if(!room||room.mode!=='heist'||!room.heist) return;
      const bank=BANKS[room.heist.bank_id];
      if(!bank) return;
      const p=room.players.get(socket.id);
      if(!p||!p.isAlive) return;
      const validActions=bank.phases;
      const currentPhaseIndex=room.heist.phasesDone.length;
      if(currentPhaseIndex>=validActions.length) return;
      if(validActions[currentPhaseIndex]!==action) return socket.emit('heist_error',{message:`Wrong phase. Expected: ${validActions[currentPhaseIndex]}`});
      const guardsAlive=room.guards.filter(g=>g.isAlive).length;
      if(action==='hack'&&guardsAlive>0) return socket.emit('heist_error',{message:'Cannot hack — eliminate all guards first.'});
      room.heist.phasesDone.push(action);
      p.heistPhasesDone.push(action);
      await query('INSERT INTO heist_events (heist_id,user_id,event_type) VALUES (?,?,?)',[room.heist.id,user.id,action]).catch(()=>{});
      io.to(room_code).emit('heist_phase_complete',{action,phasesDone:room.heist.phasesDone,phasesTotal:validActions.length,playerName:user.username,guardsRemaining:guardsAlive});
      if(room.heist.phasesDone.length>=validActions.length) await completeHeist(io,room,room_code,true);
    });

    socket.on('chat_message',async({message,channel='room'})=>{
      if(!message||message.length>200) return;
      const room_code=socket.currentRoom;
      const room=rooms.get(room_code);
      if(!room) return;
      const clean=message.replace(/<[^>]*>/g,'').trim();
      const roomData=await queryOne('SELECT id FROM game_rooms WHERE room_code=?',[room_code]);
      if(roomData) await query('INSERT INTO chat_log (room_id,user_id,message,channel) VALUES (?,?,?,?)',[roomData.id,user.id,clean,channel]).catch(()=>{});
      const payload={id:Date.now(),username:user.username,faction:user.faction,message:clean,channel,ts:new Date().toISOString()};
      if(channel==='room') io.to(room_code).emit('chat',payload);
      else if(channel==='faction'){room.players.forEach((pl,sid)=>{if(pl.faction===user.faction) io.to(sid).emit('chat',payload);});}
      else io.emit('chat',payload);
    });

    socket.on('report_player',async({reported_socket_id,reason})=>{
      const room=rooms.get(socket.currentRoom);
      if(!room) return;
      const target=room.players.get(reported_socket_id);
      if(!target) return;
      await query('INSERT INTO player_reports (reporter_id,reported_id,reason) VALUES (?,?,?)',[user.id,target.userId,reason||'other']).catch(()=>{});
      socket.emit('report_sent',{message:'Report submitted.'});
    });

    socket.on('disconnect',async()=>{
      userSockets.delete(user.id);
      const room_code=socket.currentRoom;
      if(!room_code) return;
      const room=rooms.get(room_code);
      if(!room) return;
      const player=room.players.get(socket.id);
      room.players.delete(socket.id);
      if(room.players.size===0){cleanupRoom(room);rooms.delete(room_code);await query("UPDATE game_rooms SET status='ended',ended_at=NOW() WHERE room_code=?",[room_code]);}
      else{await query('UPDATE game_rooms SET current_players=? WHERE room_code=?',[room.players.size,room_code]);io.to(room_code).emit('player_left',{socketId:socket.id,username:player?.username,count:room.players.size});}
      socket.to(socket.currentRoom||'').emit('voice_peer_left',{socketId:socket.id});
    });

    // SPECTATE
    socket.on('spectate_join',({room_code})=>{
      const room=rooms.get(room_code);
      if(!room||room.status!=='active') return socket.emit('error',{message:'Room not available.'});
      socket.join(room_code); socket.currentRoom=room_code; socket.isSpectator=true;
      socket.emit('spectate_state',{players:serializePlayers(room),territory:serializeTerritory(room.territory),guards:serializeGuards(room.guards),mode:room.mode,map_id:room.map_id});
    });

    // FRIEND INVITE
    socket.on('invite_friend',({friend_id,room_code})=>{
      const friendSocketId=userSockets.get(friend_id);
      if(!friendSocketId) return socket.emit('invite_result',{success:false,message:'Friend is offline.'});
      io.to(friendSocketId).emit('friend_invite',{from:user.username,from_id:user.id,room_code,faction:user.faction});
      socket.emit('invite_result',{success:true,message:'Invite sent.'});
    });

    // VOICE SIGNALLING
    socket.on('voice_offer',({targetId,sdp})=>{ io.to(targetId).emit('voice_offer',{fromId:socket.id,username:user.username,sdp}); });
    socket.on('voice_answer',({targetId,sdp})=>{ io.to(targetId).emit('voice_answer',{fromId:socket.id,sdp}); });
    socket.on('voice_ice',({targetId,candidate})=>{ io.to(targetId).emit('voice_ice',{fromId:socket.id,candidate}); });
    socket.on('voice_joined_room',()=>{ socket.to(socket.currentRoom||'').emit('voice_new_peer',{socketId:socket.id,username:user.username,x:400,y:300}); });
    socket.on('voice_position',({x,y})=>{ socket.to(socket.currentRoom||'').emit('voice_position_update',{socketId:socket.id,x,y}); });
  });

  // Guard AI tick - 500ms
  setInterval(()=>{
    const io_ref=global._mw_io;
    if(!io_ref) return;
    rooms.forEach((room,room_code)=>{
      if(room.status!=='active'||room.mode!=='heist'||!room.guards.length) return;
      const now=Date.now();
      let updated=false;
      room.guards.forEach(guard=>{
        if(!guard.isAlive) return;
        let nearest=null,nearestDist=guard.range;
        room.players.forEach(p=>{if(!p.isAlive) return;const d=Math.hypot(p.x-guard.x,p.y-guard.y);if(d<nearestDist){nearest=p;nearestDist=d;}});
        if(nearest){
          guard.aggroTarget=nearest.socketId;
          guard.angle=Math.atan2(nearest.y-guard.y,nearest.x-guard.x);
          guard.x+=Math.cos(guard.angle)*1.2; guard.y+=Math.sin(guard.angle)*1.2;
          guard.x=Math.max(20,Math.min(780,guard.x)); guard.y=Math.max(20,Math.min(580,guard.y));
          if(now-guard.lastShot>guard.firerate){
            guard.lastShot=now;
            nearest.hp=Math.max(0,nearest.hp-guard.damage);
            io_ref.to(room_code).emit('guard_shoots',{guardId:guard.id,targetId:nearest.socketId,damage:guard.damage,targetHp:nearest.hp});
            if(nearest.hp<=0) handlePlayerKill(io_ref,room,room_code,{socketId:'guard',username:'Guard',faction:null,kills:0,killStreak:0,xpEarned:0,cashEarned:0,weapon:{name:'Guard Pistol'}},nearest,null);
          }
          updated=true;
        } else {
          guard.aggroTarget=null;
          const dx=guard.patrolX-guard.x,dy=guard.patrolY-guard.y,d=Math.hypot(dx,dy);
          if(d>2){guard.x+=dx/d*0.8;guard.y+=dy/d*0.8;updated=true;}
        }
      });
      if(updated) io_ref.to(room_code).emit('guards_update',{guards:serializeGuards(room.guards)});
    });
  },500);

  // Territory tick - 1s
  setInterval(()=>{
    const io_ref=global._mw_io;
    if(!io_ref) return;
    rooms.forEach((room,room_code)=>{
      if(room.status!=='active'||room.mode!=='territory') return;
      let changed=false;
      TERRITORY_ZONES.forEach(zone=>{
        const z=room.territory[zone];
        const zb=getZoneBounds(zone);
        const inZone={ghost:0,viper:0,iron:0,shadow:0};
        room.players.forEach(p=>{if(!p.isAlive) return;if(p.x>=zb.x&&p.x<=zb.x+zb.w&&p.y>=zb.y&&p.y<=zb.y+zb.h) inZone[p.faction]=(inZone[p.faction]||0)+1;});
        let dom=null,domCount=0;
        Object.entries(inZone).forEach(([f,c])=>{if(c>domCount){dom=f;domCount=c;}});
        if(!dom||domCount===0) return;
        if(Object.values(inZone).filter(c=>c>0).length>1) return;
        if(z.owner!==dom){
          z.progress=Math.min(100,(z.progress||0)+(100/ZONE_CAPTURE_TIME));
          z.capturer=dom;
          if(z.progress>=100){
            z.owner=dom; z.progress=0; z.capturer=null;
            room.players.forEach(p=>{if(p.faction===dom&&p.isAlive){p.xpEarned+=20;p.cashEarned+=200;}});
            io_ref.to(room_code).emit('zone_captured',{zone,faction:dom});
          }
          changed=true;
        }
        if(z.owner){
          z.points[z.owner]=(z.points[z.owner]||0)+1;
          if(z.points[z.owner]>=TERRITORY_WIN_PTS) endMatch(io_ref,room_code,z.owner);
        }
      });
      if(changed) io_ref.to(room_code).emit('territory_update',{territory:serializeTerritory(room.territory)});
    });
  },1000);
}

module.exports = { initSocketEngine };
