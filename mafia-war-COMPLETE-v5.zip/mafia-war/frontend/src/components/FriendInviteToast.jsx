import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function FriendInviteToast({ socket }) {
  const [invite, setInvite] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!socket) return;
    const onInvite = (data) => {
      setInvite(data);
      setTimeout(() => setInvite(null), 20000); // auto-dismiss
    };
    socket.on('friend_invite', onInvite);
    return () => socket.off('friend_invite', onInvite);
  }, [socket]);

  if (!invite) return null;

  const accept = () => {
    navigate(`/game/${invite.room_code}`);
    setInvite(null);
  };

  return (
    <div style={{
      position: 'fixed', top: 20, right: 20, zIndex: 9999,
      background: '#111', border: '1px solid #c9a84c',
      padding: '16px 20px', maxWidth: 320,
      boxShadow: '0 4px 24px rgba(0,0,0,0.6)',
      animation: 'slideUp 0.3s ease',
    }}>
      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:3, color:'#c9a84c', marginBottom:6 }}>
        🎮 ROOM INVITE
      </div>
      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc', marginBottom:4 }}>
        {invite.from} wants you in their war
      </div>
      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', marginBottom:14 }}>
        Room: {invite.room_code}
      </div>
      <div style={{ display:'flex', gap:8 }}>
        <button className="btn btn-primary btn-sm" onClick={accept} style={{ flex:1 }}>Join Room</button>
        <button className="btn btn-ghost btn-sm" onClick={() => setInvite(null)}>Ignore</button>
      </div>
    </div>
  );
}
