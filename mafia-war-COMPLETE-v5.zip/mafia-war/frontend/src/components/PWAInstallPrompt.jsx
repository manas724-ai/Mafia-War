import { useState, useEffect } from 'react';

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showBanner,     setShowBanner]     = useState(false);
  const [installed,      setInstalled]      = useState(false);

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(err =>
        console.warn('[SW] Registration failed:', err)
      );
    }

    // Capture install prompt
    const onBeforeInstall = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    // Already installed check
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalled(true);
    }

    window.addEventListener('beforeinstallprompt', onBeforeInstall);
    window.addEventListener('appinstalled', () => {
      setInstalled(true); setShowBanner(false);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') { setShowBanner(false); setInstalled(true); }
    setDeferredPrompt(null);
  };

  const dismiss = () => setShowBanner(false);

  if (!showBanner || installed) return null;

  return (
    <div style={{
      position: 'fixed', bottom: 0, left: 0, right: 0, zIndex: 9000,
      background: 'linear-gradient(to right, #1a0000, #0a0a0a)',
      border: '1px solid #8b0000', borderBottom: 'none',
      padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16,
      boxShadow: '0 -4px 24px rgba(139,0,0,0.3)',
    }}>
      <div style={{ fontSize: 28 }}>📱</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#e8e4dc' }}>
          Install Mafia War
        </div>
        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>
          Play faster · Works offline · No app store needed
        </div>
      </div>
      <div style={{ display:'flex', gap:10 }}>
        <button className="btn btn-primary btn-sm" onClick={install}>Install App</button>
        <button className="btn btn-ghost btn-sm" onClick={dismiss}>Later</button>
      </div>
    </div>
  );
}
