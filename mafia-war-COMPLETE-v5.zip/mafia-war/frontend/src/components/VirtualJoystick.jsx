// VirtualJoystick.jsx — touch controls for mobile PWA
import { useEffect, useRef, useCallback } from 'react';

const JOYSTICK_SIZE  = 100;
const KNOB_SIZE      = 40;
const MAX_DISTANCE   = (JOYSTICK_SIZE - KNOB_SIZE) / 2;

export default function VirtualJoystick({ onMove, onFire, visible }) {
  const baseRef  = useRef(null);
  const knobRef  = useRef(null);
  const stateRef = useRef({ active: false, startX: 0, startY: 0, dx: 0, dy: 0 });
  const rafRef   = useRef(null);

  const emitMove = useCallback(() => {
    const { dx, dy } = stateRef.current;
    const dist = Math.hypot(dx, dy);
    if (dist > 4) {
      const nx = dx / Math.max(dist, MAX_DISTANCE);
      const ny = dy / Math.max(dist, MAX_DISTANCE);
      onMove(nx, ny);
    } else {
      onMove(0, 0);
    }
    rafRef.current = requestAnimationFrame(emitMove);
  }, [onMove]);

  const onTouchStart = useCallback((e) => {
    e.preventDefault();
    const t = e.touches[0];
    const rect = baseRef.current.getBoundingClientRect();
    stateRef.current = { active: true, startX: rect.left + JOYSTICK_SIZE/2, startY: rect.top + JOYSTICK_SIZE/2, dx: 0, dy: 0 };
    rafRef.current = requestAnimationFrame(emitMove);
  }, [emitMove]);

  const onTouchMove = useCallback((e) => {
    e.preventDefault();
    if (!stateRef.current.active) return;
    const t = e.touches[0];
    let dx = t.clientX - stateRef.current.startX;
    let dy = t.clientY - stateRef.current.startY;
    const dist = Math.hypot(dx, dy);
    if (dist > MAX_DISTANCE) { dx = dx/dist*MAX_DISTANCE; dy = dy/dist*MAX_DISTANCE; }
    stateRef.current.dx = dx; stateRef.current.dy = dy;

    if (knobRef.current) {
      knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    }
  }, []);

  const onTouchEnd = useCallback((e) => {
    e.preventDefault();
    stateRef.current = { active: false, startX: 0, startY: 0, dx: 0, dy: 0 };
    cancelAnimationFrame(rafRef.current);
    onMove(0, 0);
    if (knobRef.current) knobRef.current.style.transform = 'translate(0,0)';
  }, [onMove]);

  useEffect(() => {
    const base = baseRef.current;
    if (!base) return;
    base.addEventListener('touchstart', onTouchStart, { passive: false });
    base.addEventListener('touchmove',  onTouchMove,  { passive: false });
    base.addEventListener('touchend',   onTouchEnd,   { passive: false });
    return () => {
      base.removeEventListener('touchstart', onTouchStart);
      base.removeEventListener('touchmove',  onTouchMove);
      base.removeEventListener('touchend',   onTouchEnd);
    };
  }, [onTouchStart, onTouchMove, onTouchEnd]);

  if (!visible) return null;

  return (
    <div style={{ position: 'absolute', bottom: 80, left: 20, zIndex: 50, userSelect: 'none', touchAction: 'none' }}>
      {/* Joystick */}
      <div ref={baseRef} style={{
        width: JOYSTICK_SIZE, height: JOYSTICK_SIZE, borderRadius: '50%',
        background: 'rgba(255,255,255,0.1)', border: '2px solid rgba(255,255,255,0.3)',
        position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div ref={knobRef} style={{
          width: KNOB_SIZE, height: KNOB_SIZE, borderRadius: '50%',
          background: 'rgba(139,0,0,0.8)', border: '2px solid rgba(192,57,43,0.9)',
          position: 'absolute', transition: 'none',
          boxShadow: '0 0 12px rgba(139,0,0,0.6)',
        }}/>
      </div>

      {/* Fire button */}
      <button
        onTouchStart={(e) => { e.preventDefault(); onFire(); }}
        style={{
          position: 'absolute', left: JOYSTICK_SIZE + 16, top: 10,
          width: 72, height: 72, borderRadius: '50%',
          background: 'rgba(139,0,0,0.85)', border: '3px solid #c0392b',
          color: '#fff', fontSize: 26, fontFamily: 'Bebas Neue, sans-serif',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 20px rgba(139,0,0,0.5)',
          touchAction: 'none', userSelect: 'none',
        }}
      >🔫</button>

      {/* Reload button */}
      <button
        onTouchStart={(e) => { e.preventDefault(); onFire('reload'); }}
        style={{
          position: 'absolute', left: JOYSTICK_SIZE + 100, top: 20,
          width: 52, height: 52, borderRadius: '50%',
          background: 'rgba(30,30,30,0.85)', border: '2px solid #555',
          color: '#c9a84c', fontSize: 20,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          touchAction: 'none', userSelect: 'none',
        }}
      >↺</button>
    </div>
  );
}
