import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const API = axios.create({ baseURL: '/api' });

// Attach token to all requests
API.interceptors.request.use(cfg => {
  const token = localStorage.getItem('mw_access');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

// Refresh token on 401
API.interceptors.response.use(
  r => r,
  async err => {
    if (err.response?.status === 401 && !err.config._retry) {
      err.config._retry = true;
      try {
        const refresh = localStorage.getItem('mw_refresh');
        const { data } = await axios.post('/api/auth/refresh', { refreshToken: refresh });
        localStorage.setItem('mw_access', data.accessToken);
        err.config.headers.Authorization = `Bearer ${data.accessToken}`;
        return API(err.config);
      } catch {
        localStorage.clear();
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async () => {
    try {
      const { data } = await API.get('/player/profile');
      setUser(data);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('mw_access');
    if (token) loadProfile();
    else setLoading(false);
  }, [loadProfile]);

  const login = async (email, password) => {
    const { data } = await API.post('/auth/login', { email, password });
    localStorage.setItem('mw_access',  data.accessToken);
    localStorage.setItem('mw_refresh', data.refreshToken);
    setUser(data.user);
    await loadProfile();
    return data;
  };

  const register = async (form) => {
    const { data } = await API.post('/auth/register', form);
    localStorage.setItem('mw_access',  data.accessToken);
    localStorage.setItem('mw_refresh', data.refreshToken);
    setUser(data.user);
    await loadProfile();
    return data;
  };

  const logout = () => {
    localStorage.removeItem('mw_access');
    localStorage.removeItem('mw_refresh');
    setUser(null);
    window.location.href = '/';
  };

  return (
    <AuthContext.Provider value={{ user, setUser, loading, login, register, logout, api: API, loadProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
export { API };
