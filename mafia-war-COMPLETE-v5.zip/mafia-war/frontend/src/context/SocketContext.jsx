import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SocketContext = createContext(null);

export function SocketProvider({ children }) {
  const { user } = useAuth();
  const socketRef  = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!user) { socketRef.current?.disconnect(); return; }

    const token = localStorage.getItem('mw_access');
    const s = io('/', {
      auth:              { token },
      transports:        ['websocket'],
      reconnectionDelay: 2000,
      reconnectionAttempts: 10,
    });

    s.on('connect',    () => { setConnected(true);  console.log('[WS] Connected'); });
    s.on('disconnect', () => { setConnected(false); console.log('[WS] Disconnected'); });
    s.on('error',      (e) => console.error('[WS] Error:', e));

    socketRef.current = s;
    return () => { s.disconnect(); };
  }, [user]);

  return (
    <SocketContext.Provider value={{ socket: socketRef.current, connected }}>
      {children}
    </SocketContext.Provider>
  );
}

export const useSocket = () => useContext(SocketContext);
