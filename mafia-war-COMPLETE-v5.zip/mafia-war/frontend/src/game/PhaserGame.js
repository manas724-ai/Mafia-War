// PhaserGame.js — Phaser 3 Scene wired to Socket.io
// Replaces raw canvas. Loaded dynamically in Game.jsx.

import Phaser from 'phaser';

const FACTION_COLORS = { ghost: 0x9ca3af, viper: 0xc9a84c, iron: 0x60a5fa, shadow: 0x8b0000 };
const WEAPON_COLORS  = { pistol: 0xfbbf24, smg: 0xf97316, shotgun: 0xef4444, rifle: 0x22c55e, sniper: 0x818cf8, explosive: 0xf97316, special: 0xc9a84c };
const MAP_BG         = { downtown:'#0a0a0a', chinatown:'#050a05', harbour:'#050810', casino:'#0a0800', penthouse:'#050510', federal_bank:'#0a0500', casino_vault:'#080800', armoured_car:'#0a0500' };
const MAP_WALL       = { downtown:0x2a2a2a, chinatown:0x1a2a1a, harbour:0x1a2030, casino:0x2a2200, penthouse:0x1a1a2a, federal_bank:0x333322, casino_vault:0x332200, armoured_car:0x222200 };

export function createPhaserGame(container, socket, user, roomInfo, onHudUpdate, onEvent) {
  class MainScene extends Phaser.Scene {
    constructor() { super({ key: 'MainScene' }); }

    preload() {
      // Generate textures procedurally — no external assets needed
      this.generateTextures();
    }

    generateTextures() {
      // Player body texture (16x24)
      const pg = this.make.graphics({ x:0, y:0, add:false });
      pg.fillStyle(0xffffff);
      pg.fillRect(0, 4, 16, 16);  // torso
      pg.fillCircle(8, 4, 8);     // head
      pg.fillRect(14, 8, 12, 3);  // gun barrel
      pg.generateTexture('player', 28, 24);
      pg.destroy();

      // Guard texture (red tint)
      const gg = this.make.graphics({ x:0, y:0, add:false });
      gg.fillStyle(0xc0392b);
      gg.fillRect(0, 4, 16, 16);
      gg.fillCircle(8, 4, 8);
      gg.fillRect(14, 8, 10, 3);
      gg.generateTexture('guard_sprite', 26, 24);
      gg.destroy();

      // Bullet
      const bg = this.make.graphics({ x:0, y:0, add:false });
      bg.fillStyle(0xfbbf24);
      bg.fillCircle(3, 3, 3);
      bg.generateTexture('bullet', 6, 6);
      bg.destroy();

      // Zone marker
      const zg = this.make.graphics({ x:0, y:0, add:false });
      zg.lineStyle(2, 0xffffff, 0.6);
      zg.strokeRect(0, 0, 120, 100);
      zg.generateTexture('zone', 120, 100);
      zg.destroy();

      // Vault door (heist)
      const vg = this.make.graphics({ x:0, y:0, add:false });
      vg.fillStyle(0x444444);
      vg.fillRect(0,0,60,80);
      vg.lineStyle(3,0xc9a84c);
      vg.strokeRect(0,0,60,80);
      vg.fillStyle(0xc9a84c);
      vg.fillCircle(50,40,8);
      vg.generateTexture('vault', 60, 80);
      vg.destroy();
    }

    create() {
      const W = this.scale.width;
      const H = this.scale.height;
      this.mapId   = roomInfo.map_id || 'downtown';
      this.mode    = roomInfo.mode   || 'deathmatch';
      this.myId    = socket.id;

      // ── BACKGROUND ─────────────────────────────────────────
      const bgColor = parseInt((MAP_BG[this.mapId] || '#0a0a0a').replace('#',''), 16);
      this.cameras.main.setBackgroundColor(bgColor);

      // Grid lines
      this.grid = this.add.graphics();
      this.grid.lineStyle(0.5, 0x222222, 0.4);
      for (let x = 0; x < W; x += 40) { this.grid.moveTo(x,0); this.grid.lineTo(x,H); }
      for (let y = 0; y < H; y += 40) { this.grid.moveTo(0,y); this.grid.lineTo(W,y); }
      this.grid.strokePath();

      // ── MAP WALLS ───────────────────────────────────────────
      this.wallsGfx = this.add.graphics();
      this.drawWalls();

      // ── TERRITORY ZONES (if mode) ────────────────────────────
      this.zonesGfx = this.add.graphics();
      this.zoneLabels = {};
      this.zoneBars   = {};
      if (this.mode === 'territory') this.drawZones(roomInfo.territory || {});

      // ── VAULT (heist mode) ──────────────────────────────────
      this.vaultSprite = null;
      this.vaultPhaseGfx = null;
      if (this.mode === 'heist') {
        this.vaultSprite = this.add.image(400, 300, 'vault').setTint(0xc9a84c).setDepth(2);
        this.vaultPhaseGfx = this.add.graphics().setDepth(10);
        this.vaultLabel = this.add.text(400, 270, 'VAULT', {
          fontFamily:'Bebas Neue', fontSize:14, color:'#c9a84c', letterSpacing:3
        }).setOrigin(0.5).setDepth(11);
      }

      // ── PLAYERS ──────────────────────────────────────────────
      this.players     = {};   // socketId → { sprite, nameText, hpBar, hpBg, shadow }
      this.bullets     = [];
      this.bloodFx     = this.add.particles(0, 0, 'bullet', { emitting:false });
      this.guards      = {};   // id → { sprite, hpBar, hpBg }

      // Spawn existing players
      const initialPlayers = roomInfo.players || [];
      initialPlayers.forEach(p => this.spawnPlayer(p));
      this.spawnSelf(roomInfo.player);

      // Spawn guards
      (roomInfo.guards || []).forEach(g => this.spawnGuard(g));

      // ── CROSSHAIR ────────────────────────────────────────────
      this.crosshair = this.add.graphics().setDepth(100);
      this.input.on('pointermove', ptr => this.updateCrosshair(ptr.x, ptr.y));

      // ── INPUT ────────────────────────────────────────────────
      this.keys = this.input.keyboard.addKeys('W,A,S,D,R,UP,DOWN,LEFT,RIGHT');
      this.input.on('pointerdown', (ptr) => this.handleShoot(ptr));

      // ── SOCKET EVENTS ────────────────────────────────────────
      this.bindSocketEvents();

      // ── MATCH TIMER ──────────────────────────────────────────
      this.matchDuration = roomInfo.duration || 480;
      this.matchTimeLeft = this.matchDuration;
      this.time.addEvent({ delay:1000, loop:true, callback:()=>{
        if(this.matchTimeLeft > 0){this.matchTimeLeft--;onHudUpdate({timeLeft:this.matchTimeLeft});}
      }});
    }

    update() {
      const me = this.players[this.myId];
      if (!me || !me.alive) return;

      const SPEED = 3;
      let dx = 0, dy = 0;
      if (this.keys.W.isDown || this.keys.UP.isDown)    dy -= SPEED;
      if (this.keys.S.isDown || this.keys.DOWN.isDown)  dy += SPEED;
      if (this.keys.A.isDown || this.keys.LEFT.isDown)  dx -= SPEED;
      if (this.keys.D.isDown || this.keys.RIGHT.isDown) dx += SPEED;

      if (dx !== 0 || dy !== 0) {
        const nx = Phaser.Math.Clamp(me.sprite.x + dx, 20, 780);
        const ny = Phaser.Math.Clamp(me.sprite.y + dy, 20, 580);
        me.sprite.x = nx; me.sprite.y = ny;
        this.updatePlayerLabel(this.myId);

        const ptr = this.input.activePointer;
        const angle = Phaser.Math.Angle.Between(nx, ny, ptr.x, ptr.y);
        me.sprite.setRotation(angle);

        socket.emit('move', { x: nx, y: ny, angle });
        onHudUpdate({ x: nx, y: ny });
      }

      // Reload hotkey
      if (Phaser.Input.Keyboard.JustDown(this.keys.R)) {
        socket.emit('reload');
      }

      // Advance bullets
      this.bullets = this.bullets.filter(b => {
        b.img.x += Math.cos(b.angle) * b.speed;
        b.img.y += Math.sin(b.angle) * b.speed;
        b.life--;
        b.img.setAlpha(b.life / 35);
        if (b.life <= 0) { b.img.destroy(); return false; }
        return true;
      });
    }

    // ── SPAWN / REMOVE ─────────────────────────────────────────
    spawnPlayer(p, isMe = false) {
      if (this.players[p.socketId]) return;
      const faction = p.faction || 'ghost';
      const tint = FACTION_COLORS[faction] || 0x9ca3af;

      const shadow = this.add.ellipse(p.x, p.y + 14, 28, 10, 0x000000, 0.4).setDepth(1);
      const sprite = this.add.image(p.x, p.y, 'player').setTint(tint).setDepth(3);
      if (isMe) sprite.setStrokeStyle && sprite.setStrokeStyle(2, 0xffffff);

      const hpBg = this.add.rectangle(p.x, p.y - 22, 30, 4, 0x333333).setDepth(4);
      const hpBar= this.add.rectangle(p.x, p.y - 22, 30, 4, 0x22c55e).setDepth(5).setOrigin(0, 0.5);
      hpBar.x = p.x - 15;

      const nameText = this.add.text(p.x, p.y - 30, p.username, {
        fontFamily: 'Share Tech Mono', fontSize: isMe ? '11px' : '10px',
        color: isMe ? '#ffffff' : `#${tint.toString(16).padStart(6,'0')}`,
      }).setOrigin(0.5).setDepth(6);

      this.players[p.socketId] = { sprite, shadow, hpBg, hpBar, nameText, hp: p.hp || 100, alive: p.isAlive !== false };
    }

    spawnSelf(p) {
      if (!p) return;
      this.spawnPlayer({ ...p, socketId: this.myId }, true);
    }

    removePlayer(socketId) {
      const p = this.players[socketId];
      if (!p) return;
      [p.sprite, p.shadow, p.hpBg, p.hpBar, p.nameText].forEach(o => o?.destroy());
      delete this.players[socketId];
    }

    spawnGuard(g) {
      if (this.guards[g.id]) return;
      const shadow = this.add.ellipse(g.x, g.y + 12, 24, 8, 0x000000, 0.3).setDepth(1);
      const sprite = this.add.image(g.x, g.y, 'guard_sprite').setTint(0xc0392b).setDepth(3);
      const hpBg   = this.add.rectangle(g.x, g.y - 20, 26, 3, 0x333333).setDepth(4);
      const hpBar  = this.add.rectangle(g.x - 13, g.y - 20, 26, 3, 0xef4444).setDepth(5).setOrigin(0, 0.5);
      const label  = this.add.text(g.x, g.y - 26, '⚠ GUARD', { fontFamily:'Share Tech Mono', fontSize:'9px', color:'#c0392b' }).setOrigin(0.5).setDepth(6);
      this.guards[g.id] = { sprite, shadow, hpBg, hpBar, label, hp: g.hp, maxHp: g.maxHp, alive: g.isAlive };
    }

    updatePlayerLabel(socketId) {
      const p = this.players[socketId];
      if (!p) return;
      const sx = p.sprite.x, sy = p.sprite.y;
      p.shadow.setPosition(sx, sy + 14);
      p.hpBg.setPosition(sx, sy - 22);
      p.hpBar.setPosition(sx - 15, sy - 22);
      p.nameText.setPosition(sx, sy - 30);
    }

    updateGuardPosition(g) {
      const gd = this.guards[g.id];
      if (!gd) return;
      gd.sprite.setPosition(g.x, g.y);
      gd.sprite.setRotation(g.angle || 0);
      gd.shadow.setPosition(g.x, g.y + 12);
      gd.hpBg.setPosition(g.x, g.y - 20);
      gd.hpBar.setPosition(g.x - 13, g.y - 20);
      gd.label.setPosition(g.x, g.y - 26);
    }

    // ── SHOOTING ──────────────────────────────────────────────
    handleShoot(ptr) {
      if (socket._chatOpen) return;
      const me = this.players[this.myId];
      if (!me || !me.alive) return;

      const angle = Phaser.Math.Angle.Between(me.sprite.x, me.sprite.y, ptr.x, ptr.y);

      // Find nearest target
      let targetId   = null, targetType = 'player', minDist = 300;
      Object.entries(this.players).forEach(([sid, p]) => {
        if (sid === this.myId || !p.alive) return;
        const d = Phaser.Math.Distance.Between(me.sprite.x, me.sprite.y, p.sprite.x, p.sprite.y);
        if (d < minDist) { minDist = d; targetId = sid; targetType = 'player'; }
      });
      Object.entries(this.guards).forEach(([id, g]) => {
        if (!g.alive) return;
        const d = Phaser.Math.Distance.Between(me.sprite.x, me.sprite.y, g.sprite.x, g.sprite.y);
        if (d < minDist) { minDist = d; targetId = id; targetType = 'guard'; }
      });

      socket.emit('shoot', { targetId, targetType, angle });
    }

    fireBullet(x, y, angle, weaponType) {
      const speed  = weaponType === 'sniper' ? 22 : weaponType === 'explosive' ? 8 : 14;
      const life   = weaponType === 'sniper' ? 60 : 40;
      const color  = WEAPON_COLORS[weaponType] || 0xfbbf24;
      const img    = this.add.image(x, y, 'bullet').setTint(color).setDepth(7).setScale(weaponType === 'sniper' ? 1.5 : 1);
      img.setRotation(angle);
      this.bullets.push({ img, angle, speed, life: life });

      // Muzzle flash
      const flash = this.add.circle(x + Math.cos(angle)*16, y + Math.sin(angle)*16, 6, 0xfbbf24, 0.8).setDepth(8);
      this.time.delayedCall(60, () => flash.destroy());
    }

    spawnBlood(x, y) {
      for (let i = 0; i < 6; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 4;
        const dot   = this.add.circle(x, y, 2 + Math.random()*2, 0x8b0000, 0.8).setDepth(2);
        this.tweens.add({ targets: dot, x: x + Math.cos(angle)*speed*8, y: y + Math.sin(angle)*speed*8, alpha: 0, scaleX: 0.3, scaleY: 0.3, duration: 400, ease:'Power2', onComplete:()=>dot.destroy() });
      }
    }

    // ── HUD HELPERS ────────────────────────────────────────────
    updateCrosshair(mx, my) {
      this.crosshair.clear();
      this.crosshair.lineStyle(1.5, 0xffffff, 0.7);
      this.crosshair.moveTo(mx-12, my); this.crosshair.lineTo(mx+12, my);
      this.crosshair.moveTo(mx, my-12); this.crosshair.lineTo(mx, my+12);
      this.crosshair.strokePath();
      this.crosshair.strokeCircle(mx, my, 6);
    }

    drawWalls() {
      const wc = MAP_WALL[this.mapId] || 0x2a2a2a;
      this.wallsGfx.clear();
      this.wallsGfx.fillStyle(wc);
      getMapWalls(this.mapId).forEach(w => this.wallsGfx.fillRect(w.x, w.y, w.w, w.h));
      this.wallsGfx.setDepth(1);
    }

    drawZones(territory) {
      this.zonesGfx.clear();
      const ZONE_POS = { Alpha:{x:60,y:60,w:120,h:100}, Bravo:{x:620,y:60,w:120,h:100}, Charlie:{x:60,y:440,w:120,h:100}, Delta:{x:620,y:440,w:120,h:100} };
      Object.entries(ZONE_POS).forEach(([zone, pos]) => {
        const zd = territory[zone] || {};
        const col = zd.owner ? FACTION_COLORS[zd.owner] : 0x444444;
        this.zonesGfx.lineStyle(2, col, 0.7);
        this.zonesGfx.strokeRect(pos.x, pos.y, pos.w, pos.h);
        this.zonesGfx.fillStyle(col, 0.08);
        this.zonesGfx.fillRect(pos.x, pos.y, pos.w, pos.h);

        // Zone label
        if (!this.zoneLabels[zone]) {
          this.zoneLabels[zone] = this.add.text(pos.x+pos.w/2, pos.y+pos.h/2, zone, {
            fontFamily:'Bebas Neue', fontSize:'18px', color:'#ffffff', alpha:0.5
          }).setOrigin(0.5).setDepth(2);
        }

        // Capture progress bar
        if (zd.progress > 0 && !this.zoneBars[zone]) {
          this.zoneBars[zone] = this.add.rectangle(pos.x, pos.y+pos.h+4, pos.w*(zd.progress/100), 4, FACTION_COLORS[zd.capturer]||0xffffff).setOrigin(0,0).setDepth(3);
        }
      });
      this.zonesGfx.setDepth(1);
    }

    updateZones(territory) {
      this.drawZones(territory);
      // Update progress bars
      const ZONE_POS = { Alpha:{x:60,y:60,w:120,h:100}, Bravo:{x:620,y:60,w:120,h:100}, Charlie:{x:60,y:440,w:120,h:100}, Delta:{x:620,y:440,w:120,h:100} };
      Object.entries(territory).forEach(([zone, zd]) => {
        const pos = ZONE_POS[zone];
        if (this.zoneBars[zone]) { this.zoneBars[zone].destroy(); delete this.zoneBars[zone]; }
        if (zd.progress > 0 && pos) {
          const col = FACTION_COLORS[zd.capturer] || 0xffffff;
          this.zoneBars[zone] = this.add.rectangle(pos.x, pos.y+pos.h+4, pos.w*(zd.progress/100), 4, col).setOrigin(0,0).setDepth(3);
        }
      });
    }

    updateHeistPhases(phasesDone, phasesTotal) {
      if (!this.vaultPhaseGfx) return;
      this.vaultPhaseGfx.clear();
      const W = 120, H = 10, sx = 340, sy = 340;
      this.vaultPhaseGfx.fillStyle(0x222222); this.vaultPhaseGfx.fillRect(sx, sy, W, H);
      this.vaultPhaseGfx.fillStyle(0xc9a84c); this.vaultPhaseGfx.fillRect(sx, sy, W*(phasesDone/phasesTotal), H);
      if (this.vaultLabel) this.vaultLabel.setText(`${phasesDone}/${phasesTotal} PHASES`);
    }

    // ── SOCKET BINDINGS ────────────────────────────────────────
    bindSocketEvents() {
      socket.on('player_joined', ({ player }) => {
        if (player.socketId !== this.myId) this.spawnPlayer(player);
      });

      socket.on('player_left', ({ socketId }) => this.removePlayer(socketId));

      socket.on('player_moved', ({ socketId, x, y, angle }) => {
        const p = this.players[socketId];
        if (!p) return;
        this.tweens.add({ targets: p.sprite, x, y, duration: 80, ease: 'Linear' });
        p.sprite.setRotation(angle || 0);
        this.time.delayedCall(80, () => this.updatePlayerLabel(socketId));
      });

      socket.on('bullet_fired', ({ shooterId, x, y, angle, weaponType }) => {
        this.fireBullet(x, y, angle, weaponType);
      });

      socket.on('player_hit', ({ targetId, damage, hp }) => {
        const p = this.players[targetId];
        if (!p) return;
        p.hp = hp;
        const ratio = hp / 100;
        const barW = ratio * 30;
        this.tweens.add({ targets: p.hpBar, scaleX: ratio, duration: 100 });
        p.hpBar.setFillStyle(ratio > 0.5 ? 0x22c55e : ratio > 0.25 ? 0xf59e0b : 0xc0392b);
        this.spawnBlood(p.sprite.x, p.sprite.y);
        if (targetId === this.myId) onHudUpdate({ hp });
      });

      socket.on('blood_particles', ({ x, y }) => this.spawnBlood(x, y));

      socket.on('player_killed', ({ victimId, killerName, weapon }) => {
        const p = this.players[victimId];
        if (!p) return;
        p.alive = false;
        // Death effect
        this.tweens.add({ targets: p.sprite, alpha: 0, scaleX: 1.5, scaleY: 0.3, duration: 500, ease:'Power2', onComplete:()=>p.sprite.setAlpha(0) });
        this.spawnBlood(p.sprite.x, p.sprite.y);
        this.spawnBlood(p.sprite.x, p.sprite.y);
        onEvent('kill', { killerName, weapon, victimId });
      });

      socket.on('player_respawned', ({ socketId, x, y }) => {
        const p = this.players[socketId];
        if (!p) return;
        p.sprite.setPosition(x, y).setAlpha(1).setScale(1);
        p.hp = 100; p.alive = true;
        p.hpBar.setFillStyle(0x22c55e);
        this.updatePlayerLabel(socketId);
      });

      socket.on('respawned', ({ x, y, hp, ammo }) => {
        const me = this.players[this.myId];
        if (me) { me.sprite.setPosition(x, y).setAlpha(1).setScale(1); me.hp = hp; me.alive = true; }
        onHudUpdate({ hp, ammo });
      });

      socket.on('stats_update', (data) => onHudUpdate(data));
      socket.on('reloaded', ({ ammo, reserve }) => onHudUpdate({ ammo, reserve }));
      socket.on('out_of_ammo', () => onEvent('system', { text: '🔴 Out of ammo! Press R to reload.' }));

      socket.on('guards_update', ({ guards }) => {
        guards.forEach(g => {
          if (!this.guards[g.id] && g.isAlive) this.spawnGuard(g);
          else this.updateGuardPosition(g);
        });
      });

      socket.on('guard_hit', ({ guardId, hp, maxHp }) => {
        const g = this.guards[guardId];
        if (!g) return;
        g.hp = hp;
        const ratio = hp / maxHp;
        g.hpBar.setSize(26 * ratio, 3);
      });

      socket.on('guard_killed', ({ guardId, killerName }) => {
        const g = this.guards[guardId];
        if (!g) return;
        g.alive = false;
        this.tweens.add({ targets:[g.sprite,g.label], alpha:0, duration:400, onComplete:()=>{
          [g.sprite,g.shadow,g.hpBg,g.hpBar,g.label].forEach(o=>o?.destroy());
          delete this.guards[guardId];
        }});
        onEvent('system', { text: `💀 ${killerName} eliminated a guard!` });
      });

      socket.on('guard_shoots', ({ targetId, damage, targetHp }) => {
        const target = this.players[targetId];
        if (target) { this.spawnBlood(target.sprite.x, target.sprite.y); }
        if (targetId === this.myId) onHudUpdate({ hp: Math.max(0, targetHp) });
      });

      socket.on('territory_update', ({ territory }) => this.updateZones(territory));
      socket.on('zone_captured', ({ zone, faction }) => {
        onEvent('zone', { zone, faction });
        // Flash zone
        this.cameras.main.flash(300, 100, 80, 0);
      });

      socket.on('heist_phase_complete', ({ action, phasesDone, phasesTotal, playerName }) => {
        this.updateHeistPhases(phasesDone.length, phasesTotal);
        onEvent('heist', { text: `✅ ${playerName} completed: ${action.toUpperCase()}` });
      });

      socket.on('heist_error', ({ message }) => onEvent('system', { text: `⚠ ${message}` }));

      socket.on('heist_complete', ({ success, share, message }) => {
        onEvent('heist_end', { success, share, message });
      });
    }
  }

  const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: container,
    backgroundColor: '#0a0a0a',
    scene: MainScene,
    input: { mouse: true, keyboard: true },
    render: { antialias: true, pixelArt: false },
    fps: { target: 60, min: 30 },
  };

  const game = new Phaser.Game(config);
  return game;
}

function getMapWalls(mapId) {
  const walls = {
    downtown: [
      {x:80,y:40,w:20,h:140},{x:300,y:70,w:140,h:20},{x:560,y:140,w:20,h:120},
      {x:180,y:240,w:100,h:20},{x:430,y:190,w:20,h:160},{x:80,y:370,w:160,h:20},
      {x:580,y:340,w:20,h:140},{x:300,y:440,w:120,h:20},{x:40,y:510,w:220,h:20},{x:530,y:490,w:170,h:20},
    ],
    chinatown: [
      {x:70,y:90,w:20,h:220},{x:190,y:50,w:20,h:160},{x:340,y:110,w:170,h:20},{x:550,y:70,w:20,h:200},
      {x:140,y:310,w:120,h:20},{x:390,y:290,w:20,h:160},{x:90,y:450,w:70,h:20},{x:540,y:410,w:120,h:20},
    ],
    harbour: [
      {x:50,y:70,w:20,h:320},{x:190,y:140,w:90,h:20},{x:370,y:90,w:20,h:220},
      {x:490,y:190,w:200,h:20},{x:670,y:90,w:20,h:270},{x:140,y:440,w:220,h:20},{x:440,y:390,w:20,h:170},{x:570,y:470,w:140,h:20},
    ],
    federal_bank: [
      {x:100,y:60,w:200,h:20},{x:500,y:60,w:200,h:20},{x:100,y:60,w:20,h:150},
      {x:680,y:60,w:20,h:150},{x:350,y:250,w:100,h:20},{x:150,y:350,w:20,h:120},
      {x:630,y:350,w:20,h:120},{x:200,y:480,w:400,h:20},{x:350,y:350,w:100,h:100},
    ],
    casino_vault: [
      {x:80,y:80,w:160,h:20},{x:560,y:80,w:160,h:20},{x:80,y:80,w:20,h:200},
      {x:700,y:80,w:20,h:200},{x:200,y:300,w:80,h:20},{x:520,y:300,w:80,h:20},
      {x:360,y:220,w:80,h:20},{x:360,y:380,w:80,h:100},
    ],
    armoured_car: [
      {x:0,y:200,w:800,h:20},{x:0,y:380,w:800,h:20},{x:100,y:220,w:80,h:160},
      {x:300,y:220,w:80,h:160},{x:500,y:220,w:80,h:160},{x:650,y:220,w:80,h:160},
    ],
  };
  return walls[mapId] || walls.downtown;
}
