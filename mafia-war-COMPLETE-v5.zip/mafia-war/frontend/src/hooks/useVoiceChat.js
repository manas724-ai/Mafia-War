// useVoiceChat.js — WebRTC voice chat with spatial audio
// Spatial audio: volume decreases with distance to each peer on game canvas

import { useEffect, useRef, useState, useCallback } from 'react';

const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
];

const MAX_VOICE_RANGE = 250; // pixels — beyond this, volume = 0

export function useVoiceChat(socket, myPosition, enabled) {
  const localStreamRef = useRef(null);
  const peersRef       = useRef({}); // socketId → { pc, gainNode, audioEl, x, y }
  const audioCtxRef    = useRef(null);
  const [muted,    setMuted]    = useState(false);
  const [voiceOn,  setVoiceOn]  = useState(false);
  const [peerCount,setPeerCount]= useState(0);

  // Init microphone
  const startVoice = useCallback(async () => {
    if (!enabled || voiceOn) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      localStreamRef.current = stream;
      audioCtxRef.current    = new (window.AudioContext || window.webkitAudioContext)();
      setVoiceOn(true);
      socket?.emit('voice_joined_room');
    } catch (err) {
      console.warn('[VOICE] Mic access denied:', err.message);
    }
  }, [enabled, voiceOn, socket]);

  const stopVoice = useCallback(() => {
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    Object.values(peersRef.current).forEach(p => {
      p.pc?.close();
      p.audioEl?.remove();
    });
    peersRef.current = {};
    audioCtxRef.current?.close();
    setVoiceOn(false);
    setPeerCount(0);
  }, []);

  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    stream.getAudioTracks().forEach(t => { t.enabled = muted; });
    setMuted(prev => !prev);
  }, [muted]);

  // Create peer connection to a new peer
  const createPeer = useCallback(async (targetId, initiator) => {
    if (peersRef.current[targetId]) return;
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    // Add local tracks
    localStreamRef.current?.getTracks().forEach(t => pc.addTrack(t, localStreamRef.current));

    // Remote audio with gain node for spatial audio
    const audioCtx = audioCtxRef.current;
    let gainNode = null, audioEl = null;

    pc.ontrack = (ev) => {
      audioEl = new Audio();
      audioEl.srcObject = ev.streams[0];
      audioEl.autoplay  = true;
      document.body.appendChild(audioEl);

      if (audioCtx) {
        const src   = audioCtx.createMediaElementSource(audioEl);
        gainNode    = audioCtx.createGain();
        gainNode.gain.value = 1;
        src.connect(gainNode);
        gainNode.connect(audioCtx.destination);
      }
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate) socket?.emit('voice_ice', { targetId, candidate: ev.candidate });
    };

    peersRef.current[targetId] = { pc, gainNode, audioEl, x: 400, y: 300 };
    setPeerCount(Object.keys(peersRef.current).length);

    if (initiator) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket?.emit('voice_offer', { targetId, sdp: pc.localDescription });
    }
    return pc;
  }, [socket]);

  // Update spatial volume based on positions
  const updateSpatialAudio = useCallback((myX, myY) => {
    Object.entries(peersRef.current).forEach(([, peer]) => {
      if (!peer.gainNode) return;
      const dist = Math.hypot((peer.x || 400) - myX, (peer.y || 300) - myY);
      const vol  = Math.max(0, 1 - dist / MAX_VOICE_RANGE);
      peer.gainNode.gain.setTargetAtTime(vol, audioCtxRef.current.currentTime, 0.05);
    });
  }, []);

  // Socket event listeners
  useEffect(() => {
    if (!socket) return;

    const onNewPeer = async ({ socketId, x, y }) => {
      if (!voiceOn || !localStreamRef.current) return;
      await createPeer(socketId, true);
      if (peersRef.current[socketId]) { peersRef.current[socketId].x = x; peersRef.current[socketId].y = y; }
    };

    const onOffer = async ({ fromId, sdp }) => {
      if (!voiceOn || !localStreamRef.current) return;
      let peer = peersRef.current[fromId];
      if (!peer) {
        await createPeer(fromId, false);
        peer = peersRef.current[fromId];
      }
      if (!peer) return;
      await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await peer.pc.createAnswer();
      await peer.pc.setLocalDescription(answer);
      socket.emit('voice_answer', { targetId: fromId, sdp: peer.pc.localDescription });
    };

    const onAnswer = async ({ fromId, sdp }) => {
      const peer = peersRef.current[fromId];
      if (peer) await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
    };

    const onIce = async ({ fromId, candidate }) => {
      const peer = peersRef.current[fromId];
      if (peer && candidate) await peer.pc.addIceCandidate(new RTCIceCandidate(candidate)).catch(() => {});
    };

    const onPeerLeft = ({ socketId }) => {
      const peer = peersRef.current[socketId];
      if (peer) { peer.pc?.close(); peer.audioEl?.remove(); delete peersRef.current[socketId]; }
      setPeerCount(Object.keys(peersRef.current).length);
    };

    const onPosUpdate = ({ socketId, x, y }) => {
      if (peersRef.current[socketId]) { peersRef.current[socketId].x = x; peersRef.current[socketId].y = y; }
    };

    socket.on('voice_new_peer',      onNewPeer);
    socket.on('voice_offer',         onOffer);
    socket.on('voice_answer',        onAnswer);
    socket.on('voice_ice',           onIce);
    socket.on('voice_peer_left',     onPeerLeft);
    socket.on('voice_position_update', onPosUpdate);

    return () => {
      socket.off('voice_new_peer',      onNewPeer);
      socket.off('voice_offer',         onOffer);
      socket.off('voice_answer',        onAnswer);
      socket.off('voice_ice',           onIce);
      socket.off('voice_peer_left',     onPeerLeft);
      socket.off('voice_position_update', onPosUpdate);
    };
  }, [socket, voiceOn, createPeer]);

  // Spatial audio update on position change
  useEffect(() => {
    if (!voiceOn || !myPosition || !audioCtxRef.current) return;
    updateSpatialAudio(myPosition.x, myPosition.y);
    socket?.emit('voice_position', { x: myPosition.x, y: myPosition.y });
  }, [myPosition, voiceOn, updateSpatialAudio, socket]);

  useEffect(() => () => stopVoice(), [stopVoice]);

  return { voiceOn, muted, peerCount, startVoice, stopVoice, toggleMute };
}
