import { useState, useEffect } from 'react';
import { API } from '../context/AuthContext';

const RARITY_COLOR = { common:'#9a9590', rare:'#60a5fa', epic:'#8b5cf6', legendary:'#c9a84c' };
const CAT_ICONS    = { combat:'⚔️', heist:'🏦', social:'👥', progression:'📈', special:'⭐' };

export default function Achievements() {
  const [achievements, setAchievements] = useState([]);
  const [notifications,setNotifications]= useState([]);
  const [filter,  setFilter]  = useState('all');
  const [total,   setTotal]   = useState(0);
  const [unlocked,setUnlocked]= useState(0);

  useEffect(() => {
    API.get('/achievements').then(r => {
      setAchievements(r.data.achievements);
      setTotal(r.data.total);
      setUnlocked(r.data.unlocked);
    }).catch(() => {});

    API.get('/achievements/notifications').then(r => {
      setNotifications(r.data.notifications);
    }).catch(() => {});
  }, []);

  const cats = ['all', ...new Set(achievements.map(a => a.category))];
  const filtered = filter === 'all' ? achievements : achievements.filter(a => a.category === filter);

  const pct = total > 0 ? Math.round((unlocked / total) * 100) : 0;

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:1000, margin:'0 auto' }}>

        {/* Unlock notifications */}
        {notifications.length > 0 && (
          <div style={{ background:'linear-gradient(135deg,#1a1200,#0a0800)', border:'1px solid #c9a84c', padding:20, marginBottom:24 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#c9a84c', marginBottom:12 }}>🎉 NEW ACHIEVEMENTS UNLOCKED</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:12 }}>
              {notifications.map(n => (
                <div key={n.achievement_id} style={{ display:'flex', alignItems:'center', gap:10, background:'#111', padding:'10px 14px', border:'1px solid #c9a84c33' }}>
                  <span style={{ fontSize:24 }}>{n.icon}</span>
                  <div>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:2, color: RARITY_COLOR[n.rarity] }}>{n.name}</div>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:1 }}>
                      +${n.reward_cash?.toLocaleString()} · +{n.reward_xp} XP
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Header */}
        <div style={{ marginBottom:32 }}>
          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>Achievements</div>
          <div style={{ display:'flex', alignItems:'center', gap:16, marginTop:12, flexWrap:'wrap' }}>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:12, color:'#9a9590', letterSpacing:2 }}>
              {unlocked}/{total} UNLOCKED
            </div>
            <div style={{ flex:1, maxWidth:300, background:'#222', height:6, borderRadius:3 }}>
              <div style={{ background:'linear-gradient(to right,#8b0000,#c9a84c)', height:6, borderRadius:3, width:`${pct}%`, transition:'width 0.5s' }}/>
            </div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, color:'#c9a84c' }}>{pct}%</div>
          </div>
        </div>

        {/* Category filter */}
        <div style={{ display:'flex', gap:0, marginBottom:24, borderBottom:'1px solid #2a2a2a', overflowX:'auto' }}>
          {cats.map(c => (
            <button key={c} onClick={() => setFilter(c)} style={{
              padding:'10px 16px', background:'none', whiteSpace:'nowrap',
              color: filter===c ? '#e8e4dc' : '#9a9590',
              borderBottom: filter===c ? '2px solid #8b0000' : '2px solid transparent',
              fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1,
            }}>
              {c === 'all' ? '🏆 All' : `${CAT_ICONS[c]} ${c.charAt(0).toUpperCase()+c.slice(1)}`}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:8 }}>
          {filtered.map(a => {
            const rc = RARITY_COLOR[a.rarity] || '#9a9590';
            return (
              <div key={a.achievement_id} style={{
                background: a.unlocked ? '#0f1200' : '#111',
                border: `1px solid ${a.unlocked ? rc+'66' : '#1a1a1a'}`,
                padding:'16px 14px', position:'relative', overflow:'hidden',
                opacity: a.unlocked ? 1 : 0.65,
                transition:'opacity 0.2s',
              }}>
                {/* Rarity stripe */}
                <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:rc, opacity:a.unlocked?1:0.3 }}/>

                <div style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
                  <div style={{ fontSize:32, lineHeight:1, flexShrink:0, filter: a.unlocked?'none':'grayscale(1)' }}>{a.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
                      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:2, color: a.unlocked ? rc : '#555' }}>{a.name}</div>
                      <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, letterSpacing:1, color:rc, textTransform:'uppercase' }}>{a.rarity}</span>
                    </div>
                    <p style={{ fontSize:12, color: a.unlocked?'#9a9590':'#444', lineHeight:1.5, marginBottom:8 }}>{a.description}</p>

                    {/* Progress bar */}
                    {!a.unlocked && a.current_value > 0 && (
                      <div style={{ marginBottom:6 }}>
                        <div style={{ background:'#1a1a1a', height:4, borderRadius:2 }}>
                          <div style={{ background:rc, height:4, borderRadius:2, width:`${a.pct}%`, transition:'width 0.5s', opacity:0.7 }}/>
                        </div>
                        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:3, letterSpacing:1 }}>
                          {a.current_value}/{a.condition_value}
                        </div>
                      </div>
                    )}

                    <div style={{ display:'flex', gap:12, alignItems:'center' }}>
                      {a.reward_cash > 0 && <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#c9a84c', letterSpacing:1 }}>💰 ${a.reward_cash.toLocaleString()}</span>}
                      {a.reward_xp > 0  && <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#8b5cf6', letterSpacing:1 }}>⬆ {a.reward_xp} XP</span>}
                      {a.unlocked && <span style={{ marginLeft:'auto', fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#22c55e', letterSpacing:1 }}>✓ UNLOCKED</span>}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
