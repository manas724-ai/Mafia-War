import { useState, useEffect, useRef } from 'react';
import { useAuth, API } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const BADGE = {
  success: { bg:'#0f1a0f', border:'#22c55e', color:'#22c55e' },
  danger:  { bg:'#1a0000', border:'#c0392b', color:'#c0392b' },
  gold:    { bg:'#1a1200', border:'#c9a84c', color:'#c9a84c' },
  muted:   { bg:'#111',    border:'#2a2a2a', color:'#9a9590' },
};

function StatCard({ label, value, color='#e8e4dc', sub }) {
  return (
    <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:'18px 16px' }}>
      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590', marginBottom:6, textTransform:'uppercase' }}>{label}</div>
      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, color, letterSpacing:1 }}>{value}</div>
      {sub && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:4 }}>{sub}</div>}
    </div>
  );
}

export default function Admin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('dashboard');

  // State per tab
  const [stats,   setStats]   = useState(null);
  const [health,  setHealth]  = useState(null);
  const [users,   setUsers]   = useState([]);
  const [reports, setReports] = useState([]);
  const [ipBans,  setIpBans]  = useState([]);
  const [rooms,   setRooms]   = useState([]);
  const [errors,  setErrors]  = useState([]);
  const [chat,    setChat]    = useState([]);
  const [hofList, setHofList] = useState([]);

  const [search,    setSearch]    = useState('');
  const [newIp,     setNewIp]     = useState({ ip:'', reason:'', hours:'' });
  const [broadcast, setBroadcast] = useState({ message:'', channel:'global' });
  const [cashAdj,   setCashAdj]   = useState({ user_id:'', amount:'' });
  const [msg,       setMsg]       = useState('');
  const [loading,   setLoading]   = useState(false);
  const pollRef = useRef(null);

  useEffect(() => {
    if (!user || !['admin','owner'].includes(user.role)) navigate('/lobby');
  }, [user, navigate]);

  const load = async () => {
    try {
      const [s, h] = await Promise.all([
        API.get('/admin/stats').then(r => r.data),
        API.get('/monitor/health').then(r => r.data).catch(() => null),
      ]);
      setStats(s); setHealth(h);
    } catch {}
  };

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 15000);
    return () => clearInterval(pollRef.current);
  }, []);

  useEffect(() => {
    if (tab === 'users')    loadUsers();
    if (tab === 'reports')  API.get('/admin/reports').then(r => setReports(r.data.reports)).catch(()=>{});
    if (tab === 'ipbans')   API.get('/admin/ip-bans').then(r => setIpBans(r.data.bans)).catch(()=>{});
    if (tab === 'rooms')    API.get('/admin/active-rooms').then(r => setRooms(r.data.rooms)).catch(()=>{});
    if (tab === 'errors')   API.get('/monitor/errors').then(r => setErrors(r.data.errors)).catch(()=>{});
    if (tab === 'chat')     API.get('/monitor/chat').then(r => setChat(r.data.chats)).catch(()=>{});
    if (tab === 'hof')      API.get('/season-admin/hall-of-fame').then(r => setHofList(r.data.hall_of_fame)).catch(()=>{});
  }, [tab]);

  const loadUsers = async () => {
    try { const r = await API.get(`/admin/users?search=${search}&limit=50`); setUsers(r.data.users); }
    catch {}
  };

  const action = async (fn, successMsg) => {
    setMsg(''); setLoading(true);
    try { const r = await fn(); setMsg(`✅ ${r.data?.message || successMsg}`); load(); loadUsers(); }
    catch(err) { setMsg(`❌ ${err.response?.data?.error || 'Action failed.'}`); }
    finally { setLoading(false); }
  };

  const TABS = [
    { key:'dashboard', label:'📊 Dashboard' },
    { key:'health',    label:'⚡ Health' },
    { key:'users',     label:'👥 Users' },
    { key:'rooms',     label:'🎮 Rooms' },
    { key:'reports',   label:'🚨 Reports' },
    { key:'ipbans',    label:'🔒 IP Bans' },
    { key:'chat',      label:'💬 Chat Log' },
    { key:'errors',    label:'🔴 Errors' },
    { key:'broadcast', label:'📢 Broadcast' },
    { key:'hof',       label:'🏆 Hall of Fame' },
    { key:'season',    label:'🔄 Season' },
  ];

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a' }}>
      {/* NAV */}
      <nav style={{ background:'#111', borderBottom:'1px solid #2a2a2a', padding:'12px 24px', display:'flex', alignItems:'center', gap:12 }}>
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:4, color:'#e8e4dc' }}>ADMIN PANEL</div>
        <span style={{ background:'#1a0000', border:'1px solid #8b0000', color:'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, padding:'3px 8px' }}>RESTRICTED</span>
        {stats && (
          <div style={{ marginLeft:16, fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', display:'flex', gap:16 }}>
            <span>👥 {stats.total_users}</span>
            <span style={{ color:'#22c55e' }}>🎮 {stats.active_rooms} live</span>
            <span style={{ color:'#c9a84c' }}>💰 ${((stats.total_revenue_cents||0)/100).toFixed(0)}</span>
            {stats.open_reports > 0 && <span style={{ color:'#c0392b' }}>🚨 {stats.open_reports} reports</span>}
          </div>
        )}
        <button className="btn btn-ghost btn-sm" style={{ marginLeft:'auto' }} onClick={() => navigate('/lobby')}>← Lobby</button>
      </nav>

      {/* TABS */}
      <div style={{ background:'#111', borderBottom:'1px solid #1a1a1a', display:'flex', overflowX:'auto', padding:'0 24px' }}>
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{
            padding:'10px 14px', background:'none', color: tab===t.key?'#e8e4dc':'#9a9590',
            borderBottom: tab===t.key?'2px solid #8b0000':'2px solid transparent',
            fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1, whiteSpace:'nowrap',
            flexShrink:0,
          }}>{t.label}</button>
        ))}
      </div>

      <div style={{ padding:'24px', maxWidth:1100, margin:'0 auto' }}>
        {msg && <div style={{ marginBottom:16, padding:'10px 16px', background: msg.startsWith('✅')?'#0f1a0f':'#1a0000', border:`1px solid ${msg.startsWith('✅')?'#22c55e':'#c0392b'}`, color: msg.startsWith('✅')?'#22c55e':'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>{msg}</div>}

        {/* ── DASHBOARD ── */}
        {tab==='dashboard' && stats && (
          <div className="animate-fadeIn">
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:8, marginBottom:24 }}>
              <StatCard label="Total Users"    value={stats.total_users}         color="#e8e4dc"/>
              <StatCard label="Active Rooms"   value={stats.active_rooms||0}     color="#22c55e"/>
              <StatCard label="Premium Users"  value={stats.premium_users||0}    color="#c9a84c"/>
              <StatCard label="Today Signups"  value={stats.today_signups||0}    color="#8b5cf6"/>
              <StatCard label="Today Matches"  value={stats.total_matches||0}    color="#60a5fa"/>
              <StatCard label="Open Reports"   value={stats.open_reports||0}     color={stats.open_reports>0?'#c0392b':'#22c55e'}/>
              <StatCard label="Banned Users"   value={stats.banned_users||0}     color="#c0392b"/>
              <StatCard label="Total Revenue"  value={`$${((stats.total_revenue_cents||0)/100).toFixed(0)}`} color="#c9a84c" sub="AUD"/>
            </div>

            {/* Quick actions */}
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>Quick Actions</div>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              <button className="btn btn-ghost btn-sm" onClick={() => setTab('users')}>Manage Users</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setTab('reports')}>View Reports</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setTab('broadcast')}>Send Broadcast</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setTab('health')}>Server Health</button>
            </div>

            {/* Cash adjustment */}
            <div style={{ marginTop:24, background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c9a84c', marginBottom:12 }}>Adjust Player Cash</div>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                <input className="input" placeholder="User ID" value={cashAdj.user_id} onChange={e=>setCashAdj(p=>({...p,user_id:e.target.value}))} style={{ width:120 }}/>
                <input className="input" placeholder="Amount (negative to remove)" value={cashAdj.amount} onChange={e=>setCashAdj(p=>({...p,amount:e.target.value}))} style={{ width:200 }}/>
                <button className="btn btn-primary btn-sm" disabled={loading}
                  onClick={()=>action(()=>API.post('/admin/adjust-cash',cashAdj),'Cash adjusted.')}>
                  Adjust Cash
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── HEALTH ── */}
        {tab==='health' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Server Health</div>
            {!health ? (
              <div style={{ color:'#9a9590' }}>Loading health data...</div>
            ) : (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:12 }}>
                {[
                  { title:'Server', items:[
                    ['Uptime',    health.server?.uptime_human],
                    ['Node',      health.server?.node_version],
                    ['Hostname',  health.server?.hostname],
                    ['Platform',  health.server?.platform],
                  ]},
                  { title:'Memory', items:[
                    ['Process RAM', `${health.memory?.used_mb} MB`],
                    ['Heap Used',   `${health.memory?.heap_mb} MB`],
                    ['Heap Total',  `${health.memory?.heap_total} MB`],
                    ['System Used', `${health.memory?.system_pct}%`],
                  ]},
                  { title:'CPU', items:[
                    ['Load 1m',  health.cpu?.load_1m],
                    ['Load 5m',  health.cpu?.load_5m],
                    ['Load 15m', health.cpu?.load_15m],
                    ['Cores',    health.cpu?.cores],
                  ]},
                  { title:'Game', items:[
                    ['Active Rooms',  health.game?.active_rooms],
                    ['Waiting Rooms', health.game?.waiting_rooms],
                    ['Online Players',health.game?.online_players],
                    ['Total Users',   health.game?.total_users],
                    ['Today Signups', health.game?.today_signups],
                  ]},
                  { title:'Revenue', items:[
                    ['Today (AUD)', `$${health.revenue?.today_aud}`],
                    ['Total (AUD)', `$${health.revenue?.total_aud}`],
                  ]},
                  { title:'Errors', items:[
                    ['Errors Today',   health.errors?.today],
                    ['Slow Requests',  health.errors?.slow_requests],
                    ['IP Bans Active', health.errors?.ip_bans],
                    ['Database',       health.database?.status],
                  ]},
                ].map(section => (
                  <div key={section.title} style={{ background:'#111', border:'1px solid #2a2a2a', padding:18 }}>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c9a84c', marginBottom:12 }}>{section.title}</div>
                    {section.items.map(([label, value]) => (
                      <div key={label} style={{ display:'flex', justifyContent:'space-between', padding:'5px 0', borderBottom:'1px solid #1a1a1a', fontSize:13 }}>
                        <span style={{ color:'#9a9590', fontFamily:'Share Tech Mono, monospace', fontSize:10 }}>{label}</span>
                        <span style={{ color:'#e8e4dc', fontFamily:'Bebas Neue, sans-serif', fontSize:15, letterSpacing:1 }}>{value ?? '—'}</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
            <button className="btn btn-ghost btn-sm" style={{ marginTop:16 }} onClick={load}>Refresh</button>
          </div>
        )}

        {/* ── USERS ── */}
        {tab==='users' && (
          <div className="animate-fadeIn">
            <div style={{ display:'flex', gap:12, marginBottom:20, flexWrap:'wrap' }}>
              <input className="input" placeholder="Search username or email..." value={search} onChange={e=>setSearch(e.target.value)} style={{ flex:1, maxWidth:320 }}/>
              <button className="btn btn-primary btn-sm" onClick={loadUsers}>Search</button>
            </div>
            <div style={{ overflowX:'auto' }}>
              <table style={{ width:'100%', borderCollapse:'collapse', minWidth:700 }}>
                <thead>
                  <tr style={{ borderBottom:'1px solid #2a2a2a' }}>
                    {['ID','Username','Email','Role','Rank','Kills','Cash','Status','Actions'].map(h=>(
                      <th key={h} style={{ padding:'8px 10px', textAlign:'left', fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590', whiteSpace:'nowrap' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {users.map(u=>(
                    <tr key={u.id} style={{ borderBottom:'1px solid #1a1a1a' }}>
                      <td style={{ padding:'8px 10px', color:'#555', fontSize:12 }}>{u.id}</td>
                      <td style={{ padding:'8px 10px', color:'#e8e4dc', fontWeight:500 }}>{u.username}</td>
                      <td style={{ padding:'8px 10px', color:'#9a9590', fontSize:11 }}>{u.email}</td>
                      <td style={{ padding:'8px 10px' }}>
                        <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:1, color:u.role==='admin'?'#c0392b':u.role==='premium'?'#c9a84c':'#9a9590' }}>
                          {u.role?.toUpperCase()}
                        </span>
                      </td>
                      <td style={{ padding:'8px 10px', color:'#9a9590', fontSize:12 }}>{u.rank_level}</td>
                      <td style={{ padding:'8px 10px', color:'#9a9590', fontSize:12 }}>{u.kills}</td>
                      <td style={{ padding:'8px 10px', color:'#9a9590', fontSize:12 }}>${u.cash?.toLocaleString()}</td>
                      <td style={{ padding:'8px 10px' }}>
                        <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:u.is_banned?'#c0392b':'#22c55e' }}>
                          {u.is_banned?'BANNED':'ACTIVE'}
                        </span>
                      </td>
                      <td style={{ padding:'8px 10px' }}>
                        <div style={{ display:'flex', gap:4 }}>
                          {u.is_banned
                            ? <button className="btn btn-success btn-sm" style={{ fontSize:11, padding:'4px 8px' }} onClick={()=>action(()=>API.post('/admin/unban',{user_id:u.id}),'Unbanned.')}>Unban</button>
                            : <button className="btn btn-danger btn-sm"  style={{ fontSize:11, padding:'4px 8px' }} onClick={()=>action(()=>API.post('/admin/ban',{user_id:u.id,reason:'Admin action'}),'Banned.')}>Ban</button>
                          }
                          <button className="btn btn-ghost btn-sm" style={{ fontSize:11, padding:'4px 8px' }}
                            onClick={()=>action(()=>API.post('/admin/promote',{user_id:u.id,role:u.role==='player'?'admin':'player'}),u.role==='player'?'Promoted to admin.':'Demoted to player.')}>
                            {u.role==='player'?'→Admin':'→Player'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {users.length===0&&<tr><td colSpan={9} style={{ padding:32, textAlign:'center', color:'#9a9590' }}>Search for users above.</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── ROOMS ── */}
        {tab==='rooms' && (
          <div className="animate-fadeIn">
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc' }}>Active Rooms</div>
              <button className="btn btn-ghost btn-sm" onClick={()=>API.get('/admin/active-rooms').then(r=>setRooms(r.data.rooms))}>Refresh</button>
            </div>
            {rooms.map(r=>(
              <div key={r.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 18px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc' }}>{r.name}</div>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1, marginTop:2 }}>
                    {r.room_code} · {r.map_id} · {r.mode} · {r.current_players}/{r.max_players} players · Host: {r.host_name}
                  </div>
                </div>
                <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:r.status==='active'?'#22c55e':'#c9a84c' }}>{r.status?.toUpperCase()}</span>
                <button className="btn btn-danger btn-sm" onClick={()=>action(()=>API.post('/admin/end-room',{room_code:r.room_code}),'Room ended.')}>Force End</button>
              </div>
            ))}
            {rooms.length===0&&<div style={{ color:'#9a9590', padding:'40px 0', textAlign:'center' }}>No active rooms.</div>}
          </div>
        )}

        {/* ── REPORTS ── */}
        {tab==='reports' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Open Reports ({reports.length})</div>
            {reports.length===0?<div style={{ color:'#9a9590', padding:'40px 0', textAlign:'center' }}>No open reports.</div>:reports.map(r=>(
              <div key={r.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 18px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ flex:1 }}>
                  <div style={{ color:'#e8e4dc' }}><span style={{ color:'#c0392b' }}>{r.reported_name}</span> reported by {r.reporter_name}</div>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', marginTop:4, letterSpacing:1 }}>{r.reason?.toUpperCase()} · {new Date(r.created_at).toLocaleDateString()}</div>
                  {r.description&&<div style={{ fontSize:13, color:'#9a9590', marginTop:6 }}>{r.description}</div>}
                </div>
                <div style={{ display:'flex', gap:8 }}>
                  <button className="btn btn-danger btn-sm" onClick={()=>action(()=>API.post('/admin/ban',{user_id:r.reported_id,reason:r.reason}),'Player banned.')}>Ban</button>
                  <button className="btn btn-ghost btn-sm" onClick={()=>action(()=>API.post(`/admin/reports/${r.id}/resolve`),'Resolved.').then(()=>setReports(p=>p.filter(x=>x.id!==r.id)))}>Dismiss</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── IP BANS ── */}
        {tab==='ipbans' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>IP Bans</div>
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20, marginBottom:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c0392b', marginBottom:12 }}>Add IP Ban</div>
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                <input className="input" placeholder="IP Address..." value={newIp.ip} onChange={e=>setNewIp(p=>({...p,ip:e.target.value}))} style={{ width:160 }}/>
                <input className="input" placeholder="Reason..." value={newIp.reason} onChange={e=>setNewIp(p=>({...p,reason:e.target.value}))} style={{ flex:1, minWidth:160 }}/>
                <input className="input" placeholder="Hours (blank=permanent)" value={newIp.hours} onChange={e=>setNewIp(p=>({...p,hours:e.target.value}))} style={{ width:160 }}/>
                <button className="btn btn-danger btn-sm" disabled={loading} onClick={()=>action(()=>API.post('/admin/ip-ban',newIp),'IP banned.').then(()=>API.get('/admin/ip-bans').then(r=>setIpBans(r.data.bans)))}>Ban IP</button>
              </div>
            </div>
            {ipBans.map(b=>(
              <div key={b.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'12px 18px', marginBottom:6, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:12, color:'#c0392b', letterSpacing:2, minWidth:140 }}>{b.ip_address}</div>
                <div style={{ flex:1, fontSize:13, color:'#9a9590' }}>{b.reason}</div>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#555' }}>
                  {b.expires_at ? `Expires: ${new Date(b.expires_at).toLocaleDateString()}` : 'Permanent'}
                </div>
                <button className="btn btn-ghost btn-sm" onClick={()=>action(()=>API.delete(`/admin/ip-ban/${encodeURIComponent(b.ip_address)}`),'IP unbanned.').then(()=>setIpBans(p=>p.filter(x=>x.id!==b.id)))}>Remove</button>
              </div>
            ))}
            {ipBans.length===0&&<div style={{ color:'#9a9590', padding:'20px 0' }}>No IP bans.</div>}
          </div>
        )}

        {/* ── CHAT LOG ── */}
        {tab==='chat' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Chat Log</div>
            <div style={{ background:'#0a0a0a', border:'1px solid #1a1a1a', padding:16, maxHeight:600, overflow:'auto', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>
              {chat.map(c=>(
                <div key={c.id} style={{ padding:'4px 0', borderBottom:'1px solid #111', display:'flex', gap:12 }}>
                  <span style={{ color:'#555', minWidth:80 }}>{new Date(c.sent_at).toLocaleTimeString()}</span>
                  <span style={{ color:'#c9a84c', minWidth:100 }}>{c.username}</span>
                  <span style={{ color:'#e8e4dc' }}>{c.message}</span>
                  <span style={{ color:'#333', marginLeft:'auto' }}>{c.channel}</span>
                </div>
              ))}
              {chat.length===0&&<div style={{ color:'#9a9590', padding:20 }}>No chat messages.</div>}
            </div>
          </div>
        )}

        {/* ── ERRORS ── */}
        {tab==='errors' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Error Log</div>
            {errors.map(e=>(
              <div key={e.id} style={{ background:'#111', border:`1px solid ${e.level==='critical'?'#c0392b':e.level==='error'?'#8b0000':'#2a2a2a'}`, padding:'12px 16px', marginBottom:8 }}>
                <div style={{ display:'flex', gap:12, alignItems:'center', marginBottom:6 }}>
                  <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:e.level==='critical'?'#c0392b':e.level==='error'?'#f59e0b':'#9a9590' }}>{e.level?.toUpperCase()}</span>
                  <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555' }}>{new Date(e.created_at).toLocaleString()}</span>
                  {e.route&&<span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590' }}>{e.route}</span>}
                </div>
                <div style={{ color:'#e8e4dc', fontSize:13 }}>{e.message}</div>
                {e.stack&&<div style={{ marginTop:6, fontSize:11, color:'#555', fontFamily:'monospace', whiteSpace:'pre-wrap', maxHeight:100, overflow:'auto' }}>{e.stack}</div>}
              </div>
            ))}
            {errors.length===0&&<div style={{ color:'#9a9590', padding:'40px 0', textAlign:'center' }}>No errors logged today.</div>}
          </div>
        )}

        {/* ── BROADCAST ── */}
        {tab==='broadcast' && (
          <div className="animate-fadeIn" style={{ maxWidth:600 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Send Broadcast</div>
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:24, display:'flex', flexDirection:'column', gap:16 }}>
              <div>
                <label className="label">Channel</label>
                <select className="input" value={broadcast.channel} onChange={e=>setBroadcast(p=>({...p,channel:e.target.value}))} style={{ background:'#161616' }}>
                  <option value="global">Global (All Players)</option>
                  <option value="premium">Premium Only</option>
                  <option value="faction">Faction Leaders</option>
                </select>
              </div>
              <div>
                <label className="label">Message</label>
                <textarea className="input" rows={4} value={broadcast.message} onChange={e=>setBroadcast(p=>({...p,message:e.target.value}))}
                  placeholder="Message shown to all connected players..." style={{ resize:'vertical' }}/>
              </div>
              <button className="btn btn-primary" disabled={loading||!broadcast.message}
                onClick={()=>action(()=>API.post('/monitor/broadcast',broadcast),'Broadcast sent.')}>
                📢 Send to All Players
              </button>
              <p style={{ fontSize:12, color:'#555', fontFamily:'Share Tech Mono, monospace', letterSpacing:1 }}>
                This message will appear immediately in the game UI for all connected players.
              </p>
            </div>
          </div>
        )}

        {/* ── HALL OF FAME ── */}
        {tab==='hof' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Season Hall of Fame</div>
            {hofList.length===0?<div style={{ color:'#9a9590', padding:'40px 0', textAlign:'center' }}>No archived seasons yet.</div>:(
              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead>
                  <tr style={{ borderBottom:'1px solid #2a2a2a' }}>
                    {['#','Season','Player','Faction','Tier','Kills','Heists','Season XP'].map(h=>(
                      <th key={h} style={{ padding:'8px 10px', textAlign:'left', fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {hofList.map((h,i)=>(
                    <tr key={h.id} style={{ borderBottom:'1px solid #1a1a1a' }}>
                      <td style={{ padding:'8px 10px', fontFamily:'Bebas Neue, sans-serif', fontSize:20, color:i===0?'#c9a84c':'#9a9590' }}>{h.rank}</td>
                      <td style={{ padding:'8px 10px', fontSize:12, color:'#9a9590' }}>{h.season_name}</td>
                      <td style={{ padding:'8px 10px', color:'#e8e4dc', fontWeight:500 }}>{h.username}</td>
                      <td style={{ padding:'8px 10px', fontSize:12, color:'#9a9590' }}>{h.faction}</td>
                      <td style={{ padding:'8px 10px', fontFamily:'Bebas Neue, sans-serif', fontSize:18, color:'#c9a84c' }}>{h.final_tier}</td>
                      <td style={{ padding:'8px 10px', fontSize:12, color:'#9a9590' }}>{h.total_kills}</td>
                      <td style={{ padding:'8px 10px', fontSize:12, color:'#9a9590' }}>{h.heists_won}</td>
                      <td style={{ padding:'8px 10px', fontFamily:'Bebas Neue, sans-serif', fontSize:16, color:'#8b5cf6' }}>{h.season_xp?.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* ── SEASON ADMIN ── */}
        {tab==='season' && (
          <div className="animate-fadeIn" style={{ maxWidth:600 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>Season Management</div>

            <div style={{ background:'#1a0000', border:'1px solid #8b0000', padding:20, marginBottom:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c0392b', marginBottom:8 }}>⚠ END CURRENT SEASON</div>
              <p style={{ fontSize:13, color:'#9a9590', marginBottom:16, lineHeight:1.6 }}>
                This archives all player standings, awards Season Champion badge to #1 player, clears old faction data, and optionally starts a new season. This action cannot be undone.
              </p>
              <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                <div>
                  <label className="label">New Season Name (optional)</label>
                  <input className="input" placeholder="Season 2: Shadow Empire" id="new_season_name"/>
                </div>
                <div>
                  <label className="label">Theme (optional)</label>
                  <input className="input" placeholder="Underground Crime" id="new_season_theme"/>
                </div>
                <button className="btn btn-danger" disabled={loading} onClick={()=>{
                  const name  = document.getElementById('new_season_name')?.value;
                  const theme = document.getElementById('new_season_theme')?.value;
                  if(!window.confirm('End the current season? This cannot be undone.')) return;
                  action(()=>API.post('/season-admin/reset',{new_season_name:name,new_season_theme:theme}),'Season ended.');
                }}>End Season & Archive Results</button>
              </div>
            </div>

            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c9a84c', marginBottom:8 }}>Weekly Leaderboard Reset</div>
              <p style={{ fontSize:13, color:'#9a9590', marginBottom:12 }}>Archives this week's faction standings and removes data older than 12 weeks.</p>
              <button className="btn btn-secondary" disabled={loading} onClick={()=>action(()=>API.post('/season-admin/weekly-reset'),'Weekly reset done.')}>
                Run Weekly Reset
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
