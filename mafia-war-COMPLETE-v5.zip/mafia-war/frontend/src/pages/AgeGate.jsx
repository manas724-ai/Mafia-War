import { useState } from 'react';

export default function AgeGate({ onConfirm }) {
  const [dob, setDob] = useState({ day: '', month: '', year: '' });
  const [error, setError] = useState('');

  const verify = () => {
    const { day, month, year } = dob;
    if (!day || !month || !year) return setError('Please enter your full date of birth.');
    const birth = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    if (isNaN(birth.getTime())) return setError('Invalid date of birth.');
    const age = Math.floor((Date.now() - birth.getTime()) / (365.25 * 24 * 60 * 60 * 1000));
    if (age < 18) {
      setError('You must be 18 or older to enter Mafia War. Redirecting...');
      setTimeout(() => window.location.href = 'https://www.google.com', 2000);
      return;
    }
    sessionStorage.setItem('mw_age_ok', '1');
    onConfirm();
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, background: '#0a0a0a',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      zIndex: 9999, flexDirection: 'column', gap: 0, padding: 24,
    }}>
      <div style={{
        background: '#111', border: '1px solid #2a2a2a',
        padding: '48px 40px', maxWidth: 440, width: '100%',
        textAlign: 'center',
      }}>
        {/* Warning icon */}
        <div style={{ fontSize: 56, marginBottom: 16 }}>🔞</div>

        <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 32, letterSpacing: 4, color: '#c0392b', marginBottom: 8 }}>
          ADULTS ONLY
        </div>
        <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 11, letterSpacing: 3, color: '#9a9590', textTransform: 'uppercase', marginBottom: 24 }}>
          Mafia War — 18+ Strictly Enforced
        </div>

        <p style={{ color: '#9a9590', fontSize: 14, lineHeight: 1.6, marginBottom: 32 }}>
          This game contains graphic violence, adult themes, simulated criminal activity, and mature language.
          You must be <strong style={{ color: '#e8e4dc' }}>18 years or older</strong> to enter.
        </p>

        <div style={{ marginBottom: 24 }}>
          <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 10, letterSpacing: 2, color: '#9a9590', textTransform: 'uppercase', marginBottom: 10, textAlign: 'left' }}>
            Date of Birth
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 2fr', gap: 8 }}>
            {[
              { key: 'day',   placeholder: 'DD',   max: 31  },
              { key: 'month', placeholder: 'MM',   max: 12  },
              { key: 'year',  placeholder: 'YYYY', max: 2099},
            ].map(f => (
              <input key={f.key}
                type="number" placeholder={f.placeholder}
                value={dob[f.key]}
                onChange={e => setDob(prev => ({ ...prev, [f.key]: e.target.value }))}
                style={{
                  padding: '10px 12px', background: '#0a0a0a', border: '1px solid #2a2a2a',
                  color: '#e8e4dc', fontSize: 16, fontFamily: 'Share Tech Mono, monospace',
                  textAlign: 'center', borderRadius: 2, outline: 'none',
                }}
                onFocus={e => e.target.style.borderColor = '#8b0000'}
                onBlur={e => e.target.style.borderColor = '#2a2a2a'}
              />
            ))}
          </div>
        </div>

        {error && <div style={{ color: '#c0392b', fontSize: 13, fontFamily: 'Share Tech Mono, monospace', marginBottom: 16 }}>{error}</div>}

        <button onClick={verify} style={{
          width: '100%', padding: '14px 0',
          fontFamily: 'Bebas Neue, sans-serif', fontSize: 20, letterSpacing: 3,
          background: '#8b0000', color: '#e8e4dc', border: 'none', cursor: 'pointer',
          transition: 'background 0.2s',
        }}
          onMouseOver={e => e.target.style.background = '#c0392b'}
          onMouseOut={e => e.target.style.background = '#8b0000'}
        >
          Confirm & Enter
        </button>

        <p style={{ marginTop: 20, fontSize: 12, color: '#444', lineHeight: 1.6 }}>
          © 2026 Aussi-Nexus Group (ABN 76 947 108 181).<br/>
          By entering you confirm you are 18+ and agree to our Terms of Service.
        </p>
      </div>
    </div>
  );
}
