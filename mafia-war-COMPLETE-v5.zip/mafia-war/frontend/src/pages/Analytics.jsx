import { useState, useEffect, useRef } from 'react';
import { useAuth, API } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

// Mini chart using SVG — no external deps beyond what's already in frontend
function LineChart({ data, color = '#c9a84c', label, height = 80 }) {
  if (!data?.length) return <div style={{ height, display:'flex', alignItems:'center', justifyContent:'center', color:'#555', fontSize:12 }}>No data</div>;
  const vals   = data.map(d => d.value);
  const max    = Math.max(...vals, 1);
  const min    = Math.min(...vals, 0);
  const range  = max - min || 1;
  const W = 300, H = height;
  const pts = vals.map((v, i) => `${(i / (vals.length - 1)) * W},${H - ((v - min) / range) * H}`).join(' ');

  return (
    <div>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display:'block' }}>
        <polyline points={pts} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke"/>
        <polygon points={`0,${H} ${pts} ${W},${H}`} fill={color} opacity="0.08"/>
      </svg>
      <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:4 }}>
        <span>{data[0]?.label || ''}</span>
        <span>{data[data.length-1]?.label || ''}</span>
      </div>
    </div>
  );
}

function BarChart({ data, color = '#8b0000', height = 80 }) {
  if (!data?.length) return <div style={{ height, display:'flex', alignItems:'center', justifyContent:'center', color:'#555', fontSize:12 }}>No data</div>;
  const max = Math.max(...data.map(d => d.value), 1);
  return (
    <div style={{ display:'flex', alignItems:'flex-end', gap:2, height }}>
      {data.map((d, i) => (
        <div key={i} title={`${d.label}: ${d.value}`} style={{ flex:1, background:color, height:`${(d.value / max) * 100}%`, minHeight:2, opacity:0.8, cursor:'default', borderRadius:'2px 2px 0 0' }}/>
      ))}
    </div>
  );
}

export default function Analytics() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [summary,   setSummary]   = useState(null);
  const [revenue,   setRevenue]   = useState([]);
  const [players,   setPlayers]   = useState({ new:[], active:[] });
  const [matches,   setMatches]   = useState([]);
  const [retention, setRetention] = useState(null);
  const [days,      setDays]      = useState(30);

  useEffect(() => {
    if (!user || !['admin','owner'].includes(user.role)) navigate('/lobby');
  }, [user, navigate]);

  const load = async () => {
    try {
      const [sum, rev, pl, mat, ret] = await Promise.all([
        API.get('/analytics/summary').then(r => r.data),
        API.get(`/analytics/revenue?days=${days}`).then(r => r.data),
        API.get(`/analytics/players?days=${days}`).then(r => r.data),
        API.get(`/analytics/matches?days=${days}`).then(r => r.data),
        API.get('/analytics/retention').then(r => r.data),
      ]);
      setSummary(sum);
      setRevenue(rev.revenue?.map(r => ({ label: r.stat_date?.slice(5), value: (r.total_cents || 0) / 100 })) || []);
      setPlayers({ new: pl.new_users?.map(r => ({ label: r.stat_date?.slice(5), value: r.new_users })) || [], active: pl.active_users?.map(r => ({ label: r.stat_date?.slice(5), value: r.active_users })) || [] });
      setMatches(mat.matches?.map(r => ({ label: r.stat_date?.slice(5), value: r.matches_played })) || []);
      setRetention(ret);
    } catch {}
  };

  useEffect(() => { load(); }, [days]);

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:1100, margin:'0 auto' }}>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:32, flexWrap:'wrap', gap:12 }}>
          <div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>Analytics</div>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2 }}>Revenue · Players · Engagement</div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            {[7, 14, 30, 90].map(d => (
              <button key={d} className={`btn btn-sm ${days===d?'btn-primary':'btn-ghost'}`} onClick={() => setDays(d)}>{d}d</button>
            ))}
          </div>
        </div>

        {/* RETENTION OVERVIEW */}
        {retention && (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))', gap:8, marginBottom:24 }}>
            {[
              { label:'Total Users',  value:retention.total_users,  color:'#e8e4dc' },
              { label:'DAU',          value:retention.dau,           color:'#22c55e', sub:`${retention.d1_rate}% D1` },
              { label:'WAU',          value:retention.wau,           color:'#60a5fa', sub:`${retention.d7_rate}% D7` },
              { label:'MAU',          value:retention.mau,           color:'#8b5cf6', sub:`${retention.d30_rate}% D30` },
              { label:'Premium',      value:retention.premium_users, color:'#c9a84c', sub:`${retention.premium_rate}%` },
              { label:'Banned',       value:retention.banned_users,  color:'#c0392b' },
              { label:'Rev 7D (AUD)', value:`$${summary?.revenue_7d||0}`,  color:'#c9a84c' },
              { label:'Rev 30D (AUD)',value:`$${summary?.revenue_30d||0}`, color:'#c9a84c' },
            ].map(({ label, value, color, sub }) => (
              <div key={label} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 12px', textAlign:'center' }}>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color:'#555', letterSpacing:2, marginBottom:4, textTransform:'uppercase' }}>{label}</div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:26, color, letterSpacing:1 }}>{value}</div>
                {sub && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color:'#555', marginTop:2 }}>{sub}</div>}
              </div>
            ))}
          </div>
        )}

        {/* CHARTS GRID */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24 }}>
          {[
            { title:'Revenue (AUD)', data:revenue,       type:'bar',  color:'#c9a84c' },
            { title:'New Players',   data:players.new,   type:'bar',  color:'#8b5cf6' },
            { title:'Active Players',data:players.active,type:'line', color:'#22c55e' },
            { title:'Matches Played',data:matches,       type:'bar',  color:'#8b0000' },
          ].map(chart => (
            <div key={chart.title} style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>{chart.title}</div>
              {chart.type==='bar'
                ? <BarChart data={chart.data} color={chart.color} height={90}/>
                : <LineChart data={chart.data} color={chart.color} height={90}/>
              }
              {chart.data.length > 0 && (
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, color:chart.color, marginTop:8 }}>
                  {chart.data.reduce((a,b)=>a+b.value,0).toLocaleString()}
                  <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#555', marginLeft:8 }}>total {days}d</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* TOP LISTS */}
        {summary && (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))', gap:16 }}>
            {/* Top Maps */}
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>🗺️ Top Maps</div>
              {summary.top_maps?.map((m,i) => (
                <div key={m.map_id} style={{ display:'flex', justifyContent:'space-between', padding:'6px 0', borderBottom:'1px solid #1a1a1a', fontSize:13 }}>
                  <span style={{ color:'#9a9590' }}>{i+1}. {m.map_id}</span>
                  <span style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, color:'#c9a84c' }}>{m.cnt}</span>
                </div>
              ))}
            </div>

            {/* Top Weapons */}
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>🔫 Top Weapons</div>
              {summary.top_weapons?.map((w,i) => (
                <div key={w.weapon_name} style={{ display:'flex', justifyContent:'space-between', padding:'6px 0', borderBottom:'1px solid #1a1a1a', fontSize:13 }}>
                  <span style={{ color:'#9a9590' }}>{i+1}. {w.weapon_name}</span>
                  <span style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, color:'#c9a84c' }}>{w.cnt}</span>
                </div>
              ))}
            </div>

            {/* Faction Distribution */}
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>⚜️ Faction Split</div>
              {summary.faction_distribution?.map(f => {
                const colors = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };
                const total  = summary.faction_distribution.reduce((a,b)=>a+b.cnt,0);
                const pct    = total > 0 ? Math.round((f.cnt/total)*100) : 0;
                return (
                  <div key={f.faction} style={{ marginBottom:10 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1, color:colors[f.faction]||'#9a9590', marginBottom:4 }}>
                      <span>{f.faction?.toUpperCase()}</span><span>{f.cnt} ({pct}%)</span>
                    </div>
                    <div style={{ background:'#1a1a1a', height:6, borderRadius:3 }}>
                      <div style={{ background:colors[f.faction]||'#555', height:6, borderRadius:3, width:`${pct}%`, transition:'width 0.5s' }}/>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <button className="btn btn-ghost btn-sm" style={{ marginTop:24 }} onClick={() => navigate('/admin')}>← Admin Panel</button>
      </div>
    </div>
  );
}
