import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Auth({ mode = 'login' }) {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const isLogin = mode === 'login';

  const [form, setForm] = useState({ username: '', email: '', password: '', age_confirmed: false });
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const submit = async () => {
    setError('');
    if (!form.email || !form.password) return setError('All fields required.');
    if (!isLogin && !form.username)    return setError('Username required.');
    if (!isLogin && !form.age_confirmed) return setError('You must confirm you are 18+.');

    setLoading(true);
    try {
      if (isLogin) await login(form.email, form.password);
      else         await register(form);
      navigate('/lobby');
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', background: '#0a0a0a',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 24,
    }}>
      <div style={{ width: '100%', maxWidth: 420 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 52, letterSpacing: 6, color: '#e8e4dc', lineHeight: 1 }}>
            MAFIA<span style={{ color: '#c0392b' }}>WAR</span>
          </div>
          <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 11, letterSpacing: 3, color: '#9a9590', textTransform: 'uppercase', marginTop: 4 }}>
            {isLogin ? 'Sign In to Play' : 'Create Your Account'}
          </div>
        </div>

        <div style={{ background: '#111', border: '1px solid #2a2a2a', padding: '32px 28px' }}>
          {!isLogin && (
            <div style={{ marginBottom: 16 }}>
              <label className="label">Username</label>
              <input className="input" type="text" placeholder="Your alias on the streets"
                value={form.username} onChange={e => set('username', e.target.value)}
                onKeyDown={e => e.key === 'Enter' && submit()}
              />
            </div>
          )}

          <div style={{ marginBottom: 16 }}>
            <label className="label">Email</label>
            <input className="input" type="email" placeholder="your@email.com"
              value={form.email} onChange={e => set('email', e.target.value)}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label className="label">Password</label>
            <input className="input" type="password" placeholder={isLogin ? '••••••••' : 'Min 8 characters'}
              value={form.password} onChange={e => set('password', e.target.value)}
              onKeyDown={e => e.key === 'Enter' && submit()}
            />
          </div>

          {!isLogin && (
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'flex', alignItems: 'flex-start', gap: 12, cursor: 'pointer' }}>
                <input type="checkbox" checked={form.age_confirmed}
                  onChange={e => set('age_confirmed', e.target.checked)}
                  style={{ marginTop: 2, accentColor: '#8b0000', width: 16, height: 16, flexShrink: 0 }}
                />
                <span style={{ fontSize: 13, color: '#9a9590', lineHeight: 1.5 }}>
                  I confirm I am <strong style={{ color: '#e8e4dc' }}>18 years or older</strong> and agree to the{' '}
                  <a href="/terms" style={{ color: '#c9a84c' }}>Terms of Service</a>. This game contains mature content.
                </span>
              </label>
            </div>
          )}

          {error && <div className="error-msg" style={{ marginBottom: 16 }}>{error}</div>}

          <button className="btn btn-primary btn-full" onClick={submit} disabled={loading}>
            {loading ? 'Please wait...' : (isLogin ? 'Enter the War' : 'Join the Mafia')}
          </button>

          <div style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: '#9a9590' }}>
            {isLogin ? (
              <>Don't have an account?{' '}
                <Link to="/register" style={{ color: '#c9a84c' }}>Register</Link>
              </>
            ) : (
              <>Already in?{' '}
                <Link to="/login" style={{ color: '#c9a84c' }}>Sign In</Link>
              </>
            )}
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: 24, fontSize: 11, color: '#444', fontFamily: 'Share Tech Mono, monospace', letterSpacing: 1, lineHeight: 1.8 }}>
          🔞 MAFIA WAR — ADULTS 18+ ONLY<br/>
          © 2026 AUSSI-NEXUS GROUP (ABN 76 947 108 181)
        </div>
      </div>
    </div>
  );
}
