import { useState, useEffect } from 'react';
import { useAuth, API } from '../context/AuthContext';

const RARITY_COLOR = { common:'#9a9590', rare:'#60a5fa', epic:'#8b5cf6', legendary:'#c9a84c' };
const TYPE_ICONS   = { title:'👑', badge:'🏅', kill_effect:'💥', profile_bg:'🖼️', faction_emblem:'⚜️' };
const TYPE_LABELS  = { title:'Titles', badge:'Badges', kill_effect:'Kill Effects', profile_bg:'Profile Backgrounds', faction_emblem:'Faction Emblems' };

export default function Cosmetics() {
  const { user } = useAuth();
  const [items,    setItems]    = useState([]);
  const [equipped, setEquipped] = useState({});
  const [cash,     setCash]     = useState(0);
  const [filter,   setFilter]   = useState('all');
  const [msg,      setMsg]      = useState('');
  const [loading,  setLoading]  = useState(false);

  const load = async () => {
    try {
      const { data } = await API.get('/cosmetics');
      setItems(data.cosmetics);
      setEquipped(data.equipped);
      setCash(data.cash);
    } catch { setMsg('Failed to load cosmetics.'); }
  };

  useEffect(() => { load(); }, []);

  const buy = async (cosmetic_id, name) => {
    if (!window.confirm(`Purchase "${name}"?`)) return;
    setMsg(''); setLoading(true);
    try {
      const { data } = await API.post('/cosmetics/buy', { cosmetic_id });
      setMsg(`✅ ${data.message}`);
      setCash(prev => prev - (data.cash_spent || 0));
      load();
    } catch(err) { setMsg(`❌ ${err.response?.data?.error || 'Purchase failed.'}`); }
    finally { setLoading(false); }
  };

  const equip = async (cosmetic_id, name) => {
    setMsg('');
    try {
      const { data } = await API.post('/cosmetics/equip', { cosmetic_id });
      setMsg(`✅ ${name} equipped.`);
      load();
    } catch(err) { setMsg(`❌ ${err.response?.data?.error || 'Failed to equip.'}`); }
  };

  const unequip = async (slot_type) => {
    try {
      await API.post('/cosmetics/unequip', { slot_type });
      setMsg('✅ Unequipped.');
      load();
    } catch {}
  };

  const types = ['all', ...new Set(items.map(i => i.type))];
  const filtered = filter === 'all' ? items : items.filter(i => i.type === filter);

  // Group by type
  const grouped = {};
  filtered.forEach(i => {
    if (!grouped[i.type]) grouped[i.type] = [];
    grouped[i.type].push(i);
  });

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:1000, margin:'0 auto' }}>

        {/* HEADER */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:32, flexWrap:'wrap', gap:12 }}>
          <div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>Cosmetics</div>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2, marginTop:4 }}>
              Titles, badges, kill effects & more
            </div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:2 }}>YOUR CASH</div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c' }}>${cash.toLocaleString()}</div>
          </div>
        </div>

        {/* EQUIPPED SUMMARY */}
        {Object.keys(equipped).length > 0 && (
          <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:'16px 20px', marginBottom:24 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:3, color:'#c9a84c', marginBottom:10 }}>Currently Equipped</div>
            <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
              {Object.entries(equipped).map(([slot, cid]) => {
                const cosm = items.find(i => i.cosmetic_id === cid);
                if (!cosm) return null;
                return (
                  <div key={slot} style={{ display:'flex', alignItems:'center', gap:8, background:'#1a1a1a', padding:'8px 14px' }}>
                    <span>{TYPE_ICONS[slot]}</span>
                    <div>
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2 }}>{TYPE_LABELS[slot]?.toUpperCase()}</div>
                      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, color: RARITY_COLOR[cosm.rarity] || '#e8e4dc', letterSpacing:1 }}>{cosm.name}</div>
                    </div>
                    <button style={{ marginLeft:8, background:'none', border:'none', color:'#555', cursor:'pointer', fontSize:14 }}
                      onClick={() => unequip(slot)}>✕</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {msg && <div style={{ marginBottom:16, padding:'10px 16px', background: msg.startsWith('✅')?'#0f1a0f':'#1a0000', border:`1px solid ${msg.startsWith('✅')?'#22c55e':'#c0392b'}`, color: msg.startsWith('✅')?'#22c55e':'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>{msg}</div>}

        {/* FILTER TABS */}
        <div style={{ display:'flex', gap:0, marginBottom:24, borderBottom:'1px solid #2a2a2a', overflowX:'auto' }}>
          {types.map(t => (
            <button key={t} onClick={() => setFilter(t)} style={{
              padding:'10px 16px', background:'none', whiteSpace:'nowrap',
              color: filter===t ? '#e8e4dc' : '#9a9590',
              borderBottom: filter===t ? '2px solid #8b0000' : '2px solid transparent',
              fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1,
            }}>
              {t === 'all' ? '🎯 All' : `${TYPE_ICONS[t]} ${TYPE_LABELS[t] || t}`}
            </button>
          ))}
        </div>

        {/* ITEMS GRID */}
        {Object.entries(grouped).map(([type, typeItems]) => (
          <div key={type} style={{ marginBottom:32 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>
              {TYPE_ICONS[type]} {TYPE_LABELS[type] || type}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:8 }}>
              {typeItems.map(item => {
                const isEquipped = equipped[item.type] === item.cosmetic_id;
                const rc = RARITY_COLOR[item.rarity] || '#9a9590';

                return (
                  <div key={item.cosmetic_id} style={{
                    background: item.owned ? '#0f0f18' : '#111',
                    border: `1px solid ${isEquipped ? rc : item.owned ? rc+'44' : '#2a2a2a'}`,
                    padding:'16px 14px',
                    opacity: item.locked ? 0.5 : 1,
                    position:'relative',
                  }}>
                    {/* Rarity bar */}
                    <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:rc, opacity: item.owned?1:0.3 }}/>

                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                      <div>
                        <div style={{ fontSize:24, marginBottom:4 }}>
                          {item.css_value?.length <= 2 ? item.css_value : TYPE_ICONS[item.type]}
                        </div>
                        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc' }}>{item.name}</div>
                      </div>
                      <div style={{ textAlign:'right' }}>
                        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, letterSpacing:2, color:rc, textTransform:'uppercase' }}>{item.rarity}</div>
                        {isEquipped && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color:'#22c55e', letterSpacing:1, marginTop:2 }}>✓ EQUIPPED</div>}
                      </div>
                    </div>

                    <p style={{ fontSize:12, color:'#9a9590', marginBottom:12, lineHeight:1.5, minHeight:36 }}>{item.description}</p>

                    {item.unlock_rank > 1 && (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginBottom:8, letterSpacing:1 }}>
                        Requires Rank {item.unlock_rank}
                      </div>
                    )}

                    {!item.owned && !item.locked && item.price_cash > 0 && (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#c9a84c', marginBottom:8, letterSpacing:1 }}>
                        ${item.price_cash.toLocaleString()}
                      </div>
                    )}

                    {/* Action button */}
                    {item.locked ? (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', letterSpacing:1 }}>🔒 Rank {item.unlock_rank} Required</div>
                    ) : item.owned ? (
                      isEquipped ? (
                        <button className="btn btn-ghost btn-sm" style={{ width:'100%', fontSize:11 }} onClick={() => unequip(item.type)}>Unequip</button>
                      ) : (
                        <button className="btn btn-secondary btn-sm" style={{ width:'100%', fontSize:11 }} onClick={() => equip(item.cosmetic_id, item.name)}>Equip</button>
                      )
                    ) : item.price_cash === 0 ? (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590' }}>Earn through gameplay</div>
                    ) : (
                      <button className="btn btn-primary btn-sm" disabled={loading || !item.can_buy} style={{ width:'100%', fontSize:11 }}
                        onClick={() => buy(item.cosmetic_id, item.name)}>
                        {item.can_buy ? `Buy $${item.price_cash.toLocaleString()}` : 'Insufficient funds'}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
