import { useState, useEffect } from 'react';
import { useAuth, API } from '../context/AuthContext';

export default function DailyHub() {
  const { user } = useAuth();
  const [missions, setMissions]  = useState([]);
  const [streak,   setStreak]    = useState({ current_streak:0, longest_streak:0 });
  const [referral, setReferral]  = useState(null);
  const [refCode,  setRefCode]   = useState('');
  const [tab,      setTab]       = useState('missions');
  const [msg,      setMsg]       = useState('');
  const [loading,  setLoading]   = useState(false);
  const [copied,   setCopied]    = useState(false);

  const loadMissions = async () => {
    try {
      const r = await API.get('/daily');
      setMissions(r.data.missions);
      setStreak(r.data.streak || { current_streak:0, longest_streak:0 });
    } catch {}
  };

  const loadReferral = async () => {
    try { const r = await API.get('/referral/my'); setReferral(r.data); }
    catch {}
  };

  useEffect(() => { loadMissions(); loadReferral(); }, []);

  const claim = async (id) => {
    setMsg(''); setLoading(true);
    try { const r = await API.post(`/daily/claim/${id}`); setMsg(`✅ ${r.data.message}`); loadMissions(); }
    catch(err) { setMsg(`❌ ${err.response?.data?.error||'Failed.'}`); }
    finally { setLoading(false); }
  };

  const applyRef = async () => {
    setMsg(''); setLoading(true);
    try { const r = await API.post('/referral/apply', { code: refCode }); setMsg(`✅ ${r.data.message}`); loadReferral(); }
    catch(err) { setMsg(`❌ ${err.response?.data?.error||'Failed.'}`); }
    finally { setLoading(false); }
  };

  const copyCode = () => {
    if (!referral?.code) return;
    navigator.clipboard.writeText(referral.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const allDone = missions.length > 0 && missions.every(m => m.completed);

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:800, margin:'0 auto' }}>

        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1, marginBottom:8 }}>Daily Hub</div>
        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2, marginBottom:32 }}>Missions · Streak · Referrals</div>

        {/* STREAK BAR */}
        <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:'16px 20px', marginBottom:24, display:'flex', alignItems:'center', gap:24, flexWrap:'wrap' }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2, marginBottom:4 }}>CURRENT STREAK</div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:40, color:'#f97316', lineHeight:1 }}>
              {streak.current_streak}🔥
            </div>
          </div>
          <div style={{ height:40, width:1, background:'#2a2a2a' }}/>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2, marginBottom:4 }}>LONGEST</div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:40, color:'#c9a84c', lineHeight:1 }}>{streak.longest_streak}</div>
          </div>
          <div style={{ marginLeft:'auto', fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', lineHeight:1.6 }}>
            Complete all 3 missions<br/>to extend your streak.<br/>
            <span style={{ color:'#c9a84c' }}>7-day: badge unlock · 30-day: legendary reward</span>
          </div>
        </div>

        {/* TABS */}
        <div style={{ display:'flex', borderBottom:'1px solid #2a2a2a', marginBottom:24 }}>
          {[{key:'missions',label:'📅 Daily Missions'},{key:'referral',label:'📨 Referral Program'}].map(t=>(
            <button key={t.key} onClick={()=>setTab(t.key)} style={{ padding:'10px 18px', background:'none', color:tab===t.key?'#e8e4dc':'#9a9590', borderBottom:tab===t.key?'2px solid #8b0000':'2px solid transparent', fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1 }}>{t.label}</button>
          ))}
        </div>

        {msg && <div style={{ marginBottom:16, padding:'10px 16px', background:msg.startsWith('✅')?'#0f1a0f':'#1a0000', border:`1px solid ${msg.startsWith('✅')?'#22c55e':'#c0392b'}`, color:msg.startsWith('✅')?'#22c55e':'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>{msg}</div>}

        {/* MISSIONS */}
        {tab==='missions' && (
          <div>
            {allDone && (
              <div style={{ background:'#0f1a0f', border:'1px solid #22c55e', padding:16, marginBottom:20, textAlign:'center' }}>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4, color:'#22c55e' }}>✅ ALL MISSIONS COMPLETE</div>
                <p style={{ fontSize:13, color:'#9a9590', marginTop:4 }}>Streak extended! Come back tomorrow for new missions.</p>
              </div>
            )}

            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {missions.map(m => (
                <div key={m.id} style={{
                  background: m.completed?'#0f1a0f':'#111',
                  border: `1px solid ${m.reward_claimed?'#1a3a1a':m.completed?'#22c55e33':'#2a2a2a'}`,
                  padding:'20px 20px', display:'flex', alignItems:'center', gap:20, flexWrap:'wrap',
                }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:3, color: m.completed?'#22c55e':'#e8e4dc', marginBottom:4 }}>{m.title}</div>
                    <div style={{ fontSize:13, color:'#9a9590', marginBottom:8 }}>{m.description}</div>
                    {/* Progress bar */}
                    <div style={{ background:'#1a1a1a', height:6, borderRadius:3, maxWidth:300 }}>
                      <div style={{ background: m.completed?'#22c55e':'#8b0000', height:6, borderRadius:3, width:`${Math.min(100,(m.progress/m.condition_value)*100)}%`, transition:'width 0.5s' }}/>
                    </div>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:4, letterSpacing:1 }}>
                      {m.progress}/{m.condition_value}
                    </div>
                  </div>

                  <div style={{ textAlign:'right', flexShrink:0 }}>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:1, marginBottom:4 }}>REWARD</div>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, color:'#c9a84c', letterSpacing:1 }}>${m.reward_cash?.toLocaleString()}</div>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#8b5cf6', letterSpacing:1 }}>+{m.reward_xp} XP</div>

                    {m.reward_claimed ? (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#22c55e', marginTop:8, letterSpacing:1 }}>✓ Claimed</div>
                    ) : m.completed ? (
                      <button className="btn btn-success btn-sm" style={{ marginTop:8 }} onClick={()=>claim(m.id)} disabled={loading}>Claim Reward</button>
                    ) : (
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:8, letterSpacing:1 }}>In progress</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* REFERRAL */}
        {tab==='referral' && referral && (
          <div>
            {/* Your code */}
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:24, marginBottom:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:4, color:'#e8e4dc', marginBottom:16 }}>Your Referral Code</div>
              <div style={{ display:'flex', gap:12, alignItems:'center', flexWrap:'wrap' }}>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:36, letterSpacing:8, color:'#c9a84c', background:'#0a0a0a', border:'1px solid #333', padding:'12px 24px' }}>{referral.code}</div>
                <button className="btn btn-secondary btn-sm" onClick={copyCode}>{copied?'✅ Copied!':'Copy Code'}</button>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12, marginTop:20 }}>
                {[
                  ['Times Used',     referral.uses],
                  ['Total Earned',   `$${referral.total_earned?.toLocaleString()}`],
                  ['Your Reward',    `$${referral.referrer_reward?.toLocaleString()} per referral`],
                ].map(([label,value])=>(
                  <div key={label} style={{ textAlign:'center', background:'#0a0a0a', padding:'12px 8px' }}>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2, marginBottom:4 }}>{label}</div>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, color:'#c9a84c' }}>{value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Apply someone's code */}
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:24, marginBottom:20 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:4, color:'#e8e4dc', marginBottom:8 }}>Apply a Referral Code</div>
              <p style={{ fontSize:13, color:'#9a9590', marginBottom:16 }}>Enter a friend's code to receive ${referral.referred_reward?.toLocaleString()} bonus cash. One-time only.</p>
              <div style={{ display:'flex', gap:12 }}>
                <input className="input" placeholder="Enter code..." value={refCode} onChange={e=>setRefCode(e.target.value.toUpperCase())}
                  style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:4, maxWidth:200 }}/>
                <button className="btn btn-primary" disabled={loading||!refCode||refCode.length<8} onClick={applyRef}>Apply Code</button>
              </div>
            </div>

            {/* Who you referred */}
            {referral.referred_players?.length > 0 && (
              <div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#9a9590', marginBottom:12 }}>Players You've Recruited</div>
                {referral.referred_players.map(p => (
                  <div key={p.username} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'12px 16px', marginBottom:6, display:'flex', alignItems:'center', gap:12 }}>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:2, color:'#e8e4dc' }}>{p.username}</div>
                    <div style={{ marginLeft:'auto', fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#555' }}>
                      {new Date(p.referred_at).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
