import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, API } from '../context/AuthContext';

const FACTION_COLORS = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };

export default function Friends() {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const [friends, setFriends]   = useState([]);
  const [search,  setSearch]    = useState('');
  const [msg,     setMsg]       = useState('');
  const [loading, setLoading]   = useState(true);

  const load = async () => {
    try {
      const { data } = await API.get('/friends');
      setFriends(data.friends);
    } catch { setMsg('Failed to load friends.'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const sendRequest = async () => {
    if (!search.trim()) return;
    setMsg('');
    try {
      const { data } = await API.post('/friends/request', { username: search.trim() });
      setMsg(`✅ ${data.message}`);
      setSearch('');
      load();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed.'); }
  };

  const accept = async (id) => {
    try {
      await API.post('/friends/accept', { friendship_id: id });
      setMsg('✅ Friend accepted.');
      load();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed.'); }
  };

  const remove = async (id) => {
    try {
      await API.delete(`/friends/${id}`);
      setMsg('Friend removed.');
      load();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed.'); }
  };

  const accepted = friends.filter(f => f.status === 'accepted');
  const incoming = friends.filter(f => f.status === 'pending' && f.direction === 'received');
  const outgoing = friends.filter(f => f.status === 'pending' && f.direction === 'sent');

  const isOnline = (last_login) => {
    if (!last_login) return false;
    return (Date.now() - new Date(last_login).getTime()) < 15 * 60 * 1000;
  };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:700, margin:'0 auto' }}>
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', marginBottom:4 }}>Friends</div>
        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2, marginBottom:32 }}>
          {accepted.length} friends · {incoming.length} pending
        </div>

        {/* Add Friend */}
        <div style={{ display:'flex', gap:12, marginBottom:32 }}>
          <input className="input" placeholder="Search by username..." value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendRequest()}
            style={{ flex:1 }}
          />
          <button className="btn btn-primary" onClick={sendRequest}>Send Request</button>
        </div>

        {msg && <div className={msg.startsWith('✅')?'success-msg':'error-msg'} style={{ marginBottom:16 }}>{msg}</div>}

        {/* Incoming requests */}
        {incoming.length > 0 && (
          <div style={{ marginBottom:24 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#c9a84c', marginBottom:10 }}>
              Incoming Requests ({incoming.length})
            </div>
            {incoming.map(f => (
              <div key={f.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 18px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color: FACTION_COLORS[f.faction]||'#e8e4dc' }}>{f.username}</div>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>Rank {f.rank_level}</div>
                </div>
                <div style={{ display:'flex', gap:8 }}>
                  <button className="btn btn-success btn-sm" onClick={() => accept(f.id)}>Accept</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => remove(f.id)}>Ignore</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Accepted friends */}
        <div style={{ marginBottom:24 }}>
          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#e8e4dc', marginBottom:10 }}>
            Friends ({accepted.length})
          </div>
          {accepted.length === 0 && !loading && (
            <div style={{ color:'#9a9590', fontSize:14, padding:'24px 0', textAlign:'center' }}>
              No friends yet. Send a request above.
            </div>
          )}
          {accepted.map(f => {
            const online = isOnline(f.last_login);
            return (
              <div key={f.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 18px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ width:10, height:10, borderRadius:'50%', background: online?'#22c55e':'#555', flexShrink:0 }}/>
                <div style={{ flex:1 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color: FACTION_COLORS[f.faction]||'#e8e4dc' }}>{f.username}</span>
                    <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color: online?'#22c55e':'#555', letterSpacing:1 }}>{online?'ONLINE':'OFFLINE'}</span>
                  </div>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>
                    {f.faction?.toUpperCase()||'—'} · Rank {f.rank_level}
                  </div>
                </div>
                <div style={{ display:'flex', gap:8 }}>
                  {online && (
                    <button className="btn btn-primary btn-sm" onClick={() => navigate('/lobby')}>
                      Invite to Room
                    </button>
                  )}
                  <button className="btn btn-ghost btn-sm" onClick={() => remove(f.id)}>Remove</button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Outgoing requests */}
        {outgoing.length > 0 && (
          <div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#9a9590', marginBottom:10 }}>
              Sent Requests ({outgoing.length})
            </div>
            {outgoing.map(f => (
              <div key={f.id} style={{ background:'#0f0f0f', border:'1px solid #1a1a1a', padding:'12px 18px', marginBottom:8, display:'flex', alignItems:'center', gap:16 }}>
                <div style={{ flex:1, fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:2, color:'#555' }}>{f.username}</div>
                <span className="badge badge-muted">Pending</span>
                <button className="btn btn-ghost btn-sm" onClick={() => remove(f.id)}>Cancel</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
