import { useNavigate } from 'react-router-dom';

export default function Legal() {
  const navigate = useNavigate();
  const section = (title, content) => (
    <div style={{ marginBottom: 32 }}>
      <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 22, letterSpacing: 3, color: '#c9a84c', marginBottom: 10 }}>{title}</div>
      <div style={{ color: '#9a9590', fontSize: 15, lineHeight: 1.8 }}>{content}</div>
    </div>
  );
  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0a', padding: '60px 24px' }}>
      <div style={{ maxWidth: 760, margin: '0 auto' }}>
        <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: 32 }}>← Back</button>
        <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 48, letterSpacing: 6, color: '#e8e4dc', marginBottom: 8 }}>Legal & Terms</div>
        <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 10, letterSpacing: 3, color: '#9a9590', marginBottom: 40 }}>
          MAFIA WAR — AUSSI-NEXUS GROUP (ABN 76 947 108 181) — LAST UPDATED AUGUST 2026
        </div>

        {section('1. Age Restriction', 'Mafia War is strictly restricted to adults aged 18 years or older. By accessing, registering for, or playing this game you confirm that you are at least 18 years of age. The game contains graphic simulated violence, mature themes, and adult content. Anyone under 18 is prohibited from accessing this service. If you are under 18, you must close this application immediately.')}
        {section('2. Copyright Notice', '© 2026 Aussi-Nexus Group (ABN 76 947 108 181). All rights reserved. Mafia War, its source code, game design, mechanics, artwork concepts, character design, storyline, and brand identity are the exclusive intellectual property of Aussi-Nexus Group. Unauthorised reproduction, distribution, modification, or deployment is strictly prohibited under Australian Copyright Act 1968 and applicable international copyright law.')}
        {section('3. Content Disclaimer', 'Mafia War is a work of fiction. All characters, organisations, gangs, locations, businesses, and scenarios depicted within the game are entirely fictional. Any resemblance to real persons, living or dead, or actual organisations, events, or criminal entities is entirely coincidental. The game does not endorse, glorify, promote, or encourage actual criminal activity, violence, illegal weapons use, drug trafficking, money laundering, or any other illegal conduct.')}
        {section('4. Licence & Subscription Terms', 'Access to premium game features requires a paid subscription. Subscriptions are billed in Australian Dollars (AUD) on a recurring basis. You may cancel at any time; cancellation takes effect at the end of the current billing period with no refund for the remaining period. In-game purchases including cash packs are non-refundable once credited to your account. Aussi-Nexus Group reserves the right to modify subscription pricing with 30 days notice.')}
        {section('5. Prohibited Conduct', 'Players must not: (a) cheat, hack, exploit bugs, or use third-party software to gain unfair advantage; (b) harass, threaten, abuse, or discriminate against other players; (c) share account credentials or allow minors to access their account; (d) attempt to reverse-engineer the game software; (e) engage in real-money trading of in-game items; (f) attempt to interfere with game servers or other players\' connections.')}
        {section('6. Account Termination', 'Aussi-Nexus Group reserves the right to suspend or permanently ban any account that violates these terms, without notice and without refund. Banned accounts lose all accumulated progress, in-game currency, and subscription value.')}
        {section('7. Privacy', 'We collect email addresses, usernames, game play data, and payment information (processed by Stripe). We do not sell personal data to third parties. Game session data including chat logs may be retained for moderation purposes. By registering you consent to these data practices.')}
        {section('8. Governing Law', 'These Terms are governed by the laws of Queensland, Australia. Any dispute arising from these terms or your use of Mafia War shall be subject to the exclusive jurisdiction of the courts of Queensland, Australia.')}
        {section('9. Contact', 'For licensing, acquisition, support, or legal enquiries: info@nexusonlinegames.com | Aussi-Nexus Group | Shailer Park, Queensland, Australia | ABN 76 947 108 181')}

        <div style={{ borderTop: '1px solid #2a2a2a', paddingTop: 24, fontFamily: 'Share Tech Mono, monospace', fontSize: 11, color: '#444', lineHeight: 2 }}>
          © 2026 Aussi-Nexus Group (ABN 76 947 108 181). All rights reserved.<br/>
          Mafia War is a product of Aussi-Nexus Group. Strictly 18+.
        </div>
      </div>
    </div>
  );
}
