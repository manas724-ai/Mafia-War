import { useState, useEffect } from 'react';
import { useAuth, API } from '../context/AuthContext';

const WEAPON_ICONS = { pistol:'🔫', smg:'⚡', shotgun:'💥', rifle:'🎯', sniper:'🔭', explosive:'💣', special:'🚀' };

export default function Marketplace() {
  const { user } = useAuth();
  const [listings, setListings]   = useState([]);
  const [myData,   setMyData]     = useState({ listings:[], offers:[] });
  const [cash,     setCash]       = useState(0);
  const [inventory,setInventory]  = useState([]);
  const [tab,      setTab]        = useState('browse');
  const [filter,   setFilter]     = useState({ sort:'newest' });
  const [listForm, setListForm]   = useState({ weapon_id:'', price:'' });
  const [offerPrice,setOfferPrice]= useState({});
  const [msg,      setMsg]        = useState('');
  const [loading,  setLoading]    = useState(false);

  const load = async () => {
    try {
      const [market, inv] = await Promise.all([
        API.get('/marketplace'),
        API.get('/player/weapons'),
      ]);
      setListings(market.data.listings);
      setCash(market.data.cash);
      setInventory(inv.data.weapons.filter(w => w.weapon_id !== 'pistol_basic'));
    } catch {}
  };

  const loadMy = async () => {
    try { const r = await API.get('/marketplace/my'); setMyData(r.data); } catch {}
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { if(tab==='mine') loadMy(); }, [tab]);

  const action = async (fn, successMsg, reload=true) => {
    setMsg(''); setLoading(true);
    try { const r = await fn(); setMsg(`✅ ${r.data?.message||successMsg}`); if(reload){ load(); loadMy(); } }
    catch(err) { setMsg(`❌ ${err.response?.data?.error||'Action failed.'}`); }
    finally { setLoading(false); }
  };

  const FACTION_COLORS = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:1000, margin:'0 auto' }}>

        {/* Header */}
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:32, flexWrap:'wrap', gap:12 }}>
          <div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>Black Market</div>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2, marginTop:4 }}>Player-to-player weapon trading · 5% platform fee</div>
          </div>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2 }}>YOUR CASH</div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c' }}>${cash.toLocaleString()}</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', borderBottom:'1px solid #2a2a2a', marginBottom:24 }}>
          {[{key:'browse',label:'🛒 Browse'},{key:'list',label:'📋 List Weapon'},{key:'mine',label:'📦 My Listings'}].map(t=>(
            <button key={t.key} onClick={()=>setTab(t.key)} style={{ padding:'10px 18px', background:'none', color:tab===t.key?'#e8e4dc':'#9a9590', borderBottom:tab===t.key?'2px solid #8b0000':'2px solid transparent', fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1 }}>
              {t.label}
            </button>
          ))}
        </div>

        {msg && <div style={{ marginBottom:16, padding:'10px 16px', background:msg.startsWith('✅')?'#0f1a0f':'#1a0000', border:`1px solid ${msg.startsWith('✅')?'#22c55e':'#c0392b'}`, color:msg.startsWith('✅')?'#22c55e':'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>{msg}</div>}

        {/* BROWSE */}
        {tab==='browse' && (
          <div>
            {listings.length===0 ? (
              <div style={{ textAlign:'center', padding:'60px 0', color:'#9a9590' }}>
                <div style={{ fontSize:48, marginBottom:12 }}>🔫</div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:3 }}>No Listings Yet</div>
                <p style={{ fontSize:14, marginTop:8 }}>Be the first to list a weapon on the black market.</p>
              </div>
            ) : (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:8 }}>
                {listings.map(l => {
                  const icon = Object.entries(WEAPON_ICONS).find(([k]) => l.weapon_id.includes(k))?.[1] || '🔫';
                  const isOwn = l.seller_id === user.id;
                  return (
                    <div key={l.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'16px 14px' }}>
                      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                        <div>
                          <div style={{ fontSize:24, marginBottom:4 }}>{icon}</div>
                          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:2, color:'#e8e4dc' }}>{l.weapon_name}</div>
                          <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color: FACTION_COLORS[l.seller_faction]||'#9a9590', letterSpacing:1 }}>Seller: {l.seller_name}</div>
                        </div>
                        <div style={{ textAlign:'right' }}>
                          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c', letterSpacing:1 }}>${l.price.toLocaleString()}</div>
                          {l.offer_count > 0 && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', letterSpacing:1 }}>{l.offer_count} offers</div>}
                        </div>
                      </div>

                      {!isOwn && (
                        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                          <button className="btn btn-primary btn-sm btn-full" disabled={loading||cash<l.price}
                            onClick={()=>action(()=>API.post(`/marketplace/${l.id}/buy`),'Purchased!')}>
                            {cash>=l.price?`Buy $${l.price.toLocaleString()}`:'Insufficient Funds'}
                          </button>
                          <div style={{ display:'flex', gap:6 }}>
                            <input className="input" type="number" placeholder="Offer price..." value={offerPrice[l.id]||''} onChange={e=>setOfferPrice(p=>({...p,[l.id]:e.target.value}))} style={{ flex:1, fontSize:12, padding:'6px 10px' }}/>
                            <button className="btn btn-secondary btn-sm" disabled={loading||!offerPrice[l.id]}
                              onClick={()=>action(()=>API.post(`/marketplace/${l.id}/offer`,{offer_price:offerPrice[l.id]}),'Offer sent!')}>
                              Offer
                            </button>
                          </div>
                        </div>
                      )}
                      {isOwn && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:1 }}>Your listing</div>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* LIST WEAPON */}
        {tab==='list' && (
          <div style={{ maxWidth:480 }}>
            <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:24 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4, color:'#e8e4dc', marginBottom:20 }}>List a Weapon</div>
              <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
                <div>
                  <label className="label">Select Weapon</label>
                  <select className="input" value={listForm.weapon_id} onChange={e=>setListForm(p=>({...p,weapon_id:e.target.value}))} style={{ background:'#161616' }}>
                    <option value="">Choose weapon...</option>
                    {inventory.map(w=><option key={w.weapon_id} value={w.weapon_id}>{w.weapon_name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Asking Price ($)</label>
                  <input className="input" type="number" placeholder="Minimum $100..." value={listForm.price} onChange={e=>setListForm(p=>({...p,price:e.target.value}))}/>
                </div>
                <div style={{ background:'#0a0a0a', border:'1px solid #1a1a1a', padding:12, fontSize:12, color:'#9a9590', lineHeight:1.6 }}>
                  ⚠ Your weapon will be held in escrow until sold or cancelled.<br/>
                  Platform fee: 5% deducted from sale price.<br/>
                  Minimum price: $100.
                </div>
                <button className="btn btn-primary" disabled={loading||!listForm.weapon_id||!listForm.price||parseInt(listForm.price)<100}
                  onClick={()=>action(()=>API.post('/marketplace/list',listForm),'Weapon listed for sale!')}>
                  List for Sale
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MY LISTINGS */}
        {tab==='mine' && (
          <div>
            {myData.offers.length > 0 && (
              <div style={{ marginBottom:24 }}>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:3, color:'#c9a84c', marginBottom:12 }}>Incoming Offers</div>
                {myData.offers.map(o => (
                  <div key={o.id} style={{ background:'#111', border:'1px solid #c9a84c33', padding:'14px 16px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc' }}>{o.weapon_name}</div>
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>{o.buyer_name} offers ${o.offer_price.toLocaleString()} (listed: ${o.listing_price.toLocaleString()})</div>
                    </div>
                    <button className="btn btn-success btn-sm" onClick={()=>action(()=>API.post(`/marketplace/offer/${o.id}/accept`),'Offer accepted!')}>Accept</button>
                  </div>
                ))}
              </div>
            )}

            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:22, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>My Listings</div>
            {myData.listings.length===0 ? <div style={{ color:'#9a9590' }}>No active listings.</div> : myData.listings.map(l => (
              <div key={l.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'14px 16px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc' }}>{l.weapon_name}</div>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>
                    ${l.price.toLocaleString()} · {l.offer_count} offers · {l.status}
                  </div>
                </div>
                {l.status==='active' && (
                  <button className="btn btn-danger btn-sm" onClick={()=>action(()=>API.delete(`/marketplace/${l.id}`),'Listing cancelled.')}>Cancel</button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
