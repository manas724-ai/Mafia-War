import { useNavigate, useSearchParams } from 'react-router-dom';

export function PaymentSuccess() {
  const navigate = useNavigate();
  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:16, padding:24 }}>
      <div style={{ fontSize:64 }}>💰</div>
      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#c9a84c' }}>PAYMENT RECEIVED</div>
      <p style={{ color:'#9a9590', textAlign:'center', maxWidth:400, lineHeight:1.6 }}>
        Your payment has been processed. Your account has been upgraded. Welcome to the inner circle.
      </p>
      <button className="btn btn-primary" onClick={() => navigate('/lobby')}>Enter the War</button>
    </div>
  );
}

export function PaymentCancel() {
  const navigate = useNavigate();
  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:16, padding:24 }}>
      <div style={{ fontSize:64 }}>❌</div>
      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#c0392b' }}>PAYMENT CANCELLED</div>
      <p style={{ color:'#9a9590' }}>No charge was made. You can upgrade any time from your profile.</p>
      <div style={{ display:'flex', gap:12 }}>
        <button className="btn btn-primary" onClick={() => navigate('/lobby')}>Back to Lobby</button>
        <button className="btn btn-secondary" onClick={() => navigate('/lobby?tab=profile')}>Try Again</button>
      </div>
    </div>
  );
}
