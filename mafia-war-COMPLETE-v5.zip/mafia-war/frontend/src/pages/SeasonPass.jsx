import { useState, useEffect } from 'react';
import { useAuth, API } from '../context/AuthContext';

const REWARD_ICONS = { weapon:'🔫', cash:'💰', title:'👑', cosmetic:'✨' };

export default function SeasonPass() {
  const { user } = useAuth();
  const [season,   setSeason]   = useState(null);
  const [tiers,    setTiers]    = useState([]);
  const [player,   setPlayer]   = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [msg,      setMsg]      = useState('');
  const [buying,   setBuying]   = useState(false);

  const load = async () => {
    try {
      const { data } = await API.get('/season/current');
      setSeason(data.season);
      setTiers(data.tiers || []);
      setPlayer(data.player);
    } catch (err) {
      setMsg('Failed to load season pass.');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const claim = async (tier) => {
    setMsg('');
    try {
      const { data } = await API.post(`/season/claim/${tier}`);
      setMsg(`✅ ${data.reward}`);
      load();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed to claim.'); }
  };

  const buyPremium = async () => {
    setBuying(true); setMsg('');
    try {
      const { data } = await API.post('/season/buy-premium');
      setMsg(`✅ ${data.message}`);
      load();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed.'); }
    finally { setBuying(false); }
  };

  if (loading) return <div style={{ padding:40, color:'#9a9590', fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4 }}>LOADING SEASON...</div>;
  if (!season) return <div style={{ padding:40, color:'#9a9590' }}>No active season.</div>;

  const hasPremium   = player?.has_premium;
  const currentTier  = player?.current_tier  || 0;
  const seasonXp     = player?.season_xp     || 0;
  const claimed      = player?.rewards_claimed || [];
  const maxXp        = tiers[tiers.length-1]?.xp_required || 45000;
  const progress     = Math.min(100, (seasonXp / maxXp) * 100);

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:960, margin:'0 auto' }}>

        {/* HEADER */}
        <div style={{ marginBottom:32 }}>
          <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, letterSpacing:4, color:'#c0392b', marginBottom:6, textTransform:'uppercase' }}>
            Active Season · {season.days_left} days remaining
          </div>
          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:52, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>
            {season.name}
          </div>
          <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:12, color:'#c9a84c', marginTop:4, letterSpacing:2 }}>
            {season.theme}
          </div>
        </div>

        {/* PROGRESS */}
        <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:'20px 24px', marginBottom:24 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
            <div>
              <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:2, color:'#9a9590' }}>SEASON PROGRESS</div>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#e8e4dc', letterSpacing:2 }}>
                Tier <span style={{ color:'#c9a84c' }}>{currentTier}</span> / {tiers.length}
              </div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:2, color:'#9a9590' }}>SEASON XP</div>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c' }}>{seasonXp.toLocaleString()}</div>
            </div>
          </div>
          <div style={{ background:'#222', height:8, borderRadius:4 }}>
            <div style={{ background:'linear-gradient(to right, #8b0000, #c9a84c)', height:8, borderRadius:4, width:`${progress}%`, transition:'width 0.5s' }}/>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:6, fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555' }}>
            <span>0</span><span>{maxXp.toLocaleString()} XP</span>
          </div>
        </div>

        {/* PREMIUM UPGRADE */}
        {!hasPremium && (
          <div style={{ background:'linear-gradient(135deg,#1a0800,#0a0500)', border:'1px solid #c9a84c44', padding:'20px 24px', marginBottom:24, display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:12 }}>
            <div>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:3, color:'#c9a84c' }}>🏆 PREMIUM SEASON PASS</div>
              <div style={{ fontSize:14, color:'#9a9590', marginTop:4 }}>Unlock all premium tier rewards — weapons, bonus cash, exclusive titles.</div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, color:'#c9a84c', letterSpacing:2 }}>$5,000 <span style={{ fontSize:16, color:'#9a9590' }}>in-game cash</span></div>
              <button className="btn btn-primary" onClick={buyPremium} disabled={buying} style={{ marginTop:8, minWidth:160 }}>
                {buying ? 'Activating...' : '💰 Get Premium Pass'}
              </button>
            </div>
          </div>
        )}
        {hasPremium && (
          <div style={{ background:'#0f1a0f', border:'1px solid #22c55e44', padding:'12px 20px', marginBottom:24, display:'flex', alignItems:'center', gap:12 }}>
            <span style={{ fontSize:24 }}>✅</span>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#22c55e' }}>PREMIUM PASS ACTIVE — All rewards unlocked</div>
          </div>
        )}

        {msg && <div className={msg.startsWith('✅')?'success-msg':'error-msg'} style={{ marginBottom:16, fontSize:14 }}>{msg}</div>}

        {/* TIER TRACK */}
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4, color:'#e8e4dc', marginBottom:16 }}>Reward Track</div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:8 }}>
          {tiers.map(tier => {
            const unlocked  = currentTier >= tier.tier;
            const isClaimed = claimed.includes(tier.tier);
            const canClaim  = unlocked && !isClaimed;

            return (
              <div key={tier.tier} style={{
                background: unlocked ? '#111' : '#0a0a0a',
                border: `1px solid ${isClaimed ? '#1a3a1a' : unlocked ? '#2a2a2a' : '#1a1a1a'}`,
                padding:'16px 14px', opacity: unlocked ? 1 : 0.5,
                position:'relative',
              }}>
                {/* Tier badge */}
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color: isClaimed?'#22c55e': unlocked?'#c9a84c':'#555', letterSpacing:2, lineHeight:1, marginBottom:8 }}>
                  {isClaimed ? '✅' : `T${tier.tier}`}
                </div>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#c0392b', textTransform:'uppercase', marginBottom:8 }}>
                  {tier.xp_required.toLocaleString()} XP
                </div>

                {/* Free reward */}
                <div style={{ marginBottom:8 }}>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color:'#555', letterSpacing:1, marginBottom:3 }}>FREE</div>
                  <div style={{ fontSize:12, color:'#9a9590' }}>{tier.free_reward}</div>
                </div>

                {/* Premium reward */}
                <div style={{ padding:'6px 8px', background: hasPremium?'#1a0800':'#111', border:`1px solid ${hasPremium?'#c9a84c33':'#222'}`, borderRadius:2, marginBottom:10 }}>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color: hasPremium?'#c9a84c':'#555', letterSpacing:1, marginBottom:2 }}>PREMIUM {REWARD_ICONS[tier.reward_type]}</div>
                  <div style={{ fontSize:11, color: hasPremium?'#e8e4dc':'#555' }}>{tier.paid_reward}</div>
                </div>

                {canClaim ? (
                  <button className="btn btn-primary btn-sm" onClick={() => claim(tier.tier)} style={{ width:'100%', fontSize:12 }}>
                    Claim
                  </button>
                ) : isClaimed ? (
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#22c55e', textAlign:'center' }}>Claimed</div>
                ) : (
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', textAlign:'center' }}>Locked</div>
                )}
              </div>
            );
          })}
        </div>

        {/* HOW TO EARN XP */}
        <div style={{ marginTop:32, background:'#111', border:'1px solid #2a2a2a', padding:'20px 24px' }}>
          <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#c9a84c', marginBottom:12 }}>How to Earn Season XP</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:12 }}>
            {[
              {action:'Win a Match',          xp:'+200 XP'},
              {action:'Kill an Enemy',        xp:'+50 XP'},
              {action:'Complete a Heist',     xp:'+500 XP'},
              {action:'Capture a Zone',       xp:'+20 XP'},
              {action:'Kill Streak x3',       xp:'+50 XP'},
              {action:'Kill Streak x5',       xp:'+100 XP'},
              {action:'Eliminate a Guard',    xp:'+30 XP'},
              {action:'Match Participation',  xp:'+50 XP'},
            ].map(({action,xp}) => (
              <div key={action} style={{ display:'flex', justifyContent:'space-between', fontSize:13, padding:'8px 0', borderBottom:'1px solid #1a1a1a' }}>
                <span style={{ color:'#9a9590' }}>{action}</span>
                <span style={{ color:'#c9a84c', fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:1 }}>{xp}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
