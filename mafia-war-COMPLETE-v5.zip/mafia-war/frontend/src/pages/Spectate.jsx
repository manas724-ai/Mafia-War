import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import { createPhaserGame } from '../game/PhaserGame';
import { API } from '../context/AuthContext';

const FACTION_COLORS = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };

export default function Spectate() {
  const { code }         = useParams();
  const { user }         = useAuth();
  const navigate         = useNavigate();
  const containerRef     = useRef(null);
  const phaserRef        = useRef(null);
  const socketRef        = useRef(null);

  const [state,     setState]     = useState(null);
  const [killfeed,  setKillfeed]  = useState([]);
  const [msgs,      setMsgs]      = useState([]);
  const [error,     setError]     = useState('');
  const [scoreboard,setScoreboard]= useState([]);

  useEffect(() => {
    if (!user) return;
    const token = localStorage.getItem('mw_access');

    // Log session
    API.post(`/spectate/join/${code}`).catch(() => {});

    const s = io('/', { auth: { token }, transports: ['websocket'] });
    socketRef.current = s;

    s.on('connect', () => s.emit('spectate_join', { room_code: code }));
    s.on('connect_error', () => setError('Connection failed.'));

    s.on('spectate_state', (data) => {
      setState(data);
      setScoreboard(data.players || []);
    });

    s.on('player_killed', ({ killerName, victimName, weapon }) => {
      const feed = `${killerName} ☠ ${victimName} [${weapon}]`;
      setKillfeed(prev => [...prev.slice(-5), feed]);
      setTimeout(() => setKillfeed(prev => prev.filter(m => m !== feed)), 5000);
    });

    s.on('chat', msg => setMsgs(prev => [...prev.slice(-20), { ...msg, id: Date.now()+Math.random() }]));
    s.on('player_joined', ({ player }) => setScoreboard(prev => [...prev.filter(p => p.socketId !== player.socketId), player]));
    s.on('player_left',   ({ socketId }) => setScoreboard(prev => prev.filter(p => p.socketId !== socketId)));
    s.on('player_moved',  ({ socketId, x, y }) => setScoreboard(prev => prev.map(p => p.socketId === socketId ? {...p,x,y} : p)));
    s.on('match_ended', () => { setTimeout(() => navigate('/lobby'), 4000); });
    s.on('error', ({ message }) => setError(message));

    return () => { s.disconnect(); phaserRef.current?.destroy(true); };
  }, [code, user, navigate]);

  // Init Phaser for spectator view
  useEffect(() => {
    if (!state || !containerRef.current || phaserRef.current) return;
    const fakeSocket = {
      id: '__spectator__',
      on: () => {}, off: () => {}, emit: () => {},
      _chatOpen: false,
    };
    const roomInfo = {
      map_id: state.map_id, mode: state.mode,
      players: state.players, guards: state.guards || [],
      territory: state.territory || {},
      player: { socketId: '__spectator__', x:400, y:300, hp:100, ammo:0, faction:'ghost', username:'SPECTATOR' },
      duration: null,
    };
    phaserRef.current = createPhaserGame(containerRef.current, socketRef.current || fakeSocket, user, roomInfo, ()=>{}, ()=>{});
  }, [state, user]);

  if (error) return (
    <div style={{minHeight:'100vh',background:'#0a0a0a',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16}}>
      <div style={{color:'#c0392b',fontFamily:'Bebas Neue, sans-serif',fontSize:32,letterSpacing:4}}>{error}</div>
      <button className="btn btn-primary" onClick={()=>navigate('/lobby')}>Back to Lobby</button>
    </div>
  );

  return (
    <div style={{display:'flex',height:'100vh',background:'#0a0a0a',overflow:'hidden',flexDirection:'column'}}>
      {/* NAV */}
      <div style={{background:'#111',borderBottom:'1px solid #2a2a2a',padding:'8px 20px',display:'flex',alignItems:'center',gap:16,flexShrink:0}}>
        <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:22,letterSpacing:4,color:'#e8e4dc'}}>SPECTATING</div>
        <span style={{fontFamily:'Share Tech Mono, monospace',fontSize:10,letterSpacing:2,color:'#c9a84c',background:'#1a1a1a',padding:'3px 8px'}}>{code}</span>
        <span className="badge badge-muted">SPECTATOR</span>
        <button className="btn btn-ghost btn-sm" style={{marginLeft:'auto'}} onClick={()=>navigate('/lobby')}>Leave</button>
      </div>

      <div style={{flex:1,display:'flex',overflow:'hidden'}}>
        {/* GAME VIEW */}
        <div ref={containerRef} style={{width:800,height:'100%',position:'relative',flexShrink:0,overflow:'hidden'}}>
          {!state && (
            <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',background:'#0a0a0a'}}>
              <div className="animate-pulse" style={{fontFamily:'Bebas Neue, sans-serif',fontSize:32,letterSpacing:6,color:'#c0392b'}}>CONNECTING...</div>
            </div>
          )}
          {/* Killfeed overlay */}
          <div style={{position:'absolute',top:12,right:12,display:'flex',flexDirection:'column',gap:4,alignItems:'flex-end',pointerEvents:'none',zIndex:20}}>
            {killfeed.map((m,i)=>(
              <div key={i} style={{background:'rgba(0,0,0,0.75)',padding:'4px 10px',fontFamily:'Share Tech Mono, monospace',fontSize:11,color:'#c0392b',borderLeft:'2px solid #8b0000'}}>
                {m}
              </div>
            ))}
          </div>
          {/* Spectator badge */}
          <div style={{position:'absolute',top:12,left:12,pointerEvents:'none',zIndex:20}}>
            <span className="badge badge-muted">👁 SPECTATING</span>
          </div>
        </div>

        {/* SIDEBAR */}
        <div style={{flex:1,background:'#111',borderLeft:'1px solid #2a2a2a',display:'flex',flexDirection:'column'}}>
          {/* Scoreboard */}
          <div style={{padding:'12px 14px',borderBottom:'1px solid #2a2a2a'}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:16,letterSpacing:3,color:'#e8e4dc',marginBottom:10}}>PLAYERS</div>
            {[...scoreboard].sort((a,b)=>(b.kills||0)-(a.kills||0)).map(p=>(
              <div key={p.socketId} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 0',borderBottom:'1px solid #1a1a1a'}}>
                <div style={{width:8,height:8,borderRadius:'50%',background:p.isAlive?'#22c55e':'#c0392b',flexShrink:0}}/>
                <span style={{flex:1,fontSize:12,color:FACTION_COLORS[p.faction]||'#e8e4dc'}}>{p.username}</span>
                <span style={{fontFamily:'Share Tech Mono, monospace',fontSize:10,color:'#9a9590'}}>{p.kills||0}K/{p.deaths||0}D</span>
                <div style={{width:30,height:4,background:'#222',borderRadius:2}}>
                  <div style={{width:`${p.hp||0}%`,height:4,background:p.hp>50?'#22c55e':p.hp>25?'#f59e0b':'#c0392b',borderRadius:2}}/>
                </div>
              </div>
            ))}
          </div>
          {/* Chat */}
          <div style={{flex:1,overflow:'auto',padding:'8px 14px',display:'flex',flexDirection:'column',gap:4}}>
            {msgs.map(m=>(
              <div key={m.id} style={{fontSize:12,color:'#e8e4dc',lineHeight:1.4}}>
                <span style={{color:FACTION_COLORS[m.faction]||'#9a9590'}}>{m.username}: </span>
                {m.message}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
