import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth, API } from '../context/AuthContext';

const FACTION_COLORS = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };
const STATUS_COLOR   = { open:'#22c55e', seeded:'#c9a84c', active:'#f97316', complete:'#9a9590' };

// ── BRACKET COMPONENT ─────────────────────────────────────────
function Bracket({ matches, participants }) {
  if (!matches?.length) return <div style={{ color:'#9a9590', padding:24 }}>No bracket generated yet.</div>;

  const rounds = [...new Set(matches.map(m => m.round))].sort((a,b)=>a-b);

  return (
    <div style={{ overflowX:'auto', paddingBottom:16 }}>
      <div style={{ display:'flex', gap:32, minWidth: rounds.length * 200 }}>
        {rounds.map(round => {
          const roundMatches = matches.filter(m => m.round === round).sort((a,b)=>a.match_num-b.match_num);
          const totalRounds  = Math.max(...rounds);
          const label = round === totalRounds ? '🏆 FINAL' : round === totalRounds - 1 ? 'SEMI-FINAL' : `ROUND ${round}`;

          return (
            <div key={round} style={{ flex:1, display:'flex', flexDirection:'column', gap: Math.pow(2, round - 1) * 8 + 8 }}>
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:14, letterSpacing:3, color:'#c9a84c', textAlign:'center', marginBottom:8 }}>{label}</div>
              {roundMatches.map(m => (
                <div key={m.id} style={{ background:'#111', border:`1px solid ${m.status==='complete'?'#2a2a2a':'#333'}`, padding:'8px 12px' }}>
                  <MatchSlot name={m.player1_name} winner={m.winner_id === m.player1_id} eliminated={m.status==='complete' && m.winner_id !== m.player1_id && m.player1_id} bye={!m.player1_id}/>
                  <div style={{ height:1, background:'#1a1a1a', margin:'4px 0' }}/>
                  <MatchSlot name={m.player2_name} winner={m.winner_id === m.player2_id} eliminated={m.status==='complete' && m.winner_id !== m.player2_id && m.player2_id} bye={!m.player2_id}/>
                  {m.room_code && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555', marginTop:4, letterSpacing:1 }}>Room: {m.room_code}</div>}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MatchSlot({ name, winner, eliminated, bye }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8, padding:'4px 0' }}>
      <div style={{ width:8, height:8, borderRadius:'50%', background: winner?'#c9a84c':eliminated?'#c0392b':bye?'#333':'#555', flexShrink:0 }}/>
      <span style={{
        fontFamily: winner?'Bebas Neue, sans-serif':'Inter, sans-serif',
        fontSize: winner?16:13,
        letterSpacing: winner?2:0,
        color: winner?'#c9a84c': eliminated?'#555': bye?'#333':'#e8e4dc',
        textDecoration: eliminated?'line-through':'none',
      }}>
        {bye ? '— BYE —' : name || '???'}
      </span>
      {winner && <span style={{ fontSize:12, marginLeft:'auto' }}>🏆</span>}
    </div>
  );
}

// ── TOURNAMENT LIST ───────────────────────────────────────────
export default function Tournaments() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [tournaments, setTournaments] = useState([]);
  const [selected,    setSelected]    = useState(null);
  const [detail,      setDetail]      = useState(null);
  const [creating,    setCreating]    = useState(false);
  const [form,        setForm]        = useState({ name:'', mode:'deathmatch', map_id:'downtown', max_players:8, entry_fee:0 });
  const [msg,         setMsg]         = useState('');
  const [loading,     setLoading]     = useState(false);

  const load = async () => {
    try { const r = await API.get('/tournament'); setTournaments(r.data.tournaments); }
    catch {}
  };

  useEffect(() => { load(); }, []);

  const loadDetail = async (id) => {
    setSelected(id);
    try { const r = await API.get(`/tournament/${id}`); setDetail(r.data); }
    catch {}
  };

  const create = async () => {
    setMsg(''); setLoading(true);
    try {
      const r = await API.post('/tournament', form);
      setMsg('✅ Tournament created!');
      setCreating(false); load();
      loadDetail(r.data.tournament.id);
    } catch(err) { setMsg(`❌ ${err.response?.data?.error||'Failed.'}`); }
    finally { setLoading(false); }
  };

  const join = async (id) => {
    setMsg(''); setLoading(true);
    try { await API.post(`/tournament/${id}/join`); setMsg('✅ Joined!'); loadDetail(id); }
    catch(err) { setMsg(`❌ ${err.response?.data?.error||'Failed to join.'}`); }
    finally { setLoading(false); }
  };

  const seed = async (id) => {
    setMsg(''); setLoading(true);
    try { await API.post(`/tournament/${id}/seed`); setMsg('✅ Bracket generated!'); loadDetail(id); }
    catch(err) { setMsg(`❌ ${err.response?.data?.error||'Failed.'}`); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', padding:'40px 24px' }}>
      <div style={{ maxWidth:1100, margin:'0 auto' }}>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:32, flexWrap:'wrap', gap:12 }}>
          <div>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc', lineHeight:1 }}>Tournaments</div>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2, marginTop:4 }}>
              Bracket wars · Prize pools · Champions
            </div>
          </div>
          {user.rank_level >= 8 && (
            <button className="btn btn-primary" onClick={() => setCreating(true)}>+ Create Tournament</button>
          )}
        </div>

        {msg && <div style={{ marginBottom:16, padding:'10px 16px', background:msg.startsWith('✅')?'#0f1a0f':'#1a0000', border:`1px solid ${msg.startsWith('✅')?'#22c55e':'#c0392b'}`, color:msg.startsWith('✅')?'#22c55e':'#c0392b', fontFamily:'Share Tech Mono, monospace', fontSize:12 }}>{msg}</div>}

        {/* CREATE FORM */}
        {creating && (
          <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:24, marginBottom:24 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4, color:'#e8e4dc', marginBottom:16 }}>New Tournament</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:16 }}>
              {[
                { label:'Name', key:'name', type:'text', placeholder:'Blood Cup 2026...' },
                { label:'Entry Fee ($0 = free)', key:'entry_fee', type:'number', placeholder:'0' },
              ].map(f => (
                <div key={f.key}>
                  <label className="label">{f.label}</label>
                  <input className="input" type={f.type} placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm(p => ({...p,[f.key]:e.target.value}))}/>
                </div>
              ))}
              <div>
                <label className="label">Mode</label>
                <select className="input" value={form.mode} onChange={e=>setForm(p=>({...p,mode:e.target.value}))} style={{ background:'#161616' }}>
                  {['deathmatch','team','heist','territory'].map(m=><option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Max Players</label>
                <select className="input" value={form.max_players} onChange={e=>setForm(p=>({...p,max_players:parseInt(e.target.value)}))} style={{ background:'#161616' }}>
                  {[4,8,16,32].map(n=><option key={n} value={n}>{n} Players</option>)}
                </select>
              </div>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-primary" onClick={create} disabled={loading||!form.name}>Create</button>
              <button className="btn btn-ghost" onClick={()=>setCreating(false)}>Cancel</button>
            </div>
          </div>
        )}

        <div style={{ display:'grid', gridTemplateColumns: selected?'300px 1fr':'1fr', gap:24 }}>
          {/* LIST */}
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {tournaments.length===0 && <div style={{ color:'#9a9590', padding:'32px 0', textAlign:'center' }}>No tournaments yet. Be the first to create one.</div>}
            {tournaments.map(t => (
              <div key={t.id} onClick={()=>loadDetail(t.id)} style={{
                background: selected===t.id?'#1a0800':'#111',
                border: `1px solid ${selected===t.id?'#c9a84c':'#2a2a2a'}`,
                padding:'14px 16px', cursor:'pointer', transition:'all 0.2s',
              }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:2, color:'#e8e4dc' }}>{t.name}</div>
                  <span style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color: STATUS_COLOR[t.status]||'#9a9590' }}>{t.status?.toUpperCase()}</span>
                </div>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1, marginTop:4 }}>
                  {t.mode} · {t.participant_count}/{t.max_players} · Prize: ${t.prize_pool.toLocaleString()}
                </div>
                {t.entry_fee > 0 && <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#c9a84c', marginTop:2 }}>Entry: ${t.entry_fee}</div>}
              </div>
            ))}
          </div>

          {/* DETAIL */}
          {detail && (
            <div>
              <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20, marginBottom:16 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
                  <div>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:4, color:'#e8e4dc' }}>{detail.tournament.name}</div>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1, marginTop:4 }}>
                      {detail.tournament.mode} · {detail.tournament.map_id} · {detail.participants.length}/{detail.tournament.max_players} players
                    </div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:2 }}>PRIZE POOL</div>
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c' }}>${detail.tournament.prize_pool.toLocaleString()}</div>
                  </div>
                </div>

                <div style={{ display:'flex', gap:8, marginTop:16, flexWrap:'wrap' }}>
                  {detail.tournament.status === 'open' && !detail.my_entry && (
                    <button className="btn btn-primary btn-sm" disabled={loading} onClick={()=>join(detail.tournament.id)}>
                      {detail.tournament.entry_fee>0?`Pay $${detail.tournament.entry_fee} & Join`:'Join Free'}
                    </button>
                  )}
                  {detail.my_entry && <span className="badge badge-green">✅ REGISTERED</span>}
                  {['admin','owner'].includes(user.role) && detail.tournament.status==='open' && (
                    <button className="btn btn-secondary btn-sm" disabled={loading} onClick={()=>seed(detail.tournament.id)}>Generate Bracket</button>
                  )}
                  {detail.tournament.winner_name && (
                    <span style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, color:'#c9a84c', letterSpacing:2 }}>🏆 Champion: {detail.tournament.winner_name}</span>
                  )}
                </div>
              </div>

              {/* BRACKET */}
              <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20, marginBottom:16 }}>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#e8e4dc', marginBottom:16 }}>Bracket</div>
                <Bracket matches={detail.matches} participants={detail.participants} />
              </div>

              {/* PARTICIPANTS */}
              <div style={{ background:'#111', border:'1px solid #2a2a2a', padding:20 }}>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:3, color:'#e8e4dc', marginBottom:12 }}>
                  Participants ({detail.participants.length})
                </div>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(160px,1fr))', gap:8 }}>
                  {detail.participants.map(p => (
                    <div key={p.user_id} style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 12px', background:'#0a0a0a', border:`1px solid ${p.eliminated?'#1a1a1a':'#2a2a2a'}`, opacity:p.eliminated?0.4:1 }}>
                      {p.seed && <span style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, color:'#555', minWidth:20 }}>#{p.seed}</span>}
                      <div>
                        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:14, letterSpacing:2, color: FACTION_COLORS[p.faction]||'#e8e4dc' }}>{p.username}</div>
                        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#555' }}>Rank {p.rank_level}</div>
                      </div>
                      {p.eliminated && <span style={{ marginLeft:'auto', fontSize:12 }}>☠</span>}
                      {p.prize_earned > 0 && <span style={{ marginLeft:'auto', fontFamily:'Bebas Neue, sans-serif', fontSize:14, color:'#c9a84c' }}>${p.prize_earned.toLocaleString()}</span>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
