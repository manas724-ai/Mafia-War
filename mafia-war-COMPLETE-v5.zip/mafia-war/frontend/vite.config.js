import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api':      'http://localhost:3110',
      '/socket.io':{ target: 'http://localhost:3110', ws: true }
    }
  },
  build: { outDir: 'dist', sourcemap: false }
});
