#!/bin/bash
# ================================================================
# MAFIA WAR — VPS Deployment Script
# © 2026 Aussi-Nexus Group (ABN 76 947 108 181)
# Run this on your Hetzner VPS as root
# ================================================================
set -e

APP_DIR="/var/www/mafia-war"
PORT=3110
PM2_NAME="mafia-war"
DOMAIN="mafia.nexusonlinegames.com"

echo ""
echo "🔫 MAFIA WAR DEPLOYMENT"
echo "========================"

# ── 1. CREATE APP DIRECTORY ──────────────────────────────────
echo "[1/7] Setting up directories..."
mkdir -p "$APP_DIR/backend"
mkdir -p "$APP_DIR/frontend"

# ── 2. UPLOAD REMINDER ───────────────────────────────────────
echo "[2/7] Upload your files via FileZilla:"
echo "       Local:  ./backend/*   → Remote: $APP_DIR/backend/"
echo "       Local:  ./frontend/dist/*  → Remote: $APP_DIR/frontend/dist/"
echo "       (Build frontend locally: cd frontend && npm install && npm run build)"
echo ""
echo "Press ENTER when files are uploaded..."
read -r

# ── 3. INSTALL BACKEND DEPS ──────────────────────────────────
echo "[3/7] Installing backend dependencies..."
cd "$APP_DIR/backend"
npm install --production

# ── 4. SET UP DATABASE ───────────────────────────────────────
echo "[4/7] Setting up MySQL database..."
echo "Enter MySQL root password:"
read -rs MYSQL_ROOT_PASS

mysql -u root -p"$MYSQL_ROOT_PASS" << SQLEOF
CREATE DATABASE IF NOT EXISTS mafia_war CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'mafia_war_user'@'localhost' IDENTIFIED BY 'MafiaWar2026!Secure';
GRANT ALL PRIVILEGES ON mafia_war.* TO 'mafia_war_user'@'localhost';
FLUSH PRIVILEGES;
SQLEOF

mysql -u root -p"$MYSQL_ROOT_PASS" mafia_war < "$APP_DIR/backend/src/db/schema.sql"
echo "Database ready."

# ── 5. CREATE .env ───────────────────────────────────────────
echo "[5/7] Creating .env file..."
echo "Enter your Stripe Secret Key (sk_live_...):"
read -rs STRIPE_SK
echo "Enter your Stripe Webhook Secret (whsec_...):"
read -rs STRIPE_WH
echo "Enter your Stripe Premium Price ID (price_...):"
read -rs STRIPE_PRICE

cat > "$APP_DIR/backend/.env" << EOF
PORT=$PORT
NODE_ENV=production
DB_HOST=localhost
DB_PORT=3306
DB_NAME=mafia_war
DB_USER=mafia_war_user
DB_PASS=MafiaWar2026!Secure
JWT_SECRET=$(openssl rand -hex 32)
STRIPE_SECRET_KEY=$STRIPE_SK
STRIPE_WEBHOOK_SECRET=$STRIPE_WH
STRIPE_PREMIUM_PRICE_ID=$STRIPE_PRICE
FRONTEND_URL=https://$DOMAIN
ADMIN_EMAIL=admin@nexusonlinegames.com
EOF
echo ".env created."

# ── 6. PM2 ───────────────────────────────────────────────────
echo "[6/7] Starting with PM2..."
pm2 delete "$PM2_NAME" 2>/dev/null || true
pm2 start "$APP_DIR/backend/src/server.js" --name "$PM2_NAME" --env production
pm2 save

# ── 7. NGINX ─────────────────────────────────────────────────
echo "[7/7] Configuring Nginx..."
cat > "/etc/nginx/sites-available/$DOMAIN" << NGINXEOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    location /socket.io/ {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }

    location /api/payment/webhook {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_read_timeout 30s;
    }

    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
    }
}
NGINXEOF

ln -sf "/etc/nginx/sites-available/$DOMAIN" "/etc/nginx/sites-enabled/$DOMAIN"
nginx -t && systemctl reload nginx

# ── SSL ──────────────────────────────────────────────────────
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m admin@nexusonlinegames.com

echo ""
echo "✅ MAFIA WAR DEPLOYED"
echo "   URL:  https://$DOMAIN"
echo "   PM2:  $PM2_NAME (port $PORT)"
echo "   Admin panel: https://$DOMAIN/admin"
echo ""
