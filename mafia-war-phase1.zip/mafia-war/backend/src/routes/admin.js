const router = require('express').Router();
const { query, queryOne } = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');

// GET /api/admin/users
router.get('/users', requireAdmin, async (req, res) => {
  try {
    const { search = '', page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const like = `%${search}%`;
    const users = await query(
      `SELECT id, uuid, username, email, role, faction, rank_level, xp, kills, deaths,
              cash, is_banned, subscription_status, last_login, created_at
       FROM users WHERE username LIKE ? OR email LIKE ?
       ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [like, like, parseInt(limit), offset]
    );
    const [{ total }] = await query(
      'SELECT COUNT(*) total FROM users WHERE username LIKE ? OR email LIKE ?', [like, like]
    );
    res.json({ users, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load users.' });
  }
});

// POST /api/admin/ban
router.post('/ban', requireAdmin, async (req, res) => {
  try {
    const { user_id, reason } = req.body;
    if (!user_id) return res.status(400).json({ error: 'user_id required.' });
    await query('UPDATE users SET is_banned = 1, ban_reason = ? WHERE id = ?', [reason || 'Violation of terms', user_id]);
    res.json({ message: 'Player banned.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to ban player.' });
  }
});

// POST /api/admin/unban
router.post('/unban', requireAdmin, async (req, res) => {
  try {
    const { user_id } = req.body;
    await query('UPDATE users SET is_banned = 0, ban_reason = NULL WHERE id = ?', [user_id]);
    res.json({ message: 'Player unbanned.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to unban player.' });
  }
});

// GET /api/admin/stats — dashboard overview
router.get('/stats', requireAdmin, async (req, res) => {
  try {
    const [totals] = await query(
      `SELECT
        COUNT(*) total_users,
        SUM(is_banned) banned_users,
        SUM(subscription_status='active') premium_users,
        SUM(role='admin') admins
       FROM users`
    );
    const [rooms] = await query(
      `SELECT COUNT(*) total_rooms, SUM(status='active') active_rooms FROM game_rooms`
    );
    const [revenue] = await query(
      `SELECT SUM(amount) total_revenue_cents FROM payments WHERE status='succeeded'`
    );
    const [reports] = await query(
      `SELECT COUNT(*) open_reports FROM player_reports WHERE status='open'`
    );
    res.json({ ...totals, ...rooms, ...revenue, ...reports });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load admin stats.' });
  }
});

// GET /api/admin/reports
router.get('/reports', requireAdmin, async (req, res) => {
  try {
    const reports = await query(
      `SELECT pr.*, u1.username reporter_name, u2.username reported_name
       FROM player_reports pr
       JOIN users u1 ON u1.id = pr.reporter_id
       JOIN users u2 ON u2.id = pr.reported_id
       WHERE pr.status = 'open'
       ORDER BY pr.created_at DESC LIMIT 100`
    );
    res.json({ reports });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load reports.' });
  }
});

// POST /api/admin/reports/:id/resolve
router.post('/reports/:id/resolve', requireAdmin, async (req, res) => {
  try {
    await query("UPDATE player_reports SET status = 'resolved' WHERE id = ?", [req.params.id]);
    res.json({ message: 'Report resolved.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to resolve report.' });
  }
});

// POST /api/admin/promote
router.post('/promote', requireAdmin, async (req, res) => {
  try {
    const { user_id, role } = req.body;
    const valid = ['player', 'premium', 'admin'];
    if (!valid.includes(role)) return res.status(400).json({ error: 'Invalid role.' });
    await query('UPDATE users SET role = ? WHERE id = ?', [role, user_id]);
    res.json({ message: `User promoted to ${role}.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to promote user.' });
  }
});

module.exports = router;
