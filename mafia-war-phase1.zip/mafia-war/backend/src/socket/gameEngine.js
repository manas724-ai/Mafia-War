const { query, queryOne } = require('../db/pool');
const { verifyToken } = require('../middleware/auth');

// ── WEAPON DEFINITIONS ─────────────────────────────────────────
const WEAPONS = {
  pistol_basic:      { name: 'Glock 17',      damage: 25,  firerate: 400,  range: 300, ammo: 15,  type: 'pistol'    },
  pistol_desert:     { name: 'Desert Eagle',  damage: 55,  firerate: 600,  range: 350, ammo: 7,   type: 'pistol'    },
  smg_micro:         { name: 'Micro SMG',     damage: 18,  firerate: 100,  range: 200, ammo: 30,  type: 'smg'       },
  smg_mp5:           { name: 'MP5',           damage: 22,  firerate: 120,  range: 250, ammo: 30,  type: 'smg'       },
  shotgun_pump:      { name: 'Pump Shotgun',  damage: 80,  firerate: 800,  range: 100, ammo: 8,   type: 'shotgun'   },
  shotgun_auto:      { name: 'Auto Shotgun',  damage: 60,  firerate: 400,  range: 120, ammo: 10,  type: 'shotgun'   },
  rifle_ak:          { name: 'AK-47',         damage: 35,  firerate: 150,  range: 400, ammo: 30,  type: 'rifle'     },
  rifle_m16:         { name: 'M16',           damage: 30,  firerate: 130,  range: 450, ammo: 30,  type: 'rifle'     },
  sniper_basic:      { name: 'Sniper Rifle',  damage: 120, firerate: 1500, range: 900, ammo: 5,   type: 'sniper'    },
  explosive_grenade: { name: 'Grenade',       damage: 150, firerate: 2000, range: 200, ammo: 3,   type: 'explosive' },
  special_minigun:   { name: 'Minigun',       damage: 20,  firerate: 80,   range: 300, ammo: 100, type: 'special'   },
  special_rocket:    { name: 'RPG',           damage: 250, firerate: 3000, range: 600, ammo: 2,   type: 'special'   },
};

// ── RANK XP THRESHOLDS ────────────────────────────────────────
const RANK_XP = [0,500,1500,3500,7000,13000,22000,35000,55000,80000,115000,160000,220000,300000,420000];

// ── ACTIVE GAME STATE ─────────────────────────────────────────
const rooms       = new Map(); // roomCode → roomState
const userSockets = new Map(); // userId  → socketId

function createRoomState(roomData) {
  return {
    id:         roomData.id,
    code:       roomData.room_code,
    name:       roomData.name,
    map_id:     roomData.map_id,
    mode:       roomData.mode,
    maxPlayers: roomData.max_players,
    status:     'waiting',
    players:    new Map(), // socketId → playerState
    startedAt:  null,
    timer:      null,
    heist:      null,
    territory:  initTerritory(roomData.map_id),
  };
}

function initTerritory(mapId) {
  const zones = ['Alpha','Bravo','Charlie','Delta'];
  const t = {};
  zones.forEach(z => { t[z] = { owner: null, progress: 0 }; });
  return t;
}

function createPlayerState(user, socketId, weapon) {
  const spawnPoints = [
    { x: 100, y: 100 }, { x: 700, y: 100 }, { x: 100, y: 500 }, { x: 700, y: 500 },
    { x: 400, y: 300 }, { x: 200, y: 300 }, { x: 600, y: 300 }, { x: 400, y: 150 }
  ];
  const spawn = spawnPoints[Math.floor(Math.random() * spawnPoints.length)];
  const wp = WEAPONS[weapon] || WEAPONS['pistol_basic'];
  return {
    userId:     user.id,
    socketId,
    username:   user.username,
    faction:    user.faction || 'ghost',
    rank:       user.rank_level,
    x:          spawn.x,
    y:          spawn.y,
    hp:         100,
    maxHp:      100,
    armor:      0,
    kills:      0,
    deaths:     0,
    assists:    0,
    xpEarned:   0,
    cashEarned: 0,
    weapon:     wp,
    weaponId:   weapon,
    ammo:       wp.ammo,
    lastShot:   0,
    isAlive:    true,
    respawnAt:  null,
  };
}

// ── MAIN SOCKET HANDLER ───────────────────────────────────────
function initSocketEngine(io) {

  // Auth middleware for socket
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('No token'));
      const payload = await verifyToken(token);
      const user = await queryOne(
        'SELECT id, username, email, role, faction, rank_level, xp, kills, deaths, cash, is_banned FROM users WHERE id = ?',
        [payload.sub]
      );
      if (!user || user.is_banned) return next(new Error('Unauthorized'));
      socket.user = user;
      next();
    } catch {
      next(new Error('Auth failed'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.user;
    userSockets.set(user.id, socket.id);
    console.log(`[SOCKET] Connected: ${user.username} (${socket.id})`);

    // ── JOIN ROOM ─────────────────────────────────────────────
    socket.on('join_room', async ({ room_code, weapon_id = 'pistol_basic' }) => {
      try {
        const roomData = await queryOne(
          'SELECT * FROM game_rooms WHERE room_code = ? AND status != ?',
          [room_code, 'ended']
        );
        if (!roomData) return socket.emit('error', { message: 'Room not found.' });
        if (roomData.current_players >= roomData.max_players) {
          return socket.emit('error', { message: 'Room is full.' });
        }

        // Verify weapon ownership
        const owned = await queryOne(
          'SELECT * FROM weapons_inventory WHERE user_id = ? AND weapon_id = ?',
          [user.id, weapon_id]
        );
        const finalWeapon = owned ? weapon_id : 'pistol_basic';

        // Init room state if first player
        if (!rooms.has(room_code)) {
          rooms.set(room_code, createRoomState(roomData));
        }
        const room = rooms.get(room_code);

        // Create player state
        const playerState = createPlayerState(user, socket.id, finalWeapon);
        room.players.set(socket.id, playerState);
        socket.join(room_code);
        socket.currentRoom = room_code;

        // Update DB player count
        await query('UPDATE game_rooms SET current_players = ? WHERE id = ?',
          [room.players.size, roomData.id]);

        socket.emit('room_joined', {
          room:    { ...roomData, current_players: room.players.size },
          player:  playerState,
          players: serializePlayers(room),
          territory: room.territory,
        });

        socket.to(room_code).emit('player_joined', {
          player: playerState,
          count:  room.players.size,
        });

        // Auto-start if enough players
        if (room.players.size >= 2 && room.status === 'waiting') {
          startCountdown(io, room_code);
        }
      } catch (err) {
        console.error('[SOCKET] join_room error:', err);
        socket.emit('error', { message: 'Failed to join room.' });
      }
    });

    // ── PLAYER MOVE ───────────────────────────────────────────
    socket.on('move', ({ x, y, angle }) => {
      const room_code = socket.currentRoom;
      if (!room_code) return;
      const room = rooms.get(room_code);
      if (!room) return;
      const player = room.players.get(socket.id);
      if (!player || !player.isAlive) return;

      // Clamp to map bounds (800x600 default)
      player.x = Math.max(0, Math.min(800, x));
      player.y = Math.max(0, Math.min(600, y));
      player.angle = angle;

      socket.to(room_code).emit('player_moved', {
        socketId: socket.id,
        x: player.x, y: player.y, angle
      });
    });

    // ── SHOOT ─────────────────────────────────────────────────
    socket.on('shoot', ({ targetId, angle }) => {
      const room_code = socket.currentRoom;
      if (!room_code) return;
      const room = rooms.get(room_code);
      if (!room || room.status !== 'active') return;
      const shooter = room.players.get(socket.id);
      if (!shooter || !shooter.isAlive) return;

      const now = Date.now();
      if (now - shooter.lastShot < shooter.weapon.firerate) return; // rate limit
      if (shooter.ammo <= 0) {
        socket.emit('out_of_ammo', { weapon: shooter.weaponId });
        return;
      }

      shooter.lastShot = now;
      shooter.ammo--;

      // Broadcast bullet
      io.to(room_code).emit('bullet_fired', {
        shooterId: socket.id,
        x: shooter.x, y: shooter.y,
        angle, weaponType: shooter.weapon.type,
      });

      // Hit detection
      if (targetId) {
        const target = room.players.get(targetId);
        if (target && target.isAlive && targetId !== socket.id) {
          // Check friendly fire (same faction in team mode)
          if (room.mode === 'team' && shooter.faction === target.faction) return;

          const damage = shooter.weapon.damage;
          target.hp = Math.max(0, target.hp - damage);

          io.to(room_code).emit('player_hit', {
            targetId, shooterId: socket.id,
            damage, hp: target.hp
          });

          if (target.hp <= 0) {
            handleKill(io, room, room_code, shooter, target, socket);
          }
        }
      }
    });

    // ── RELOAD ────────────────────────────────────────────────
    socket.on('reload', () => {
      const room = rooms.get(socket.currentRoom);
      if (!room) return;
      const player = room.players.get(socket.id);
      if (!player) return;
      player.ammo = player.weapon.ammo;
      socket.emit('reloaded', { ammo: player.ammo });
    });

    // ── CHAT ─────────────────────────────────────────────────
    socket.on('chat_message', async ({ message, channel = 'room' }) => {
      if (!message || message.length > 200) return;
      const room_code = socket.currentRoom;
      const clean = message.replace(/<[^>]*>/g, '').trim();

      const room = rooms.get(room_code);
      if (!room) return;
      const roomData = await queryOne('SELECT id FROM game_rooms WHERE room_code = ?', [room_code]);
      if (!roomData) return;

      await query('INSERT INTO chat_log (room_id, user_id, message, channel) VALUES (?,?,?,?)',
        [roomData.id, user.id, clean, channel]);

      const payload = {
        id:       Date.now(),
        username: user.username,
        faction:  socket.user.faction,
        message:  clean,
        channel,
        ts:       new Date().toISOString(),
      };

      if (channel === 'room') io.to(room_code).emit('chat', payload);
      else if (channel === 'faction') {
        // Send only to same faction
        room.players.forEach((p, sid) => {
          if (p.faction === user.faction) io.to(sid).emit('chat', payload);
        });
      } else {
        io.emit('chat', payload); // global
      }
    });

    // ── HEIST ACTIONS ─────────────────────────────────────────
    socket.on('heist_action', async ({ action }) => {
      const room_code = socket.currentRoom;
      const room = rooms.get(room_code);
      if (!room || room.mode !== 'heist') return;

      const ACTIONS = ['breach', 'secure', 'hack', 'extract'];
      if (!ACTIONS.includes(action)) return;

      io.to(room_code).emit('heist_update', {
        playerId: socket.id, username: user.username, action,
        ts: Date.now()
      });
    });

    // ── REPORT PLAYER ─────────────────────────────────────────
    socket.on('report_player', async ({ reported_socket_id, reason }) => {
      const room = rooms.get(socket.currentRoom);
      if (!room) return;
      const target = room.players.get(reported_socket_id);
      if (!target) return;
      await query(
        'INSERT INTO player_reports (reporter_id, reported_id, reason) VALUES (?,?,?)',
        [user.id, target.userId, reason || 'other']
      );
      socket.emit('report_sent', { message: 'Report submitted. Thank you.' });
    });

    // ── DISCONNECT ────────────────────────────────────────────
    socket.on('disconnect', async () => {
      userSockets.delete(user.id);
      const room_code = socket.currentRoom;
      if (!room_code) return;
      const room = rooms.get(room_code);
      if (!room) return;

      const player = room.players.get(socket.id);
      room.players.delete(socket.id);

      if (room.players.size === 0) {
        // Clean up empty room
        if (room.timer) clearTimeout(room.timer);
        rooms.delete(room_code);
        await query("UPDATE game_rooms SET status = 'ended', ended_at = NOW() WHERE room_code = ?", [room_code]);
      } else {
        await query('UPDATE game_rooms SET current_players = ? WHERE room_code = ?',
          [room.players.size, room_code]);
        io.to(room_code).emit('player_left', {
          socketId: socket.id,
          username: player?.username,
          count:    room.players.size,
        });
      }
      console.log(`[SOCKET] Disconnected: ${user.username}`);
    });
  });
}

// ── GAME FLOW HELPERS ─────────────────────────────────────────

function startCountdown(io, room_code) {
  const room = rooms.get(room_code);
  if (!room || room.status !== 'waiting') return;
  room.status = 'countdown';

  let count = 5;
  io.to(room_code).emit('countdown', { seconds: count });

  const tick = setInterval(() => {
    count--;
    if (count <= 0) {
      clearInterval(tick);
      startMatch(io, room_code);
    } else {
      io.to(room_code).emit('countdown', { seconds: count });
    }
  }, 1000);
}

async function startMatch(io, room_code) {
  const room = rooms.get(room_code);
  if (!room) return;
  room.status = 'active';
  room.startedAt = Date.now();

  await query("UPDATE game_rooms SET status = 'active', started_at = NOW() WHERE room_code = ?", [room_code]);
  io.to(room_code).emit('match_started', {
    mode:      room.mode,
    map_id:    room.map_id,
    players:   serializePlayers(room),
    territory: room.territory,
    duration:  room.mode === 'heist' ? 300 : 600,
  });

  // Match timer
  const duration = room.mode === 'heist' ? 300000 : 600000;
  room.timer = setTimeout(() => endMatch(io, room_code), duration);
}

async function handleKill(io, room, room_code, killer, victim, killerSocket) {
  victim.hp = 0;
  victim.isAlive = false;
  victim.deaths++;
  killer.kills++;
  killer.xpEarned  += 50;
  killer.cashEarned += 500;

  const xpBonus = killer.kills >= 3 ? killer.kills * 10 : 0; // kill streak bonus

  io.to(room_code).emit('player_killed', {
    killerId:      killer.socketId,
    killerName:    killer.username,
    victimId:      victim.socketId,
    victimName:    victim.username,
    weapon:        killer.weapon.name,
    killerKills:   killer.kills,
    killStreak:    killer.kills,
    xpBonus,
  });

  // Update killer live stats
  killerSocket.emit('stats_update', {
    kills:    killer.kills,
    xp:       killer.xpEarned,
    cash:     killer.cashEarned,
    ammo:     killer.ammo,
  });

  // Respawn victim after 5 seconds
  victim.respawnAt = Date.now() + 5000;
  const victimSocket = io.sockets.sockets.get(victim.socketId);
  if (victimSocket) {
    victimSocket.emit('you_died', {
      killedBy: killer.username,
      respawnIn: 5,
    });
  }

  setTimeout(() => {
    if (!room.players.has(victim.socketId)) return;
    const spawnPoints = [{ x: 100,y:100},{x:700,y:100},{x:100,y:500},{x:700,y:500}];
    const spawn = spawnPoints[Math.floor(Math.random() * spawnPoints.length)];
    victim.x = spawn.x;
    victim.y = spawn.y;
    victim.hp = 100;
    victim.isAlive = true;
    victim.respawnAt = null;

    if (victimSocket) victimSocket.emit('respawned', { x: spawn.x, y: spawn.y, hp: 100 });
    io.to(room_code).emit('player_respawned', { socketId: victim.socketId, x: spawn.x, y: spawn.y });
  }, 5000);
}

async function endMatch(io, room_code) {
  const room = rooms.get(room_code);
  if (!room || room.status === 'ended') return;
  room.status = 'ended';
  if (room.timer) clearTimeout(room.timer);

  // Determine winner
  let winner = null;
  let topKills = -1;
  room.players.forEach(p => {
    if (p.kills > topKills) { topKills = p.kills; winner = p; }
  });

  // Save match results to DB
  const roomData = await queryOne('SELECT id FROM game_rooms WHERE room_code = ?', [room_code]);

  for (const [, player] of room.players) {
    const isWinner = player.socketId === winner?.socketId;
    const outcome  = isWinner ? 'win' : 'loss';
    const bonusXp  = isWinner ? 200 : 50;
    const totalXp  = player.xpEarned + bonusXp;
    const totalCash= player.cashEarned + (isWinner ? 2000 : 500);

    if (roomData) {
      await query(
        'INSERT INTO match_history (room_id, user_id, kills, deaths, assists, xp_earned, cash_earned, outcome) VALUES (?,?,?,?,?,?,?,?)',
        [roomData.id, player.userId, player.kills, player.deaths, player.assists, totalXp, totalCash, outcome]
      );
    }

    // Update user stats and XP
    const userRow = await queryOne('SELECT xp, rank_level, kills, deaths FROM users WHERE id = ?', [player.userId]);
    if (userRow) {
      const newXp    = userRow.xp + totalXp;
      const newRank  = calcRank(newXp);
      const rankedUp = newRank > userRow.rank_level;

      await query(
        'UPDATE users SET xp = ?, rank_level = ?, kills = kills + ?, deaths = deaths + ?, cash = cash + ? WHERE id = ?',
        [newXp, newRank, player.kills, player.deaths, totalCash, player.userId]
      );
      await query(
        'UPDATE leaderboard SET total_kills = kills + ?, rank_level = ?, kd_ratio = ROUND(kills/GREATEST(deaths,1),2) WHERE user_id = ?',
        [player.kills, newRank, player.userId]
      );

      const pSocket = io.sockets.sockets.get(player.socketId);
      if (pSocket) {
        pSocket.emit('match_result', {
          outcome, kills: player.kills, deaths: player.deaths,
          xpEarned: totalXp, cashEarned: totalCash,
          newXp, newRank, rankedUp,
          rankTitle: getRankTitle(newRank),
        });
      }
    }
  }

  io.to(room_code).emit('match_ended', {
    winner:   winner ? { username: winner.username, kills: winner.kills, faction: winner.faction } : null,
    scoreboard: serializePlayers(room),
  });

  await query("UPDATE game_rooms SET status = 'ended', ended_at = NOW() WHERE room_code = ?", [room_code]);
  rooms.delete(room_code);
}

function calcRank(xp) {
  let rank = 1;
  for (let i = RANK_XP.length - 1; i >= 0; i--) {
    if (xp >= RANK_XP[i]) { rank = i + 1; break; }
  }
  return Math.min(rank, 15);
}

const RANK_TITLES = ['','Street Rat','Thug','Runner','Enforcer','Soldier','Made Man','Lieutenant','Capo','Underboss','Consigliere','Boss','Don','Crime Lord','Kingpin','Godfather'];
function getRankTitle(level) { return RANK_TITLES[level] || 'Godfather'; }

function serializePlayers(room) {
  const out = [];
  room.players.forEach(p => out.push({
    socketId: p.socketId, username: p.username, faction: p.faction,
    rank: p.rank, x: p.x, y: p.y, hp: p.hp, isAlive: p.isAlive,
    kills: p.kills, deaths: p.deaths, weaponType: p.weapon.type,
  }));
  return out;
}

module.exports = { initSocketEngine };
