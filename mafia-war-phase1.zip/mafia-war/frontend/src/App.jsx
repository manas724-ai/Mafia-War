import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import AgeGate  from './pages/AgeGate';
import Auth     from './pages/Auth';
import Lobby    from './pages/Lobby';
import Game     from './pages/Game';
import Admin    from './pages/Admin';
import Legal    from './pages/Legal';
import { PaymentSuccess, PaymentCancel } from './pages/Payment';

function PrivateRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="animate-pulse" style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:6, color:'#c0392b' }}>
        LOADING...
      </div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

function AppInner() {
  const [ageOk, setAgeOk] = useState(!!sessionStorage.getItem('mw_age_ok'));

  if (!ageOk) return <AgeGate onConfirm={() => setAgeOk(true)} />;

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/"          element={<Navigate to="/lobby" replace />} />
        <Route path="/login"     element={<Auth mode="login" />} />
        <Route path="/register"  element={<Auth mode="register" />} />
        <Route path="/terms"     element={<Legal />} />
        <Route path="/payment/success" element={<PaymentSuccess />} />
        <Route path="/payment/cancel"  element={<PaymentCancel />} />

        <Route path="/lobby" element={
          <PrivateRoute><Lobby /></PrivateRoute>
        } />
        <Route path="/game/:code" element={
          <PrivateRoute><Game /></PrivateRoute>
        } />
        <Route path="/admin" element={
          <PrivateRoute><Admin /></PrivateRoute>
        } />

        <Route path="*" element={<Navigate to="/lobby" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}
