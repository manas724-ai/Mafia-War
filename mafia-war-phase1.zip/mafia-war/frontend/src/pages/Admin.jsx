import { useState, useEffect } from 'react';
import { useAuth, API } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Admin() {
  const { user } = useAuth();
  const navigate  = useNavigate();
  const [tab,     setTab]     = useState('stats');
  const [stats,   setStats]   = useState(null);
  const [users,   setUsers]   = useState([]);
  const [reports, setReports] = useState([]);
  const [search,  setSearch]  = useState('');
  const [msg,     setMsg]     = useState('');

  useEffect(() => {
    if (!user || !['admin','owner'].includes(user.role)) navigate('/lobby');
  }, [user, navigate]);

  useEffect(() => {
    API.get('/admin/stats').then(r => setStats(r.data)).catch(() => {});
    API.get('/admin/reports').then(r => setReports(r.data.reports)).catch(() => {});
  }, []);

  const loadUsers = async () => {
    const { data } = await API.get(`/admin/users?search=${search}`);
    setUsers(data.users);
  };

  const ban = async (id, reason) => {
    await API.post('/admin/ban', { user_id: id, reason });
    setMsg('Player banned.'); loadUsers();
  };

  const unban = async (id) => {
    await API.post('/admin/unban', { user_id: id });
    setMsg('Player unbanned.'); loadUsers();
  };

  const resolve = async (id) => {
    await API.post(`/admin/reports/${id}/resolve`);
    setReports(prev => prev.filter(r => r.id !== id));
  };

  return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a' }}>
      <nav style={{ background:'#111', borderBottom:'1px solid #2a2a2a', padding:'12px 24px', display:'flex', alignItems:'center', gap:16 }}>
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, letterSpacing:4, color:'#e8e4dc' }}>
          ADMIN PANEL
        </div>
        <span className="badge badge-red">RESTRICTED</span>
        <button className="btn btn-ghost btn-sm" style={{ marginLeft:'auto' }} onClick={() => navigate('/lobby')}>← Lobby</button>
      </nav>

      <div style={{ display:'flex', borderBottom:'1px solid #2a2a2a', background:'#111', padding:'0 24px' }}>
        {['stats','users','reports'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding:'14px 20px', background:'none', color: tab===t ? '#e8e4dc' : '#9a9590',
            borderBottom: tab===t ? '2px solid #8b0000' : '2px solid transparent',
            fontFamily:'Share Tech Mono, monospace', fontSize:12, letterSpacing:1, textTransform:'uppercase',
          }}>{t}</button>
        ))}
      </div>

      <div style={{ padding:'32px 24px', maxWidth:1000, margin:'0 auto' }}>
        {msg && <div className="success-msg" style={{ marginBottom:16 }}>{msg}</div>}

        {/* STATS */}
        {tab === 'stats' && stats && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, marginBottom:24, color:'#e8e4dc' }}>Dashboard</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(160px,1fr))', gap:12 }}>
              {[
                { label:'Total Users',   value: stats.total_users },
                { label:'Active Rooms',  value: stats.active_rooms },
                { label:'Premium Users', value: stats.premium_users },
                { label:'Banned Users',  value: stats.banned_users },
                { label:'Open Reports',  value: stats.open_reports },
                { label:'Revenue (AUD)', value: stats.total_revenue_cents ? `$${(stats.total_revenue_cents/100).toFixed(2)}` : '$0.00' },
              ].map(({ label, value }) => (
                <div key={label} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'20px 16px', textAlign:'center' }}>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590', marginBottom:8, textTransform:'uppercase' }}>{label}</div>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:36, color:'#c9a84c' }}>{value ?? 0}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div className="animate-fadeIn">
            <div style={{ display:'flex', gap:12, marginBottom:20 }}>
              <input className="input" placeholder="Search username or email..." value={search}
                onChange={e => setSearch(e.target.value)} style={{ maxWidth:320 }} />
              <button className="btn btn-primary" onClick={loadUsers}>Search</button>
            </div>
            <table style={{ width:'100%', borderCollapse:'collapse' }}>
              <thead>
                <tr style={{ borderBottom:'1px solid #2a2a2a' }}>
                  {['ID','Username','Email','Role','Rank','Kills','Status','Actions'].map(h => (
                    <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id} style={{ borderBottom:'1px solid #1a1a1a' }}>
                    <td style={{ padding:'10px 12px', color:'#9a9590', fontSize:12 }}>{u.id}</td>
                    <td style={{ padding:'10px 12px', color:'#e8e4dc', fontWeight:500 }}>{u.username}</td>
                    <td style={{ padding:'10px 12px', color:'#9a9590', fontSize:12 }}>{u.email}</td>
                    <td style={{ padding:'10px 12px' }}><span className={`badge badge-${u.role==='admin'?'red':u.role==='premium'?'gold':'muted'}`}>{u.role}</span></td>
                    <td style={{ padding:'10px 12px', color:'#9a9590' }}>{u.rank_level}</td>
                    <td style={{ padding:'10px 12px', color:'#9a9590' }}>{u.kills}</td>
                    <td style={{ padding:'10px 12px' }}><span className={`badge badge-${u.is_banned?'red':'green'}`}>{u.is_banned?'Banned':'Active'}</span></td>
                    <td style={{ padding:'10px 12px', display:'flex', gap:6 }}>
                      {u.is_banned
                        ? <button className="btn btn-success btn-sm" onClick={() => unban(u.id)}>Unban</button>
                        : <button className="btn btn-danger btn-sm" onClick={() => ban(u.id, 'Admin action')}>Ban</button>
                      }
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr><td colSpan={8} style={{ padding:'32px', textAlign:'center', color:'#9a9590' }}>Search for users above</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* REPORTS */}
        {tab === 'reports' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, letterSpacing:4, marginBottom:24, color:'#e8e4dc' }}>
              Open Reports ({reports.length})
            </div>
            {reports.length === 0
              ? <div style={{ color:'#9a9590', padding:'40px 0', textAlign:'center' }}>No open reports.</div>
              : reports.map(r => (
                <div key={r.id} style={{ background:'#111', border:'1px solid #2a2a2a', padding:'16px 20px', marginBottom:8, display:'flex', alignItems:'center', gap:16, flexWrap:'wrap' }}>
                  <div style={{ flex:1 }}>
                    <div style={{ color:'#e8e4dc', fontWeight:500 }}>
                      <span style={{ color:'#c0392b' }}>{r.reported_name}</span> reported by {r.reporter_name}
                    </div>
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', marginTop:4, letterSpacing:1 }}>
                      {r.reason.toUpperCase()} · {new Date(r.created_at).toLocaleDateString()}
                    </div>
                    {r.description && <div style={{ fontSize:13, color:'#9a9590', marginTop:6 }}>{r.description}</div>}
                  </div>
                  <div style={{ display:'flex', gap:8 }}>
                    <button className="btn btn-danger btn-sm" onClick={() => ban(r.reported_id, r.reason)}>Ban Player</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => resolve(r.id)}>Dismiss</button>
                  </div>
                </div>
              ))
            }
          </div>
        )}
      </div>
    </div>
  );
}
