import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';

// ── MAPS ─────────────────────────────────────────────────────
const MAP_COLORS = {
  downtown:    { bg: '#0a0a0a', ground: '#1a1a1a', wall: '#2a2a2a', accent: '#8b0000' },
  chinatown:   { bg: '#050a05', ground: '#0f1a0f', wall: '#1a2a1a', accent: '#c9a84c' },
  harbour:     { bg: '#050810', ground: '#0a1020', wall: '#1a2030', accent: '#3b82f6' },
  casino:      { bg: '#0a0800', ground: '#1a1500', wall: '#2a2200', accent: '#c9a84c' },
  penthouse:   { bg: '#050510', ground: '#0f0f1a', wall: '#1a1a2a', accent: '#8b5cf6' },
  default:     { bg: '#0a0a0a', ground: '#1a1a1a', wall: '#2a2a2a', accent: '#8b0000' },
};

const FACTION_COLORS = { ghost: '#9ca3af', viper: '#c9a84c', iron: '#60a5fa', shadow: '#8b0000' };

export default function Game() {
  const { code }        = useParams();
  const [params]        = useSearchParams();
  const { user }        = useAuth();
  const navigate        = useNavigate();

  const canvasRef   = useRef(null);
  const socketRef   = useRef(null);
  const stateRef    = useRef({
    me: null, players: {}, bullets: [], particles: [], kills: [],
    keys: {}, mouse: { x: 400, y: 300 }, chatOpen: false,
    map: 'downtown', mode: 'deathmatch', status: 'waiting',
    territory: {}, timer: null,
  });
  const animRef     = useRef(null);
  const chatInputRef = useRef(null);

  const [phase,   setPhase]   = useState('connecting'); // connecting|waiting|countdown|active|ended
  const [hud,     setHud]     = useState({ hp: 100, kills: 0, ammo: 15, cash: 0, xp: 0 });
  const [msgs,    setMsgs]    = useState([]);
  const [chatMsg, setChatMsg] = useState('');
  const [result,  setResult]  = useState(null);
  const [error,   setError]   = useState('');
  const [countdown, setCountdown] = useState(null);
  const [deathMsg,  setDeathMsg]  = useState('');
  const [killfeed,  setKillfeed]  = useState([]);

  // ── CONNECT SOCKET ────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    const token  = localStorage.getItem('mw_access');
    const weapon = params.get('weapon') || 'pistol_basic';

    const s = io('/', { auth: { token }, transports: ['websocket'] });
    socketRef.current = s;

    s.on('connect', () => {
      s.emit('join_room', { room_code: code, weapon_id: weapon });
    });

    s.on('connect_error', () => setError('Connection failed. Check your internet.'));

    s.on('room_joined', ({ room, player, players, territory }) => {
      const st = stateRef.current;
      st.me       = player;
      st.map      = room.map_id;
      st.mode     = room.mode;
      st.territory= territory || {};
      players.forEach(p => { st.players[p.socketId] = p; });
      setPhase('waiting');
      setHud({ hp: player.hp, kills: 0, ammo: player.ammo || 15, cash: 0, xp: 0 });
    });

    s.on('player_joined', ({ player }) => {
      stateRef.current.players[player.socketId] = player;
      addMsg(`${player.username} joined the war.`, 'system');
    });

    s.on('player_left', ({ socketId, username }) => {
      delete stateRef.current.players[socketId];
      addMsg(`${username || '?'} left.`, 'system');
    });

    s.on('countdown', ({ seconds }) => {
      setPhase('countdown');
      setCountdown(seconds);
    });

    s.on('match_started', ({ map_id, mode }) => {
      stateRef.current.map  = map_id;
      stateRef.current.mode = mode;
      stateRef.current.status = 'active';
      setPhase('active');
      setCountdown(null);
    });

    s.on('player_moved', ({ socketId, x, y, angle }) => {
      const p = stateRef.current.players[socketId];
      if (p) { p.x = x; p.y = y; p.angle = angle; }
    });

    s.on('bullet_fired', ({ shooterId, x, y, angle, weaponType }) => {
      stateRef.current.bullets.push({
        id: Math.random(), x, y, angle, type: weaponType,
        speed: weaponType === 'sniper' ? 20 : 12,
        life: weaponType === 'explosive' ? 60 : 40,
      });
    });

    s.on('player_hit', ({ targetId, damage, hp }) => {
      const p = stateRef.current.players[targetId];
      if (p) {
        p.hp = hp;
        // Spawn hit particles
        stateRef.current.particles.push(
          ...Array.from({ length: 6 }, () => ({
            x: p.x, y: p.y,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 6,
            life: 20, color: '#c0392b', size: 3,
          }))
        );
      }
      if (targetId === socketRef.current?.id) {
        setHud(h => ({ ...h, hp: Math.max(0, hp) }));
      }
    });

    s.on('player_killed', ({ killerName, victimName, weapon, killerId }) => {
      const feed = `${killerName}  ☠  ${victimName}  [${weapon}]`;
      setKillfeed(prev => [...prev.slice(-4), feed]);
      setTimeout(() => setKillfeed(prev => prev.filter(m => m !== feed)), 4000);

      if (killerId === s.id) {
        setHud(h => ({ ...h, kills: h.kills + 1, xp: h.xp + 50, cash: h.cash + 500 }));
        // Victory particles at kill location
        const p = stateRef.current.players[killerId];
        if (p) {
          stateRef.current.particles.push(
            ...Array.from({ length: 12 }, () => ({
              x: p.x, y: p.y,
              vx: (Math.random() - 0.5) * 10,
              vy: (Math.random() - 0.5) * 10,
              life: 35, color: '#c9a84c', size: 4,
            }))
          );
        }
      }

      const victim = Object.values(stateRef.current.players).find(p => p.username === victimName);
      if (victim) { victim.isAlive = false; victim.hp = 0; }
    });

    s.on('you_died', ({ killedBy, respawnIn }) => {
      setDeathMsg(`You were killed by ${killedBy}. Respawning in ${respawnIn}s...`);
      setTimeout(() => setDeathMsg(''), respawnIn * 1000 + 500);
    });

    s.on('respawned', ({ x, y, hp }) => {
      const me = stateRef.current.me;
      if (me) { me.x = x; me.y = y; me.hp = hp; me.isAlive = true; }
      setHud(h => ({ ...h, hp }));
    });

    s.on('player_respawned', ({ socketId, x, y }) => {
      const p = stateRef.current.players[socketId];
      if (p) { p.x = x; p.y = y; p.hp = 100; p.isAlive = true; }
    });

    s.on('stats_update', ({ kills, xp, cash, ammo }) => {
      setHud(h => ({ ...h, kills: kills ?? h.kills, xp: xp ?? h.xp, cash: cash ?? h.cash, ammo: ammo ?? h.ammo }));
    });

    s.on('out_of_ammo', () => addMsg('Out of ammo! Press R to reload.', 'system'));
    s.on('reloaded', ({ ammo }) => setHud(h => ({ ...h, ammo })));

    s.on('chat', (msg) => addMsg(`${msg.username}: ${msg.message}`, msg.channel));

    s.on('match_ended', ({ winner, scoreboard }) => {
      stateRef.current.status = 'ended';
      setPhase('ended');
    });

    s.on('match_result', (data) => setResult(data));

    s.on('error', ({ message }) => setError(message));

    return () => s.disconnect();
  }, [code, user, params]);

  const addMsg = useCallback((text, type = 'chat') => {
    setMsgs(prev => [...prev.slice(-30), { text, type, id: Date.now() + Math.random() }]);
  }, []);

  // ── INPUT HANDLING ────────────────────────────────────────
  useEffect(() => {
    const st = stateRef.current;

    const onKey = (e) => {
      if (st.chatOpen) return;
      st.keys[e.code] = e.type === 'keydown';

      if (e.type === 'keydown') {
        if (e.code === 'Enter') { st.chatOpen = true; chatInputRef.current?.focus(); }
        if (e.code === 'KeyR' && socketRef.current) socketRef.current.emit('reload');
      }
    };

    const onMouse = (e) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      st.mouse.x = e.clientX - rect.left;
      st.mouse.y = e.clientY - rect.top;
    };

    const onClick = (e) => {
      if (st.chatOpen || phase !== 'active') return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;

      const me = st.me;
      if (!me || !me.isAlive) return;

      const angle = Math.atan2(cy - me.y, cx - me.x);

      // Find nearest target
      let targetId = null;
      let minDist = 300;
      Object.entries(st.players).forEach(([sid, p]) => {
        if (sid === socketRef.current?.id || !p.isAlive) return;
        const d = Math.hypot(p.x - me.x, p.y - me.y);
        if (d < minDist) { minDist = d; targetId = sid; }
      });

      socketRef.current?.emit('shoot', { targetId, angle });
    };

    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup',   onKey);
    window.addEventListener('mousemove', onMouse);
    canvasRef.current?.addEventListener('click', onClick);

    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('keyup',   onKey);
      window.removeEventListener('mousemove', onMouse);
    };
  }, [phase]);

  // ── MOVEMENT LOOP ─────────────────────────────────────────
  useEffect(() => {
    if (phase !== 'active') return;
    const SPEED = 3;
    let raf;
    const loop = () => {
      const st = stateRef.current;
      const me = st.me;
      if (me && me.isAlive && !st.chatOpen) {
        let dx = 0, dy = 0;
        if (st.keys['KeyW'] || st.keys['ArrowUp'])    dy -= SPEED;
        if (st.keys['KeyS'] || st.keys['ArrowDown'])  dy += SPEED;
        if (st.keys['KeyA'] || st.keys['ArrowLeft'])  dx -= SPEED;
        if (st.keys['KeyD'] || st.keys['ArrowRight']) dx += SPEED;

        if (dx !== 0 || dy !== 0) {
          me.x = Math.max(20, Math.min(780, me.x + dx));
          me.y = Math.max(20, Math.min(580, me.y + dy));
          me.angle = Math.atan2(st.mouse.y - me.y, st.mouse.x - me.x);
          socketRef.current?.emit('move', { x: me.x, y: me.y, angle: me.angle });
          st.players[socketRef.current?.id] = me;
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  // ── RENDER LOOP ───────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const render = () => {
      const st    = stateRef.current;
      const W     = canvas.width;
      const H     = canvas.height;
      const colors = MAP_COLORS[st.map] || MAP_COLORS.default;
      const me    = st.me;
      const myId  = socketRef.current?.id;

      // Background
      ctx.fillStyle = colors.bg;
      ctx.fillRect(0, 0, W, H);

      // Grid / ground
      ctx.strokeStyle = colors.ground;
      ctx.lineWidth = 0.5;
      for (let x = 0; x < W; x += 40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,H); ctx.stroke(); }
      for (let y = 0; y < H; y += 40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke(); }

      // Map obstacles (static walls per map)
      ctx.fillStyle = colors.wall;
      const walls = getMapWalls(st.map);
      walls.forEach(w => ctx.fillRect(w.x, w.y, w.w, w.h));

      // Territory zones
      if (st.mode === 'territory' && st.territory) {
        const zones = [
          { key: 'Alpha', x: 80, y: 80 }, { key: 'Bravo', x: 620, y: 80 },
          { key: 'Charlie', x: 80, y: 440 }, { key: 'Delta', x: 620, y: 440 },
        ];
        zones.forEach(z => {
          const t = st.territory[z.key];
          const col = t?.owner ? FACTION_COLORS[t.owner] : '#333';
          ctx.strokeStyle = col; ctx.lineWidth = 2;
          ctx.strokeRect(z.x, z.y, 100, 80);
          ctx.fillStyle = col + '22';
          ctx.fillRect(z.x, z.y, 100, 80);
          ctx.fillStyle = col; ctx.font = '10px Share Tech Mono';
          ctx.textAlign = 'center';
          ctx.fillText(z.key, z.x + 50, z.y + 45);
        });
      }

      // Players
      Object.entries(st.players).forEach(([sid, p]) => {
        if (!p.isAlive) return;
        const isMe = sid === myId;
        const fc = FACTION_COLORS[p.faction] || '#9ca3af';

        // Shadow
        ctx.beginPath();
        ctx.ellipse(p.x, p.y + 14, 14, 5, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fill();

        // Body
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle || 0);

        // Torso
        ctx.fillStyle = isMe ? fc : fc + 'bb';
        ctx.fillRect(-8, -10, 16, 20);

        // Gun
        ctx.fillStyle = '#555';
        ctx.fillRect(8, -2, 16, 4);

        ctx.restore();

        // Head
        ctx.beginPath();
        ctx.arc(p.x, p.y - 14, 8, 0, Math.PI * 2);
        ctx.fillStyle = isMe ? fc : fc + 'bb';
        ctx.fill();
        if (isMe) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke(); }

        // HP bar
        const barW = 30, barH = 4;
        ctx.fillStyle = '#222';
        ctx.fillRect(p.x - barW/2, p.y - 28, barW, barH);
        const ratio = p.hp / 100;
        ctx.fillStyle = ratio > 0.5 ? '#22c55e' : ratio > 0.25 ? '#f59e0b' : '#c0392b';
        ctx.fillRect(p.x - barW/2, p.y - 28, barW * ratio, barH);

        // Name
        ctx.font = isMe ? 'bold 11px Inter' : '10px Inter';
        ctx.fillStyle = isMe ? '#fff' : fc;
        ctx.textAlign = 'center';
        ctx.fillText(p.username, p.x, p.y - 32);
      });

      // Bullets
      stateRef.current.bullets = st.bullets.filter(b => b.life > 0);
      st.bullets.forEach(b => {
        b.x += Math.cos(b.angle) * b.speed;
        b.y += Math.sin(b.angle) * b.speed;
        b.life--;

        ctx.beginPath();
        ctx.arc(b.x, b.y, b.type === 'sniper' ? 3 : 2, 0, Math.PI * 2);
        ctx.fillStyle = b.type === 'explosive' ? '#f97316' : '#fbbf24';
        ctx.globalAlpha = b.life / 40;
        ctx.fill();
        ctx.globalAlpha = 1;

        // Trail
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - Math.cos(b.angle) * 12, b.y - Math.sin(b.angle) * 12);
        ctx.strokeStyle = b.type === 'explosive' ? 'rgba(249,115,22,0.4)' : 'rgba(251,191,36,0.3)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });

      // Particles
      stateRef.current.particles = st.particles.filter(p => p.life > 0);
      st.particles.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.life--;
        p.vx *= 0.9; p.vy *= 0.9;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * (p.life / 35), 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 35;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      // Crosshair (mouse position)
      if (me && me.isAlive) {
        const mx = st.mouse.x, my2 = st.mouse.y;
        ctx.strokeStyle = 'rgba(255,255,255,0.6)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(mx - 10, my2); ctx.lineTo(mx + 10, my2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(mx, my2 - 10); ctx.lineTo(mx, my2 + 10); ctx.stroke();
        ctx.beginPath(); ctx.arc(mx, my2, 5, 0, Math.PI * 2); ctx.stroke();
      }

      animRef.current = requestAnimationFrame(render);
    };

    animRef.current = requestAnimationFrame(render);
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [phase]);

  // ── SEND CHAT ─────────────────────────────────────────────
  const sendChat = () => {
    if (!chatMsg.trim()) return;
    socketRef.current?.emit('chat_message', { message: chatMsg, channel: 'room' });
    setChatMsg('');
    stateRef.current.chatOpen = false;
  };

  if (error) {
    return (
      <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:16 }}>
        <div style={{ color:'#c0392b', fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:4 }}>CONNECTION ERROR</div>
        <div style={{ color:'#9a9590' }}>{error}</div>
        <button className="btn btn-primary" onClick={() => navigate('/lobby')}>Back to Lobby</button>
      </div>
    );
  }

  return (
    <div style={{ display:'flex', height:'100vh', background:'#0a0a0a', overflow:'hidden', flexDirection:'column' }}>

      {/* TOP HUD BAR */}
      <div style={{ background:'#111', borderBottom:'1px solid #2a2a2a', padding:'8px 16px', display:'flex', alignItems:'center', gap:24, flexShrink:0, zIndex:10 }}>
        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:4, color:'#e8e4dc' }}>
          MAFIA<span style={{ color:'#c0392b' }}>WAR</span>
        </div>
        <span className="badge badge-muted" style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:2 }}>{code}</span>
        {phase === 'active' && <>
          <div style={{ display:'flex', gap:24, marginLeft:'auto' }}>
            {[
              { label:'HP',    value: `${hud.hp}%`,          color: hud.hp > 50 ? '#22c55e' : hud.hp > 25 ? '#f59e0b' : '#c0392b' },
              { label:'AMMO',  value: hud.ammo,               color: '#e8e4dc' },
              { label:'KILLS', value: hud.kills,              color: '#c9a84c' },
              { label:'CASH',  value: `$${hud.cash.toLocaleString()}`, color: '#c9a84c' },
              { label:'XP',    value: hud.xp.toLocaleString(),color: '#8b5cf6' },
            ].map(({ label, value, color }) => (
              <div key={label} style={{ textAlign:'center' }}>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, letterSpacing:2, color:'#9a9590', marginBottom:2 }}>{label}</div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:18, letterSpacing:1, color }}>{value}</div>
              </div>
            ))}
          </div>
        </>}
        <button className="btn btn-ghost btn-sm" style={{ marginLeft: phase !== 'active' ? 'auto' : undefined }} onClick={() => { socketRef.current?.disconnect(); navigate('/lobby'); }}>Leave</button>
      </div>

      <div style={{ flex:1, display:'flex', overflow:'hidden', position:'relative' }}>

        {/* GAME CANVAS */}
        <canvas ref={canvasRef} width={800} height={600}
          style={{ flex:1, maxHeight:'100%', cursor: phase === 'active' ? 'none' : 'default', objectFit:'contain' }}
        />

        {/* KILL FEED */}
        <div style={{ position:'absolute', top:12, right:12, display:'flex', flexDirection:'column', gap:4, alignItems:'flex-end' }}>
          {killfeed.map((msg, i) => (
            <div key={i} style={{ background:'rgba(0,0,0,0.7)', padding:'4px 10px', fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#c0392b', borderLeft:'2px solid #8b0000' }}>
              {msg}
            </div>
          ))}
        </div>

        {/* DEATH SCREEN */}
        {deathMsg && (
          <div style={{ position:'absolute', inset:0, background:'rgba(139,0,0,0.3)', display:'flex', alignItems:'center', justifyContent:'center', pointerEvents:'none' }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:36, letterSpacing:4, color:'#c0392b', textShadow:'0 0 40px #8b0000' }}>{deathMsg}</div>
          </div>
        )}

        {/* WAITING OVERLAY */}
        {phase === 'waiting' && (
          <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.85)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:12 }}>
            <div className="animate-pulse" style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:48, letterSpacing:6, color:'#e8e4dc' }}>WAITING FOR PLAYERS</div>
            <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:12, color:'#9a9590', letterSpacing:3 }}>Room Code: <span style={{ color:'#c9a84c' }}>{code}</span></div>
            <div style={{ fontSize:13, color:'#9a9590' }}>Share the room code. Game starts when 2+ players are ready.</div>
          </div>
        )}

        {/* COUNTDOWN OVERLAY */}
        {phase === 'countdown' && countdown !== null && (
          <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', pointerEvents:'none' }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:120, color:'#c0392b', textShadow:'0 0 60px #8b0000', lineHeight:1 }}>{countdown}</div>
          </div>
        )}

        {/* MATCH RESULT */}
        {result && (
          <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.92)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:16 }}>
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:64, letterSpacing:6, color: result.outcome === 'win' ? '#c9a84c' : '#c0392b' }}>
              {result.outcome === 'win' ? '⚡ VICTORY' : '☠ DEFEATED'}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginTop:8 }}>
              {[
                { label:'Kills',     value: result.kills    },
                { label:'Deaths',    value: result.deaths   },
                { label:'XP Earned', value: `+${result.xpEarned}` },
                { label:'Cash',      value: `+$${result.cashEarned}` },
              ].map(({ label, value }) => (
                <div key={label} style={{ textAlign:'center', background:'#111', padding:'16px 24px', border:'1px solid #2a2a2a' }}>
                  <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', marginBottom:6, letterSpacing:2 }}>{label}</div>
                  <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#e8e4dc' }}>{value}</div>
                </div>
              ))}
            </div>
            {result.rankedUp && (
              <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:24, color:'#c9a84c', letterSpacing:4 }}>🏆 RANK UP — {result.rankTitle}</div>
            )}
            <div style={{ display:'flex', gap:12, marginTop:8 }}>
              <button className="btn btn-primary" onClick={() => navigate('/lobby')}>Back to Lobby</button>
              <button className="btn btn-secondary" onClick={() => window.location.reload()}>Play Again</button>
            </div>
          </div>
        )}

        {/* CHAT SIDEBAR */}
        <div style={{ width:240, background:'#111', borderLeft:'1px solid #2a2a2a', display:'flex', flexDirection:'column', flexShrink:0 }}>
          <div style={{ padding:'8px 12px', borderBottom:'1px solid #2a2a2a', fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:2, color:'#9a9590' }}>
            COMMS
          </div>
          <div style={{ flex:1, overflow:'auto', padding:'8px 12px', display:'flex', flexDirection:'column', gap:4 }}>
            {msgs.map(m => (
              <div key={m.id} style={{
                fontSize: 12, lineHeight: 1.4,
                color: m.type === 'system' ? '#c9a84c' : m.type === 'faction' ? '#8b5cf6' : '#e8e4dc',
                fontStyle: m.type === 'system' ? 'italic' : 'normal',
              }}>{m.text}</div>
            ))}
          </div>
          <div style={{ padding:'8px 12px', borderTop:'1px solid #2a2a2a', display:'flex', gap:8 }}>
            <input ref={chatInputRef} className="input" value={chatMsg} placeholder="Press Enter to chat..."
              style={{ flex:1, fontSize:12, padding:'6px 10px' }}
              onChange={e => setChatMsg(e.target.value)}
              onFocus={() => { stateRef.current.chatOpen = true; }}
              onBlur={() => { stateRef.current.chatOpen = false; }}
              onKeyDown={e => { if (e.key === 'Enter') sendChat(); if (e.key === 'Escape') { stateRef.current.chatOpen = false; chatInputRef.current?.blur(); }}}
            />
            <button className="btn btn-primary btn-sm" onClick={sendChat}>→</button>
          </div>
          <div style={{ padding:'8px 12px', borderTop:'1px solid #1a1a1a', fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#444', lineHeight:1.6 }}>
            WASD: Move<br/>
            Click: Shoot<br/>
            R: Reload<br/>
            Enter: Chat
          </div>
        </div>
      </div>
    </div>
  );
}

// ── MAP WALLS ────────────────────────────────────────────────
function getMapWalls(mapId) {
  const walls = {
    downtown: [
      { x: 100, y: 50,  w: 20, h: 120 }, { x: 300, y: 80,  w: 120, h: 20 },
      { x: 580, y: 150, w: 20, h: 100 }, { x: 200, y: 250, w: 80,  h: 20 },
      { x: 450, y: 200, w: 20, h: 150 }, { x: 100, y: 380, w: 140, h: 20 },
      { x: 600, y: 350, w: 20, h: 120 }, { x: 320, y: 450, w: 100, h: 20 },
      { x: 50,  y: 520, w: 200, h: 20 }, { x: 550, y: 500, w: 150, h: 20 },
    ],
    chinatown: [
      { x: 80,  y: 100, w: 20, h: 200 }, { x: 200, y: 60,  w: 20, h: 150 },
      { x: 350, y: 120, w: 150, h: 20 }, { x: 560, y: 80,  w: 20, h: 180 },
      { x: 150, y: 320, w: 100, h: 20 }, { x: 400, y: 300, w: 20, h: 150 },
      { x: 100, y: 460, w: 60,  h: 20 }, { x: 550, y: 420, w: 100, h: 20 },
    ],
    harbour: [
      { x: 60,  y: 80,  w: 20, h: 300 }, { x: 200, y: 150, w: 80,  h: 20 },
      { x: 380, y: 100, w: 20, h: 200 }, { x: 500, y: 200, w: 180, h: 20 },
      { x: 680, y: 100, w: 20, h: 250 }, { x: 150, y: 450, w: 200, h: 20 },
      { x: 450, y: 400, w: 20, h: 150 }, { x: 580, y: 480, w: 120, h: 20 },
    ],
  };
  return walls[mapId] || walls.downtown;
}
