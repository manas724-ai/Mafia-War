require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

const { pool }             = require('./db/pool');
const { initSocketEngine } = require('./socket/gameEngine');

const authRoutes    = require('./routes/auth');
const playerRoutes  = require('./routes/player');
const gameRoutes    = require('./routes/game');
const paymentRoutes = require('./routes/payment');
const adminRoutes   = require('./routes/admin');
const shopRoutes    = require('./routes/shop');
const { router: heistRoutes } = require('./routes/heist');

const app    = express();
const server = http.createServer(app);
const PORT   = parseInt(process.env.PORT) || 3110;
const ORIGIN = process.env.FRONTEND_URL || 'https://mafia.nexusonlinegames.com';

// ── SOCKET.IO ─────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin:      [ORIGIN, 'http://localhost:5173', 'http://localhost:3000'],
    methods:     ['GET', 'POST'],
    credentials: true,
  },
  pingTimeout:  60000,
  pingInterval: 25000,
});
initSocketEngine(io);

// ── MIDDLEWARE ────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin:      [ORIGIN, 'http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
}));

// Stripe webhook needs raw body — must come before express.json()
app.use('/api/payment/webhook', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// Global rate limit
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      300,
  message:  { error: 'Too many requests. Please slow down.' }
}));

// ── ROUTES ────────────────────────────────────────────────────
app.use('/api/auth',    authRoutes);
app.use('/api/player',  playerRoutes);
app.use('/api/game',    gameRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/admin',   adminRoutes);
app.use('/api/shop',    shopRoutes);
app.use('/api/heist',   heistRoutes);

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({
      status:  'ok',
      game:    'Mafia War',
      version: '1.0.0',
      port:    PORT,
      db:      'connected',
      ts:      new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ status: 'error', db: 'disconnected' });
  }
});

// Serve frontend in production
const frontendDist = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendDist));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found.' });
  }
  res.sendFile(path.join(frontendDist, 'index.html'));
});

// ── ERROR HANDLER ─────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[SERVER] Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── START ─────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🔫 MAFIA WAR SERVER RUNNING`);
  console.log(`   Port:    ${PORT}`);
  console.log(`   Origin:  ${ORIGIN}`);
  console.log(`   Env:     ${process.env.NODE_ENV || 'development'}`);
  console.log(`   © 2026 Aussi-Nexus Group\n`);
});

process.on('unhandledRejection', (err) => { console.error('[SERVER] Unhandled rejection:', err); });
process.on('uncaughtException',  (err) => { console.error('[SERVER] Uncaught exception:',  err); });
