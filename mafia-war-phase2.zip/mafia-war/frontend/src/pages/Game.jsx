import { useEffect, useRef, useState, useCallback } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import { createPhaserGame } from '../game/PhaserGame';

const FACTION_COLORS = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };
const HEIST_PHASES   = { breach:'🔨 Breach Entry', hack:'💻 Hack Security', secure:'🔒 Secure Perimeter', extract:'💰 Extract Loot' };

export default function Game() {
  const { code }         = useParams();
  const [params]         = useSearchParams();
  const { user }         = useAuth();
  const navigate         = useNavigate();
  const gameContainerRef = useRef(null);
  const phaserRef        = useRef(null);
  const socketRef        = useRef(null);
  const chatInputRef     = useRef(null);

  const [phase,     setPhase]     = useState('connecting');
  const [hud,       setHud]       = useState({ hp:100, ammo:15, reserve:45, kills:0, cash:0, xp:0, timeLeft:null, killStreak:0 });
  const [msgs,      setMsgs]      = useState([]);
  const [chatMsg,   setChatMsg]   = useState('');
  const [chatOpen,  setChatOpen]  = useState(false);
  const [result,    setResult]    = useState(null);
  const [error,     setError]     = useState('');
  const [countdown, setCountdown] = useState(null);
  const [deathMsg,  setDeathMsg]  = useState('');
  const [killfeed,  setKillfeed]  = useState([]);
  const [roomInfo,  setRoomInfo]  = useState(null);

  // Heist state
  const [heistPhases,     setHeistPhases]     = useState([]);
  const [heistPhasesTotal,setHeistPhasesTotal]= useState(0);
  const [heistGuards,     setHeistGuards]     = useState(0);
  const [heistResult,     setHeistResult]     = useState(null);

  // Territory
  const [territory, setTerritory] = useState({});

  // Scoreboard
  const [scoreboard, setScoreboard] = useState([]);

  const addMsg = useCallback((text, type='chat') => {
    setMsgs(prev => [...prev.slice(-30), { text, type, id: Date.now()+Math.random() }]);
  }, []);

  const addKill = useCallback((text) => {
    setKillfeed(prev => {
      const next = [...prev.slice(-4), text];
      return next;
    });
    setTimeout(() => setKillfeed(prev => prev.filter(m => m !== text)), 4000);
  }, []);

  // ── CONNECT ────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    const token  = localStorage.getItem('mw_access');
    const weapon = params.get('weapon') || 'pistol_basic';

    const s = io('/', { auth: { token }, transports: ['websocket'] });
    socketRef.current = s;

    s.on('connect', () => s.emit('join_room', { room_code: code, weapon_id: weapon }));
    s.on('connect_error', () => setError('Connection failed.'));

    s.on('room_joined', ({ room, player, players, territory: terr, guards, mode }) => {
      const info = { ...room, player, players, guards: guards||[], territory: terr||{}, mode, map_id: room.map_id };
      setRoomInfo(info);
      setPhase('waiting');
      setTerritory(terr || {});
      setHud(h => ({ ...h, hp: player.hp, ammo: player.ammo||15 }));
      if (mode === 'heist') {
        setHeistGuards((guards||[]).filter(g=>g.isAlive).length);
      }
    });

    s.on('player_joined', ({ player }) => addMsg(`${player.username} entered the war.`, 'system'));
    s.on('player_left',   ({ username }) => addMsg(`${username||'?'} left.`, 'system'));

    s.on('countdown', ({ seconds }) => { setPhase('countdown'); setCountdown(seconds); });

    s.on('match_started', ({ mode, duration }) => {
      setPhase('active'); setCountdown(null);
      setHud(h => ({ ...h, timeLeft: duration }));
    });

    s.on('player_killed', ({ killerName, killerFaction, victimName, weapon, killerId }) => {
      const feed = `${killerName} ☠ ${victimName} [${weapon}]`;
      addKill(feed);
      if (killerId === s.id) {
        setHud(h => ({ ...h, kills: h.kills+1, xp: h.xp+50, cash: h.cash+500 }));
      }
    });

    s.on('you_died', ({ killedBy, respawnIn }) => {
      setDeathMsg(`You were killed by ${killedBy}. Respawning in ${respawnIn}s...`);
      setTimeout(() => setDeathMsg(''), respawnIn*1000+500);
    });

    s.on('stats_update', (data) => {
      setHud(h => ({
        ...h,
        kills:      data.kills      ?? h.kills,
        xp:         data.xp         ?? h.xp,
        cash:       data.cash       ?? h.cash,
        ammo:       data.ammo       ?? h.ammo,
        killStreak: data.killStreak ?? h.killStreak,
      }));
    });

    s.on('reloaded', ({ ammo, reserve }) => setHud(h => ({ ...h, ammo, reserve: reserve ?? h.reserve })));
    s.on('out_of_ammo', () => addMsg('🔴 Out of ammo! Press R to reload.', 'system'));
    s.on('player_hit', ({ targetId, hp }) => { if (targetId === s.id) setHud(h => ({ ...h, hp: Math.max(0,hp) })); });
    s.on('guard_shoots', ({ targetId, targetHp }) => { if (targetId === s.id) setHud(h => ({ ...h, hp: Math.max(0,targetHp) })); });
    s.on('respawned', ({ hp, ammo }) => setHud(h => ({ ...h, hp, ammo })));
    s.on('chat', msg => addMsg(`${msg.username}: ${msg.message}`, msg.channel));
    s.on('report_sent', ({ message }) => addMsg(message, 'system'));
    s.on('error', ({ message }) => setError(message));

    // Territory
    s.on('territory_update', ({ territory: terr }) => setTerritory(terr));
    s.on('zone_captured', ({ zone, faction }) => addMsg(`🗺 ${faction.toUpperCase()} captured ${zone}!`, 'system'));

    // Heist
    s.on('guards_update', ({ guards }) => setHeistGuards((guards||[]).filter(g=>g.isAlive).length));
    s.on('guard_killed',  () => setHeistGuards(prev => Math.max(0, prev-1)));
    s.on('heist_phase_complete', ({ phasesDone, phasesTotal, playerName, action }) => {
      setHeistPhases(phasesDone);
      setHeistPhasesTotal(phasesTotal);
      addMsg(`✅ ${playerName}: ${action.toUpperCase()} complete`, 'heist');
    });
    s.on('heist_error', ({ message }) => addMsg(`⚠ ${message}`, 'system'));
    s.on('heist_loot', ({ share }) => {
      setHud(h => ({ ...h, cash: h.cash+share, xp: h.xp+400 }));
      addMsg(`💰 Loot received: $${share.toLocaleString()}`, 'heist');
    });
    s.on('heist_complete', (data) => {
      setHeistResult(data);
      addMsg(data.message, 'heist');
    });

    s.on('match_result', (data) => setResult(data));
    s.on('match_ended',  ({ scoreboard: sb }) => {
      setPhase('ended');
      setScoreboard(sb||[]);
    });

    return () => { s.disconnect(); phaserRef.current?.destroy(true); };
  }, [code, user, params, addMsg, addKill]);

  // ── INIT PHASER once room info is ready ──────────────────
  useEffect(() => {
    if (!roomInfo || !gameContainerRef.current || phaserRef.current) return;
    const s = socketRef.current;
    if (!s) return;

    phaserRef.current = createPhaserGame(
      gameContainerRef.current,
      s,
      user,
      roomInfo,
      // HUD updater
      (data) => setHud(h => ({ ...h, ...data })),
      // Event handler
      (type, data) => {
        if (type === 'kill')     addKill(`${data.killerName} ☠ [${data.weapon}]`);
        if (type === 'system')   addMsg(data.text, 'system');
        if (type === 'heist')    addMsg(data.text, 'heist');
        if (type === 'zone')     addMsg(`🗺 ${data.faction?.toUpperCase()} captured ${data.zone}!`, 'system');
        if (type === 'heist_end') setHeistResult(data);
      }
    );
  }, [roomInfo, user, addMsg, addKill]);

  // ── CHAT ─────────────────────────────────────────────────
  const sendChat = () => {
    if (!chatMsg.trim()) return;
    socketRef.current?.emit('chat_message', { message: chatMsg, channel: 'room' });
    setChatMsg('');
    setChatOpen(false);
    if (socketRef.current) socketRef.current._chatOpen = false;
  };

  const openChat = () => {
    setChatOpen(true);
    if (socketRef.current) socketRef.current._chatOpen = true;
    setTimeout(() => chatInputRef.current?.focus(), 50);
  };

  const closeChat = () => {
    setChatOpen(false);
    if (socketRef.current) socketRef.current._chatOpen = false;
    chatInputRef.current?.blur();
  };

  // Heist action handler
  const doHeistAction = (action) => socketRef.current?.emit('heist_action', { action });

  const fmtTime = (s) => s == null ? '' : `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;

  if (error) return (
    <div style={{minHeight:'100vh',background:'#0a0a0a',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16}}>
      <div style={{color:'#c0392b',fontFamily:'Bebas Neue, sans-serif',fontSize:32,letterSpacing:4}}>CONNECTION ERROR</div>
      <div style={{color:'#9a9590'}}>{error}</div>
      <button className="btn btn-primary" onClick={()=>navigate('/lobby')}>Back to Lobby</button>
    </div>
  );

  return (
    <div style={{display:'flex',height:'100vh',background:'#0a0a0a',overflow:'hidden',flexDirection:'column'}}>

      {/* TOP HUD */}
      <div style={{background:'#111',borderBottom:'1px solid #2a2a2a',padding:'8px 20px',display:'flex',alignItems:'center',gap:20,flexShrink:0,zIndex:10}}>
        <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:22,letterSpacing:4,color:'#e8e4dc'}}>MAFIA<span style={{color:'#c0392b'}}>WAR</span></div>
        <span style={{fontFamily:'Share Tech Mono, monospace',fontSize:10,letterSpacing:2,color:'#9a9590',background:'#1a1a1a',padding:'3px 8px'}}>{code}</span>
        {roomInfo && <span className={`badge badge-${roomInfo.mode==='heist'?'gold':'red'}`}>{roomInfo.mode?.toUpperCase()}</span>}

        {phase==='active' && (
          <div style={{display:'flex',gap:20,marginLeft:'auto',alignItems:'center'}}>
            {hud.timeLeft != null && (
              <div style={{textAlign:'center'}}>
                <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:9,letterSpacing:2,color:'#9a9590'}}>TIME</div>
                <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:20,color:hud.timeLeft<60?'#c0392b':'#e8e4dc'}}>{fmtTime(hud.timeLeft)}</div>
              </div>
            )}
            {[
              {label:'HP',    value:`${hud.hp}%`,          color:hud.hp>50?'#22c55e':hud.hp>25?'#f59e0b':'#c0392b'},
              {label:'AMMO',  value:`${hud.ammo}|${hud.reserve}`,color:'#e8e4dc'},
              {label:'KILLS', value:hud.kills,              color:'#c9a84c'},
              {label:'STREAK',value:hud.killStreak||0,      color:hud.killStreak>=3?'#f97316':'#9a9590'},
              {label:'CASH',  value:`$${(hud.cash||0).toLocaleString()}`,color:'#c9a84c'},
              {label:'XP',    value:(hud.xp||0).toLocaleString(),color:'#8b5cf6'},
            ].map(({label,value,color})=>(
              <div key={label} style={{textAlign:'center'}}>
                <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:9,letterSpacing:2,color:'#9a9590'}}>{label}</div>
                <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:18,color}}>{value}</div>
              </div>
            ))}
          </div>
        )}
        <button className="btn btn-ghost btn-sm" style={{marginLeft:phase!=='active'?'auto':undefined}} onClick={()=>{socketRef.current?.disconnect();navigate('/lobby');}}>Leave</button>
      </div>

      <div style={{flex:1,display:'flex',overflow:'hidden',position:'relative'}}>

        {/* PHASER GAME CONTAINER */}
        <div ref={gameContainerRef} style={{width:800,height:'100%',position:'relative',flexShrink:0,overflow:'hidden'}}/>

        {/* KILL FEED */}
        <div style={{position:'absolute',top:12,right:280,display:'flex',flexDirection:'column',gap:4,alignItems:'flex-end',pointerEvents:'none',zIndex:20}}>
          {killfeed.map((msg,i)=>(
            <div key={i} style={{background:'rgba(0,0,0,0.75)',padding:'4px 10px',fontFamily:'Share Tech Mono, monospace',fontSize:11,color:'#c0392b',borderLeft:'2px solid #8b0000',animation:'fadeIn 0.2s ease'}}>
              {msg}
            </div>
          ))}
        </div>

        {/* DEATH SCREEN */}
        {deathMsg && (
          <div style={{position:'absolute',top:'40%',left:0,width:800,textAlign:'center',pointerEvents:'none',zIndex:30}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:32,letterSpacing:4,color:'#c0392b',textShadow:'0 0 40px #8b0000',background:'rgba(0,0,0,0.6)',padding:'12px 24px',display:'inline-block'}}>{deathMsg}</div>
          </div>
        )}

        {/* WAITING OVERLAY */}
        {phase==='waiting' && (
          <div style={{position:'absolute',inset:0,width:800,background:'rgba(0,0,0,0.88)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12,zIndex:50}}>
            <div className="animate-pulse" style={{fontFamily:'Bebas Neue, sans-serif',fontSize:42,letterSpacing:6,color:'#e8e4dc'}}>WAITING FOR PLAYERS</div>
            <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:12,color:'#9a9590',letterSpacing:3}}>Room: <span style={{color:'#c9a84c'}}>{code}</span></div>
            <p style={{fontSize:13,color:'#9a9590'}}>Share the room code. Game starts when 2+ players join.</p>
            {roomInfo?.mode==='heist' && (
              <div style={{marginTop:16,textAlign:'center',maxWidth:400,background:'#161616',border:'1px solid #2a2a2a',padding:20}}>
                <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:20,letterSpacing:3,color:'#c9a84c',marginBottom:8}}>🏦 HEIST BRIEFING</div>
                <p style={{fontSize:13,color:'#9a9590',lineHeight:1.7}}>
                  Eliminate all guards → Complete phases in order → Extract the vault.<br/>
                  Loot split equally among surviving crew.
                </p>
              </div>
            )}
          </div>
        )}

        {/* COUNTDOWN */}
        {phase==='countdown' && countdown!=null && (
          <div style={{position:'absolute',top:'35%',left:0,width:800,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none',zIndex:50}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:110,color:'#c0392b',textShadow:'0 0 60px #8b0000',lineHeight:1}}>{countdown}</div>
          </div>
        )}

        {/* HEIST PHASE UI (active heist only) */}
        {phase==='active' && roomInfo?.mode==='heist' && (
          <div style={{position:'absolute',bottom:60,left:20,zIndex:20,background:'rgba(0,0,0,0.85)',border:'1px solid #2a2a2a',padding:'12px 16px',minWidth:220}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:16,letterSpacing:3,color:'#c9a84c',marginBottom:8}}>🏦 HEIST STATUS</div>
            <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:11,color:heistGuards>0?'#c0392b':'#22c55e',marginBottom:8}}>
              {heistGuards>0?`⚠ GUARDS REMAINING: ${heistGuards}`:'✅ ALL GUARDS ELIMINATED'}
            </div>
            {/* Phase progress */}
            {heistPhasesTotal>0 && (
              <div style={{marginBottom:10}}>
                <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:9,color:'#9a9590',letterSpacing:2,marginBottom:4}}>PHASES {heistPhases.length}/{heistPhasesTotal}</div>
                <div style={{background:'#222',height:6,borderRadius:2}}>
                  <div style={{background:'#c9a84c',height:6,borderRadius:2,width:`${(heistPhases.length/heistPhasesTotal)*100}%`,transition:'width 0.3s'}}/>
                </div>
              </div>
            )}
            {/* Phase buttons — show next required action */}
            <div style={{display:'flex',flexDirection:'column',gap:6}}>
              {['breach','hack','secure','extract'].map(action=>{
                const done = heistPhases.includes(action);
                return (
                  <button key={action}
                    onClick={()=>doHeistAction(action)}
                    disabled={done || (action==='hack' && heistGuards>0)}
                    style={{padding:'6px 10px',background:done?'#1a3a1a':'#1a1a1a',border:`1px solid ${done?'#22c55e':'#333'}`,color:done?'#22c55e':'#e8e4dc',fontFamily:'Share Tech Mono, monospace',fontSize:10,letterSpacing:1,textAlign:'left',cursor:done?'default':'pointer',opacity:done||(action==='hack'&&heistGuards>0)?0.5:1}}>
                    {done?'✅':' ▶'} {HEIST_PHASES[action]||action}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* TERRITORY STATUS (territory mode) */}
        {phase==='active' && roomInfo?.mode==='territory' && Object.keys(territory).length>0 && (
          <div style={{position:'absolute',bottom:60,left:20,zIndex:20,background:'rgba(0,0,0,0.85)',border:'1px solid #2a2a2a',padding:'12px 16px',minWidth:200}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:16,letterSpacing:3,color:'#e8e4dc',marginBottom:8}}>🗺 TERRITORY</div>
            {Object.entries(territory).map(([zone,z])=>(
              <div key={zone} style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
                <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:10,color:'#9a9590',width:50}}>{zone}</div>
                <div style={{flex:1,background:'#222',height:5}}>
                  {z.progress>0&&<div style={{background:FACTION_COLORS[z.capturer||z.owner]||'#555',height:5,width:`${z.progress}%`,transition:'width 0.5s'}}/>}
                </div>
                <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:9,color:FACTION_COLORS[z.owner]||'#555',width:50,textAlign:'right'}}>
                  {z.owner?z.owner.toUpperCase():'NEUTRAL'}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* HEIST RESULT OVERLAY */}
        {heistResult && (
          <div style={{position:'absolute',inset:0,width:800,background:'rgba(0,0,0,0.92)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16,zIndex:60}}>
            <div style={{fontSize:64}}>{heistResult.success?'💰':'💀'}</div>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:48,letterSpacing:6,color:heistResult.success?'#c9a84c':'#c0392b'}}>
              {heistResult.success?'HEIST COMPLETE':'HEIST FAILED'}
            </div>
            {heistResult.success && heistResult.share && (
              <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:32,color:'#e8e4dc'}}>Your cut: <span style={{color:'#c9a84c'}}>${heistResult.share.toLocaleString()}</span></div>
            )}
            <p style={{color:'#9a9590',fontSize:14}}>{heistResult.message}</p>
            <button className="btn btn-primary" onClick={()=>setHeistResult(null)}>Continue</button>
          </div>
        )}

        {/* MATCH RESULT */}
        {result && (
          <div style={{position:'absolute',inset:0,width:800,background:'rgba(0,0,0,0.93)',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16,zIndex:70}}>
            <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:56,letterSpacing:6,color:result.outcome==='win'?'#c9a84c':'#c0392b'}}>
              {result.outcome==='win'?'⚡ VICTORY':'☠ DEFEATED'}
            </div>
            {result.winningFaction && (
              <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:24,color:FACTION_COLORS[result.winningFaction]||'#e8e4dc',letterSpacing:4}}>
                {result.winningFaction.toUpperCase()} WINS THE TERRITORY
              </div>
            )}
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginTop:8}}>
              {[
                {label:'Kills',   value:result.kills},
                {label:'Deaths',  value:result.deaths},
                {label:'XP',      value:`+${result.xpEarned}`},
                {label:'Cash',    value:`+$${result.cashEarned}`},
              ].map(({label,value})=>(
                <div key={label} style={{textAlign:'center',background:'#111',padding:'14px 20px',border:'1px solid #2a2a2a'}}>
                  <div style={{fontFamily:'Share Tech Mono, monospace',fontSize:9,color:'#9a9590',marginBottom:6,letterSpacing:2}}>{label}</div>
                  <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:26,color:'#e8e4dc'}}>{value}</div>
                </div>
              ))}
            </div>
            {result.rankedUp && (
              <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:22,color:'#c9a84c',letterSpacing:4}}>🏆 RANK UP — {result.rankTitle}</div>
            )}

            {/* Scoreboard */}
            {scoreboard.length>0 && (
              <div style={{marginTop:8,maxWidth:500,width:'100%'}}>
                <div style={{fontFamily:'Bebas Neue, sans-serif',fontSize:18,letterSpacing:3,color:'#9a9590',marginBottom:8,textAlign:'center'}}>SCOREBOARD</div>
                {scoreboard.sort((a,b)=>b.kills-a.kills).slice(0,6).map((p,i)=>(
                  <div key={p.socketId} style={{display:'flex',justifyContent:'space-between',padding:'6px 12px',background:i%2===0?'#111':'transparent',fontSize:13}}>
                    <span style={{color:FACTION_COLORS[p.faction]||'#9a9590'}}>{p.username}</span>
                    <span style={{fontFamily:'Share Tech Mono, monospace',fontSize:11,color:'#9a9590'}}>{p.kills}K / {p.deaths}D</span>
                  </div>
                ))}
              </div>
            )}

            <div style={{display:'flex',gap:12,marginTop:8}}>
              <button className="btn btn-primary" onClick={()=>navigate('/lobby')}>Back to Lobby</button>
              <button className="btn btn-secondary" onClick={()=>window.location.reload()}>Play Again</button>
            </div>
          </div>
        )}

        {/* CHAT SIDEBAR */}
        <div style={{flex:1,background:'#111',borderLeft:'1px solid #2a2a2a',display:'flex',flexDirection:'column',minWidth:220,maxWidth:240}}>
          <div style={{padding:'8px 12px',borderBottom:'1px solid #2a2a2a',fontFamily:'Share Tech Mono, monospace',fontSize:10,letterSpacing:2,color:'#9a9590'}}>COMMS</div>
          <div style={{flex:1,overflow:'auto',padding:'8px 12px',display:'flex',flexDirection:'column',gap:4}}>
            {msgs.map(m=>(
              <div key={m.id} style={{fontSize:12,lineHeight:1.4,color:m.type==='system'?'#c9a84c':m.type==='heist'?'#8b5cf6':m.type==='faction'?'#60a5fa':'#e8e4dc',fontStyle:m.type==='system'||m.type==='heist'?'italic':'normal'}}>
                {m.text}
              </div>
            ))}
          </div>
          <div style={{padding:'8px 12px',borderTop:'1px solid #2a2a2a',display:'flex',gap:8}}>
            <input ref={chatInputRef} className="input" value={chatMsg} placeholder="Enter to chat..."
              style={{flex:1,fontSize:12,padding:'6px 10px'}}
              onChange={e=>setChatMsg(e.target.value)}
              onFocus={openChat}
              onBlur={()=>{if(!chatMsg) closeChat();}}
              onKeyDown={e=>{if(e.key==='Enter'){sendChat();}if(e.key==='Escape'){setChatMsg('');closeChat();}}}
            />
            <button className="btn btn-primary btn-sm" onClick={sendChat}>→</button>
          </div>
          <div style={{padding:'8px 12px',borderTop:'1px solid #1a1a1a',fontFamily:'Share Tech Mono, monospace',fontSize:9,color:'#333',lineHeight:1.8}}>
            WASD: Move · Click: Shoot<br/>
            R: Reload · Enter: Chat<br/>
            {roomInfo?.mode==='heist'&&'Heist buttons: bottom-left'}
          </div>
        </div>
      </div>
    </div>
  );
}
