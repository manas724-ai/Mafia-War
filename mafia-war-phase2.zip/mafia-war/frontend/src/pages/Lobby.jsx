import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, API } from '../context/AuthContext';

const WEAPON_TYPE_ICONS = { pistol:'🔫', smg:'⚡', shotgun:'💥', rifle:'🎯', sniper:'🔭', explosive:'💣', special:'🚀', melee:'🗡️' };

const FACTIONS = {
  ghost:  { label: 'Ghost Syndicate', color: '#9ca3af', desc: 'Stealth and assassination specialists' },
  viper:  { label: 'Viper Cartel',    color: '#c9a84c', desc: 'Money, drugs, and street control'     },
  iron:   { label: 'Iron Brotherhood',color: '#60a5fa', desc: 'Brute force and territory domination' },
  shadow: { label: 'Shadow Council',  color: '#8b0000', desc: 'Political power through fear'         },
};

const MODES = [
  { id: 'deathmatch', label: 'Deathmatch',    icon: '💀', desc: 'Free-for-all kill count' },
  { id: 'team',       label: 'Team War',       icon: '⚔️',  desc: 'Faction vs faction'       },
  { id: 'heist',      label: 'Bank Heist',     icon: '🏦', desc: 'Co-op vault break'        },
  { id: 'territory',  label: 'Territory',      icon: '🗺️', desc: 'Hold zones to win'        },
];

export default function Lobby() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [rooms,  setRooms]  = useState([]);
  const [maps,   setMaps]   = useState([]);
  const [lb,     setLb]     = useState([]);
  const [tab,    setTab]    = useState('rooms'); // rooms | create | leaderboard | profile
  const [create, setCreate] = useState({ name: '', map_id: 'downtown', mode: 'deathmatch', max_players: 20 });
  const [joinCode, setJoinCode]   = useState('');
  const [selWeapon,setSelWeapon]  = useState('pistol_basic');
  const [weapons,  setWeapons]    = useState([]);
  const [shopItems,setShopItems]  = useState([]);
  const [shopCash, setShopCash]   = useState(0);
  const [shopMsg,  setShopMsg]    = useState('');
  const [factionStandings, setFactionStandings] = useState([]);
  const [error,    setError]      = useState('');
  const [loading,  setLoading]    = useState(false);
  const [factionModal, setFactionModal] = useState(!user?.faction);

  const loadRooms = useCallback(async () => {
    try {
      const { data } = await API.get('/game/rooms');
      setRooms(data.rooms);
    } catch {}
  }, []);

  useEffect(() => {
    loadRooms();
    const t = setInterval(loadRooms, 5000);
    return () => clearInterval(t);
  }, [loadRooms]);

  useEffect(() => {
    API.get('/player/maps').then(r => setMaps(r.data.maps)).catch(() => {});
    API.get('/player/weapons').then(r => setWeapons(r.data.weapons)).catch(() => {});
    API.get('/player/leaderboard?by=total_kills&limit=20').then(r => setLb(r.data.leaderboard)).catch(() => {});
    API.get('/shop/weapons').then(r => { setShopItems(r.data.weapons); setShopCash(r.data.cash); }).catch(() => {});
    API.get('/shop/faction').then(r => setFactionStandings(r.data.standings)).catch(() => {});
  }, []);

  const chooseFaction = async (faction) => {
    try {
      await API.post('/player/faction', { faction });
      setFactionModal(false);
      window.location.reload();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to set faction.');
    }
  };

  const joinRoom = async (code, weaponId) => {
    if (!user?.faction) return setFactionModal(true);
    navigate(`/game/${code}?weapon=${weaponId || selWeapon}`);
  };

  const createRoom = async () => {
    if (!create.name) return setError('Room name required.');
    setLoading(true); setError('');
    try {
      const { data } = await API.post('/game/rooms', create);
      navigate(`/game/${data.room.room_code}?weapon=${selWeapon}`);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create room.');
    } finally {
      setLoading(false);
    }
  };

  const rankColor = (r) => r >= 13 ? '#c9a84c' : r >= 9 ? '#c0392b' : r >= 5 ? '#60a5fa' : '#9a9590';

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0a', display: 'flex', flexDirection: 'column' }}>

      {/* FACTION MODAL */}
      {factionModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.9)', zIndex: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
          <div style={{ background: '#111', border: '1px solid #2a2a2a', padding: 40, maxWidth: 520, width: '100%' }}>
            <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 36, letterSpacing: 4, color: '#e8e4dc', marginBottom: 8 }}>Choose Your Faction</div>
            <p style={{ color: '#9a9590', marginBottom: 28, fontSize: 14 }}>This is permanent. Choose wisely — your faction determines your allies and enemies.</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {Object.entries(FACTIONS).map(([key, f]) => (
                <button key={key} onClick={() => chooseFaction(key)} style={{
                  background: '#161616', border: `1px solid ${f.color}40`,
                  padding: '20px 16px', textAlign: 'left', cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
                  onMouseOver={e => e.currentTarget.style.background = '#1f1f1f'}
                  onMouseOut={e => e.currentTarget.style.background = '#161616'}
                >
                  <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 20, color: f.color, letterSpacing: 2, marginBottom: 6 }}>{f.label}</div>
                  <div style={{ fontSize: 12, color: '#9a9590' }}>{f.desc}</div>
                </button>
              ))}
            </div>
            {error && <div className="error-msg" style={{ marginTop: 12 }}>{error}</div>}
          </div>
        </div>
      )}

      {/* TOP NAV */}
      <nav style={{ background: '#111', borderBottom: '1px solid #2a2a2a', padding: '12px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 28, letterSpacing: 4, color: '#e8e4dc' }}>
          MAFIA<span style={{ color: '#c0392b' }}>WAR</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          {user && (
            <>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 16, letterSpacing: 2, color: FACTIONS[user.faction]?.color || '#9a9590' }}>
                  {user.username}
                </div>
                <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: '#9a9590', letterSpacing: 1 }}>
                  Rank {user.rank_level} · ${user.cash?.toLocaleString()}
                </div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={logout}>Logout</button>
            </>
          )}
        </div>
      </nav>

      {/* TABS */}
      <div style={{ background: '#111', borderBottom: '1px solid #2a2a2a', display: 'flex', padding: '0 24px' }}>
        {[
          { key: 'rooms',       label: '🔴 Rooms'       },
          { key: 'create',      label: '⚔️  Create'      },
          { key: 'shop',        label: '🔫 Arsenal'      },
          { key: 'leaderboard', label: '🏆 Rankings'    },
          { key: 'factions',    label: '⚜️  Factions'    },
          { key: 'profile',     label: '👤 Profile'      },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{
            padding: '14px 20px', background: 'none', color: tab === t.key ? '#e8e4dc' : '#9a9590',
            borderBottom: tab === t.key ? '2px solid #8b0000' : '2px solid transparent',
            fontFamily: 'Share Tech Mono, monospace', fontSize: 12, letterSpacing: 1,
            transition: 'color 0.2s',
          }}>
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, padding: '32px 24px', maxWidth: 1000, margin: '0 auto', width: '100%' }}>

        {/* ── ROOMS TAB ── */}
        {tab === 'rooms' && (
          <div className="animate-fadeIn">
            <div style={{ display: 'flex', gap: 12, marginBottom: 24, alignItems: 'center' }}>
              <input className="input" placeholder="Join by room code..." value={joinCode}
                onChange={e => setJoinCode(e.target.value.toUpperCase())}
                style={{ maxWidth: 200, fontFamily: 'Share Tech Mono, monospace', letterSpacing: 2 }}
              />
              <button className="btn btn-primary" onClick={() => joinRoom(joinCode)}
                disabled={!joinCode || joinCode.length < 6}>
                Join Room
              </button>
              <button className="btn btn-ghost btn-sm" onClick={loadRooms} style={{ marginLeft: 'auto' }}>Refresh</button>
            </div>

            {rooms.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 0', color: '#9a9590' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🌆</div>
                <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 24, letterSpacing: 3, marginBottom: 8 }}>The Streets are Quiet</div>
                <p style={{ fontSize: 14 }}>No open rooms. Be the first to start a war.</p>
                <button className="btn btn-primary" style={{ marginTop: 20 }} onClick={() => setTab('create')}>Create Room</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {rooms.map(r => (
                  <div key={r.id} style={{
                    background: '#111', border: '1px solid #2a2a2a', padding: '16px 20px',
                    display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap',
                  }}>
                    <div style={{ flex: 1, minWidth: 160 }}>
                      <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 20, letterSpacing: 2, color: '#e8e4dc' }}>{r.name}</div>
                      <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 10, color: '#9a9590', letterSpacing: 1, marginTop: 2 }}>
                        {r.map_id.toUpperCase()} · {r.mode.toUpperCase()} · {r.room_code}
                      </div>
                    </div>
                    <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 18, color: r.current_players >= r.max_players ? '#c0392b' : '#22c55e' }}>
                      {r.current_players}/{r.max_players}
                    </div>
                    <span className={`badge badge-${r.status === 'waiting' ? 'green' : 'red'}`}>{r.status}</span>
                    <button className="btn btn-primary btn-sm"
                      disabled={r.status !== 'waiting' || r.current_players >= r.max_players}
                      onClick={() => joinRoom(r.room_code)}>
                      Join
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── CREATE TAB ── */}
        {tab === 'create' && (
          <div className="animate-fadeIn" style={{ maxWidth: 540 }}>
            <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 32, letterSpacing: 4, color: '#e8e4dc', marginBottom: 24 }}>Create a Room</div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <label className="label">Room Name</label>
                <input className="input" placeholder="Blackout Alley..." value={create.name}
                  onChange={e => setCreate(p => ({ ...p, name: e.target.value }))} />
              </div>

              <div>
                <label className="label">Game Mode</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  {MODES.map(m => (
                    <button key={m.id} onClick={() => setCreate(p => ({ ...p, mode: m.id }))} style={{
                      padding: '12px 14px', background: create.mode === m.id ? '#1a0000' : '#161616',
                      border: `1px solid ${create.mode === m.id ? '#8b0000' : '#2a2a2a'}`,
                      textAlign: 'left', cursor: 'pointer', transition: 'all 0.2s',
                    }}>
                      <div style={{ fontSize: 18, marginBottom: 4 }}>{m.icon}</div>
                      <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 16, letterSpacing: 2, color: '#e8e4dc' }}>{m.label}</div>
                      <div style={{ fontSize: 11, color: '#9a9590', marginTop: 2 }}>{m.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Map</label>
                <select className="input" value={create.map_id}
                  onChange={e => setCreate(p => ({ ...p, map_id: e.target.value }))} style={{ background: '#161616' }}>
                  {maps.map(m => <option key={m.map_id} value={m.map_id}>{m.name}</option>)}
                </select>
              </div>

              <div>
                <label className="label">Max Players</label>
                <select className="input" value={create.max_players}
                  onChange={e => setCreate(p => ({ ...p, max_players: parseInt(e.target.value) }))} style={{ background: '#161616' }}>
                  {[4,8,12,16,20,30].map(n => <option key={n} value={n}>{n} Players</option>)}
                </select>
              </div>

              <div>
                <label className="label">Starting Weapon</label>
                <select className="input" value={selWeapon} onChange={e => setSelWeapon(e.target.value)} style={{ background: '#161616' }}>
                  {weapons.map(w => <option key={w.weapon_id} value={w.weapon_id}>{w.weapon_name} ({w.weapon_type})</option>)}
                </select>
              </div>

              {error && <div className="error-msg">{error}</div>}

              <button className="btn btn-primary btn-full" onClick={createRoom} disabled={loading}>
                {loading ? 'Creating...' : '⚔️ Start the War'}
              </button>
            </div>
          </div>
        )}

        {/* ── SHOP TAB ── */}
        {tab === 'shop' && (
          <div className="animate-fadeIn">
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginBottom:24 }}>
              <div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:4, color:'#e8e4dc' }}>Arsenal</div>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:11, color:'#9a9590', letterSpacing:2 }}>Buy weapons with in-game cash</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:2 }}>YOUR CASH</div>
                <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:28, color:'#c9a84c' }}>${shopCash.toLocaleString()}</div>
              </div>
            </div>
            {shopMsg && <div className={shopMsg.startsWith('✅')?'success-msg':'error-msg'} style={{ marginBottom:16 }}>{shopMsg}</div>}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))', gap:8 }}>
              {shopItems.map(w => (
                <div key={w.weapon_id} style={{
                  background: w.owned?'#0f1a0f':'#111', border:`1px solid ${w.owned?'#1a3a1a':w.locked?'#1a1a1a':'#2a2a2a'}`,
                  padding:'18px 16px', opacity: w.locked?0.5:1,
                }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
                    <div>
                      <div style={{ fontSize:22 }}>{WEAPON_TYPE_ICONS[w.weapon_type]}</div>
                      <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:20, letterSpacing:2, color:'#e8e4dc', marginTop:4 }}>{w.weapon_name}</div>
                      <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:9, color:'#9a9590', letterSpacing:1, textTransform:'uppercase' }}>{w.weapon_type}</div>
                    </div>
                    {w.owned && <span className="badge badge-green">OWNED</span>}
                    {w.locked && !w.owned && <span className="badge badge-muted">RANK {w.unlock_rank}+</span>}
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:12 }}>
                    {[['DMG',w.damage],['RATE',w.firerate+'ms'],['AMMO',w.ammo]].map(([l,v])=>(
                      <div key={l} style={{ textAlign:'center', background:'#0a0a0a', padding:'6px 4px' }}>
                        <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:8, color:'#9a9590', letterSpacing:1 }}>{l}</div>
                        <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:16, color:'#e8e4dc' }}>{v}</div>
                      </div>
                    ))}
                  </div>
                  <p style={{ fontSize:12, color:'#9a9590', marginBottom:12, lineHeight:1.5 }}>{w.description}</p>
                  {w.owned ? (
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#22c55e', letterSpacing:2 }}>✅ In your arsenal</div>
                  ) : w.locked ? (
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590', letterSpacing:1 }}>🔒 Requires Rank {w.unlock_rank}</div>
                  ) : w.price_cash === 0 ? (
                    <div style={{ fontFamily:'Share Tech Mono, monospace', fontSize:10, color:'#9a9590' }}>Standard issue — check inventory</div>
                  ) : (
                    <button className="btn btn-primary btn-sm" disabled={!w.can_buy}
                      onClick={async () => {
                        setShopMsg('');
                        try {
                          const { data } = await API.post('/shop/buy', { weapon_id: w.weapon_id });
                          setShopMsg(`✅ ${w.weapon_name} acquired! Cash left: $${data.cash_left.toLocaleString()}`);
                          setShopCash(data.cash_left);
                          setShopItems(prev => prev.map(s => s.weapon_id===w.weapon_id?{...s,owned:true,can_buy:false}:s));
                          setWeapons(prev => [...prev, { weapon_id:w.weapon_id, weapon_name:w.weapon_name }]);
                        } catch(err) { setShopMsg(err.response?.data?.error||'Purchase failed.'); }
                      }}
                      style={{ width:'100%' }}>
                      💰 Buy — ${w.price_cash.toLocaleString()}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── FACTIONS TAB ── */}
        {tab === 'factions' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:4, color:'#e8e4dc', marginBottom:24 }}>Faction War</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:8, marginBottom:32 }}>
              {factionStandings.map((f,i) => {
                const colors = { ghost:'#9ca3af', viper:'#c9a84c', iron:'#60a5fa', shadow:'#8b0000' };
                const col = colors[f.faction]||'#9a9590';
                return (
                  <div key={f.faction} style={{ background:'#111', border:`1px solid ${col}33`, padding:'24px 20px', position:'relative' }}>
                    {i===0&&<div style={{ position:'absolute', top:12, right:12, fontSize:20 }}>👑</div>}
                    <div style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:26, letterSpacing:3, color:col, marginBottom:4 }}>{f.faction?.toUpperCase()}</div>
                    <div style={{ display:'flex', flexDirection:'column', gap:8, marginTop:12 }}>
                      {[['Members',f.total_members],['Total Kills',(f.total_kills||0).toLocaleString()],['Avg Rank',parseFloat(f.avg_rank||0).toFixed(1)],['Heists',f.total_heists||0]].map(([l,v])=>(
                        <div key={l} style={{ display:'flex', justifyContent:'space-between', fontSize:13 }}>
                          <span style={{ color:'#9a9590', fontFamily:'Share Tech Mono, monospace', fontSize:10, letterSpacing:1 }}>{l}</span>
                          <span style={{ color:'#e8e4dc', fontFamily:'Bebas Neue, sans-serif', fontSize:16, letterSpacing:1 }}>{v}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── LEADERBOARD TAB ── */}
        {tab === 'leaderboard' && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 32, letterSpacing: 4, color: '#e8e4dc', marginBottom: 24 }}>Top Criminals</div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #2a2a2a' }}>
                  {['#','Player','Faction','Rank','Kills','K/D','Heists'].map(h => (
                    <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontFamily: 'Share Tech Mono, monospace', fontSize: 10, letterSpacing: 2, color: '#9a9590' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lb.map((p, i) => (
                  <tr key={p.user_id} style={{ borderBottom: '1px solid #1a1a1a', background: i % 2 === 0 ? 'transparent' : '#111' }}>
                    <td style={{ padding: '10px 12px', fontFamily: 'Bebas Neue, sans-serif', fontSize: 18, color: i < 3 ? '#c9a84c' : '#9a9590' }}>{i + 1}</td>
                    <td style={{ padding: '10px 12px', color: '#e8e4dc', fontWeight: 500 }}>{p.username}</td>
                    <td style={{ padding: '10px 12px', color: FACTIONS[p.faction]?.color || '#9a9590', fontSize: 12 }}>
                      {FACTIONS[p.faction]?.label || '—'}
                    </td>
                    <td style={{ padding: '10px 12px', color: rankColor(p.rank_level), fontFamily: 'Bebas Neue, sans-serif', letterSpacing: 1 }}>
                      {p.rank_title}
                    </td>
                    <td style={{ padding: '10px 12px', color: '#e8e4dc' }}>{p.total_kills?.toLocaleString()}</td>
                    <td style={{ padding: '10px 12px', color: '#9a9590' }}>{p.kd_ratio}</td>
                    <td style={{ padding: '10px 12px', color: '#9a9590' }}>{p.heists_won}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* ── PROFILE TAB ── */}
        {tab === 'profile' && user && (
          <div className="animate-fadeIn">
            <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 32, letterSpacing: 4, color: '#e8e4dc', marginBottom: 24 }}>Your Profile</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              {[
                { label: 'Username',    value: user.username },
                { label: 'Faction',     value: FACTIONS[user.faction]?.label || 'None' },
                { label: 'Rank',        value: `${user.rank_level} — ${user.rank_title || ''}` },
                { label: 'XP',          value: user.xp?.toLocaleString() },
                { label: 'Kills',       value: user.kills?.toLocaleString() },
                { label: 'Deaths',      value: user.deaths?.toLocaleString() },
                { label: 'K/D Ratio',   value: user.deaths > 0 ? (user.kills / user.deaths).toFixed(2) : user.kills },
                { label: 'Cash',        value: `$${user.cash?.toLocaleString()}` },
                { label: 'Heists Won',  value: user.heists_won },
                { label: 'Subscription',value: user.subscription_status },
              ].map(({ label, value }) => (
                <div key={label} style={{ background: '#111', border: '1px solid #2a2a2a', padding: '16px 20px' }}>
                  <div style={{ fontFamily: 'Share Tech Mono, monospace', fontSize: 10, letterSpacing: 2, color: '#9a9590', marginBottom: 6, textTransform: 'uppercase' }}>{label}</div>
                  <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 22, letterSpacing: 2, color: '#e8e4dc' }}>{value}</div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 24 }}>
              <div style={{ fontFamily: 'Bebas Neue, sans-serif', fontSize: 20, letterSpacing: 3, color: '#c9a84c', marginBottom: 12 }}>Upgrade to Premium</div>
              <button className="btn btn-primary" onClick={async () => {
                const { data } = await API.post('/payment/subscribe', { plan: 'premium' });
                window.location.href = data.url;
              }}>
                💰 Subscribe — Premium Access
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
