#!/bin/bash
# ================================================================
# MAFIA WAR v4.0 — Complete VPS Deployment Script
# © 2026 Aussi-Nexus Group (ABN 76 947 108 181)
# Covers all phases 1–4
# ================================================================
set -e

APP_DIR="/var/www/mafia-war"
PORT=3110
PM2_NAME="mafia-war"
DOMAIN="mafia.nexusonlinegames.com"

echo ""
echo "🔫 MAFIA WAR v4.0 DEPLOYMENT"
echo "=============================="

# ── 1. DIRECTORIES ───────────────────────────────────────────
echo "[1/8] Setting up directories..."
mkdir -p "$APP_DIR/backend/src"
mkdir -p "$APP_DIR/frontend/dist"

# ── 2. UPLOAD REMINDER ───────────────────────────────────────
echo "[2/8] Upload your files via FileZilla (right-click → Upload):"
echo "   Local: backend/        → Remote: $APP_DIR/backend/"
echo "   Local: frontend/dist/  → Remote: $APP_DIR/frontend/dist/"
echo ""
echo "Press ENTER when files are uploaded..."
read -r

# ── 3. BACKEND DEPS ──────────────────────────────────────────
echo "[3/8] Installing backend dependencies..."
cd "$APP_DIR/backend"
npm install --production

# ── 4. DATABASE SETUP ────────────────────────────────────────
echo "[4/8] Setting up MySQL database..."
echo -n "MySQL root password: "
read -rs MYSQL_ROOT_PASS
echo ""

mysql -u root -p"$MYSQL_ROOT_PASS" << SQLEOF
CREATE DATABASE IF NOT EXISTS mafia_war CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'mafia_war_user'@'localhost' IDENTIFIED BY 'MafiaWar2026Secure!';
GRANT ALL PRIVILEGES ON mafia_war.* TO 'mafia_war_user'@'localhost';
FLUSH PRIVILEGES;
SQLEOF

mysql -u root -p"$MYSQL_ROOT_PASS" mafia_war < "$APP_DIR/backend/src/db/schema.sql"
echo "Database ready."

# ── 5. ENV FILE ──────────────────────────────────────────────
if [ ! -f "$APP_DIR/backend/.env" ]; then
  echo "[5/8] Creating .env file..."
  echo -n "Stripe Secret Key (sk_live_...): "; read -rs STRIPE_SK; echo ""
  echo -n "Stripe Webhook Secret (whsec_...): "; read -rs STRIPE_WH; echo ""
  echo -n "Stripe Premium Price ID (price_...): "; read -rs STRIPE_PRICE; echo ""

  cat > "$APP_DIR/backend/.env" << ENVEOF
PORT=$PORT
NODE_ENV=production
DB_HOST=localhost
DB_PORT=3306
DB_NAME=mafia_war
DB_USER=mafia_war_user
DB_PASS=MafiaWar2026Secure!
JWT_SECRET=$(openssl rand -hex 32)
STRIPE_SECRET_KEY=$STRIPE_SK
STRIPE_WEBHOOK_SECRET=$STRIPE_WH
STRIPE_PREMIUM_PRICE_ID=$STRIPE_PRICE
FRONTEND_URL=https://$DOMAIN
ADMIN_EMAIL=admin@nexusonlinegames.com
ENVEOF
  echo ".env created."
else
  echo "[5/8] .env already exists — skipping."
fi

# ── 6. PM2 ───────────────────────────────────────────────────
echo "[6/8] Starting with PM2..."
pm2 delete "$PM2_NAME" 2>/dev/null || true
pm2 start "$APP_DIR/backend/src/server.js" \
  --name "$PM2_NAME" \
  --env production \
  --max-memory-restart 512M \
  --restart-delay 3000 \
  --log "$APP_DIR/backend/logs/app.log" \
  --error "$APP_DIR/backend/logs/error.log" \
  --time
pm2 save
mkdir -p "$APP_DIR/backend/logs"
echo "PM2 started."

# ── 7. NGINX ─────────────────────────────────────────────────
echo "[7/8] Configuring Nginx..."
cat > "/etc/nginx/sites-available/$DOMAIN" << NGINXEOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;

    # WebSocket support for Socket.io
    location /socket.io/ {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400s;
    }

    # Stripe webhook — needs raw body
    location /api/payment/webhook {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_read_timeout 30s;
    }

    # API and frontend
    location / {
        proxy_pass http://127.0.0.1:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 60s;
        proxy_connect_timeout 10s;
        client_max_body_size 2M;
    }
}
NGINXEOF

ln -sf "/etc/nginx/sites-available/$DOMAIN" "/etc/nginx/sites-enabled/$DOMAIN"
nginx -t && systemctl reload nginx
echo "Nginx configured."

# ── 8. SSL ───────────────────────────────────────────────────
echo "[8/8] Setting up SSL..."
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
  -m admin@nexusonlinegames.com --redirect 2>/dev/null && echo "SSL OK." || echo "SSL: run certbot manually if this fails."

# ── CRON JOBS ────────────────────────────────────────────────
echo "Setting up cron jobs..."
# Weekly leaderboard reset — every Monday 2am AEST
CRON_CMD="0 2 * * 1 curl -s -X POST https://$DOMAIN/api/season-admin/weekly-reset -H 'x-owner-bypass: manas724' >> /var/log/mafia-war-cron.log 2>&1"
(crontab -l 2>/dev/null | grep -v 'mafia-war'; echo "$CRON_CMD") | crontab -
echo "Cron configured."

echo ""
echo "✅ MAFIA WAR v4.0 DEPLOYED"
echo "   URL:     https://$DOMAIN"
echo "   API:     https://$DOMAIN/api/health"
echo "   Admin:   https://$DOMAIN/admin"
echo "   Monitor: https://$DOMAIN/admin (Health tab)"
echo "   PM2:     pm2 status"
echo "   Logs:    pm2 logs mafia-war"
echo ""
echo "NEXT STEPS:"
echo "  1. Visit https://$DOMAIN and verify age gate"
echo "  2. Register admin account"
echo "  3. In MySQL: UPDATE users SET role='owner' WHERE email='your@email.com';"
echo "  4. Visit /admin and check Dashboard tab"
echo "  5. Set up Stripe webhook endpoint: https://$DOMAIN/api/payment/webhook"
echo ""
