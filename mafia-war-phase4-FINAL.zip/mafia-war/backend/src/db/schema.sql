-- ================================================================
-- MAFIA WAR — Database Schema
-- © 2026 Aussi-Nexus Group (ABN 76 947 108 181)
-- ================================================================

CREATE DATABASE IF NOT EXISTS mafia_war CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mafia_war;

-- ── USERS ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  uuid          VARCHAR(36) NOT NULL UNIQUE,
  username      VARCHAR(30) NOT NULL UNIQUE,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('player','premium','admin','owner') DEFAULT 'player',
  faction       ENUM('ghost','viper','iron','shadow') DEFAULT NULL,
  rank_level    INT DEFAULT 1,
  xp            INT DEFAULT 0,
  kills         INT DEFAULT 0,
  deaths        INT DEFAULT 0,
  heists_won    INT DEFAULT 0,
  cash          BIGINT DEFAULT 1000,
  age_verified  TINYINT(1) DEFAULT 0,
  is_banned     TINYINT(1) DEFAULT 0,
  ban_reason    TEXT DEFAULT NULL,
  stripe_customer_id VARCHAR(255) DEFAULT NULL,
  subscription_status ENUM('none','active','cancelled','past_due') DEFAULT 'none',
  subscription_id VARCHAR(255) DEFAULT NULL,
  last_login    DATETIME DEFAULT NULL,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_username (username),
  INDEX idx_faction (faction),
  INDEX idx_rank (rank_level DESC)
);

-- ── SESSIONS (JWT refresh tokens) ────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  token_hash VARCHAR(255) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_token (token_hash)
);

-- ── GAME ROOMS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS game_rooms (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  room_code   VARCHAR(8) NOT NULL UNIQUE,
  name        VARCHAR(100) NOT NULL,
  map_id      VARCHAR(50) NOT NULL DEFAULT 'downtown',
  mode        ENUM('deathmatch','team','heist','territory') DEFAULT 'deathmatch',
  status      ENUM('waiting','active','ended') DEFAULT 'waiting',
  max_players INT DEFAULT 20,
  current_players INT DEFAULT 0,
  host_id     INT,
  winner_faction VARCHAR(50) DEFAULT NULL,
  started_at  DATETIME DEFAULT NULL,
  ended_at    DATETIME DEFAULT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_code (room_code)
);

-- ── MATCH HISTORY ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS match_history (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  room_id     INT NOT NULL,
  user_id     INT NOT NULL,
  kills       INT DEFAULT 0,
  deaths      INT DEFAULT 0,
  assists     INT DEFAULT 0,
  xp_earned   INT DEFAULT 0,
  cash_earned INT DEFAULT 0,
  outcome     ENUM('win','loss','draw') DEFAULT 'draw',
  played_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_room (room_id)
);

-- ── HEIST MISSIONS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS heist_missions (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  room_id      INT NOT NULL,
  bank_id      VARCHAR(50) NOT NULL,
  status       ENUM('planning','active','success','failed') DEFAULT 'planning',
  vault_amount BIGINT DEFAULT 0,
  time_limit   INT DEFAULT 300,
  started_at   DATETIME DEFAULT NULL,
  completed_at DATETIME DEFAULT NULL,
  FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE
);

-- ── HEIST PARTICIPANTS ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS heist_participants (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  heist_id   INT NOT NULL,
  user_id    INT NOT NULL,
  role       ENUM('breacher','shooter','driver','hacker') DEFAULT 'shooter',
  loot_share BIGINT DEFAULT 0,
  FOREIGN KEY (heist_id) REFERENCES heist_missions(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── WEAPONS INVENTORY ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS weapons_inventory (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  weapon_id   VARCHAR(50) NOT NULL,
  weapon_name VARCHAR(100) NOT NULL,
  weapon_type ENUM('pistol','smg','shotgun','rifle','sniper','explosive','melee','special') NOT NULL,
  ammo        INT DEFAULT 0,
  acquired_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_weapon (user_id, weapon_id),
  INDEX idx_user (user_id)
);

-- ── LEADERBOARD (materialised) ────────────────────────────────
CREATE TABLE IF NOT EXISTS leaderboard (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL UNIQUE,
  username   VARCHAR(30) NOT NULL,
  faction    VARCHAR(20),
  rank_level INT DEFAULT 1,
  total_kills INT DEFAULT 0,
  kd_ratio   DECIMAL(5,2) DEFAULT 0.00,
  heists_won INT DEFAULT 0,
  total_cash BIGINT DEFAULT 0,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_kills (total_kills DESC),
  INDEX idx_kd (kd_ratio DESC)
);

-- ── PAYMENTS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  user_id             INT NOT NULL,
  stripe_payment_id   VARCHAR(255) NOT NULL UNIQUE,
  stripe_session_id   VARCHAR(255),
  amount              INT NOT NULL,
  currency            VARCHAR(3) DEFAULT 'aud',
  type                ENUM('subscription','one_time','in_game') DEFAULT 'subscription',
  status              ENUM('pending','succeeded','failed','refunded') DEFAULT 'pending',
  description         TEXT,
  created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_status (status)
);

-- ── REPORTS / MODERATION ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS player_reports (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  reporter_id INT NOT NULL,
  reported_id INT NOT NULL,
  reason      ENUM('cheating','harassment','inappropriate','other') NOT NULL,
  description TEXT,
  status      ENUM('open','reviewed','resolved') DEFAULT 'open',
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (reported_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── CHAT LOG ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chat_log (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  room_id    INT,
  user_id    INT NOT NULL,
  message    TEXT NOT NULL,
  channel    ENUM('global','room','faction','system') DEFAULT 'room',
  sent_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_room (room_id),
  INDEX idx_sent (sent_at)
);

-- ── RANK DEFINITIONS ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rank_definitions (
  level        INT PRIMARY KEY,
  title        VARCHAR(50) NOT NULL,
  xp_required  INT NOT NULL,
  cash_reward  INT DEFAULT 0,
  unlock_weapon VARCHAR(50) DEFAULT NULL
);

INSERT IGNORE INTO rank_definitions (level, title, xp_required, cash_reward, unlock_weapon) VALUES
(1,  'Street Rat',      0,      500,   'pistol_basic'),
(2,  'Thug',            500,    1000,  NULL),
(3,  'Runner',          1500,   1500,  'smg_micro'),
(4,  'Enforcer',        3500,   2000,  NULL),
(5,  'Soldier',         7000,   3000,  'shotgun_pump'),
(6,  'Made Man',        13000,  4000,  NULL),
(7,  'Lieutenant',      22000,  5000,  'rifle_ak'),
(8,  'Capo',            35000,  7500,  NULL),
(9,  'Underboss',       55000,  10000, 'sniper_basic'),
(10, 'Consigliere',     80000,  15000, NULL),
(11, 'Boss',            115000, 20000, 'explosive_grenade'),
(12, 'Don',             160000, 30000, NULL),
(13, 'Crime Lord',      220000, 40000, 'special_minigun'),
(14, 'Kingpin',         300000, 60000, NULL),
(15, 'Godfather',       420000, 100000,'special_rocket');

-- ── MAP DEFINITIONS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS map_definitions (
  map_id       VARCHAR(50) PRIMARY KEY,
  name         VARCHAR(100) NOT NULL,
  description  TEXT,
  max_players  INT DEFAULT 20,
  modes        VARCHAR(255) DEFAULT 'deathmatch,team',
  unlock_rank  INT DEFAULT 1
);

INSERT IGNORE INTO map_definitions VALUES
('downtown',     'Downtown Bloodbath',     'The neon heart of the city — tight alleys, rooftops, and crossfire at every corner.',        30, 'deathmatch,team,territory', 1),
('chinatown',    'Chinatown Massacre',     'Dragon lanterns and bullet casings — close-quarters carnage in the old quarter.',             20, 'deathmatch,team',           1),
('harbour',      'Harbour Front',          'Container yards and shipping docks — long sight lines and ambush chokepoints.',               25, 'deathmatch,team,territory', 3),
('casino',       'The Golden Palace',      'Chips, cash, and chaos — control the casino floor to control the city.',                      20, 'deathmatch,team',           4),
('penthouse',    'Penthouse Showdown',     'Skyscraper rooftop. One way up. Last one standing owns the city.',                            10, 'deathmatch',                5),
('suburbs',      'Suburban Warfare',       'Quiet streets turned war zone — houses, yards, and garages hide friend and foe.',             25, 'deathmatch,team',           2),
('underground',  'Underground Network',    'Subway tunnels — pitch black except for muzzle flash.',                                       20, 'deathmatch,team',           3),
('warehouse',    'Warehouse District',     'Industrial no-man's-land — crates for cover, forklifts for kills.',                           30, 'deathmatch,team,heist',     1),
('federal_bank', 'First Federal Bank',     'The ultimate heist — vault, guards, laser grid. Team required.',                              12, 'heist',                     5),
('casino_vault', 'Casino Vault',           'Under the Golden Palace — crack the vault before the mob arrives.',                           12, 'heist',                     7),
('armoured_car', 'Armoured Car Ambush',    'Hit it on the highway before it reaches the depot. Fast and brutal.',                         8,  'heist',                     4),
('city_hall',    'City Hall Siege',        'Political power through force — hold the building, control the city.',                        25, 'team,territory',            6);

-- ── PHASE 2 ADDITIONS ────────────────────────────────────────

-- Weapon shop catalogue
CREATE TABLE IF NOT EXISTS weapon_shop (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  weapon_id    VARCHAR(50) NOT NULL UNIQUE,
  weapon_name  VARCHAR(100) NOT NULL,
  weapon_type  ENUM('pistol','smg','shotgun','rifle','sniper','explosive','melee','special') NOT NULL,
  price_cash   INT NOT NULL DEFAULT 0,
  damage       INT NOT NULL,
  firerate     INT NOT NULL,
  ammo         INT NOT NULL,
  range_px     INT NOT NULL,
  unlock_rank  INT DEFAULT 1,
  description  TEXT
);

INSERT IGNORE INTO weapon_shop (weapon_id, weapon_name, weapon_type, price_cash, damage, firerate, ammo, range_px, unlock_rank, description) VALUES
('pistol_basic',     'Glock 17',       'pistol',    0,      25,  400,  15,  300, 1,  'Standard issue. Every soldier starts here.'),
('pistol_desert',    'Desert Eagle',   'pistol',    5000,   55,  600,  7,   350, 2,  'High-stopping power. Intimidation included.'),
('smg_micro',        'Micro SMG',      'smg',       8000,   18,  100,  30,  200, 3,  'Spray and pray. Works close up.'),
('smg_mp5',          'MP5',            'smg',       12000,  22,  120,  30,  250, 4,  'Precision automatic. Favoured by professionals.'),
('shotgun_pump',     'Pump Shotgun',   'shotgun',   10000,  80,  800,  8,   100, 3,  'One shot. One very bad day.'),
('shotgun_auto',     'Auto Shotgun',   'shotgun',   18000,  60,  400,  10,  120, 6,  'Shells on shells. Rooms on rooms.'),
('rifle_ak',         'AK-47',          'rifle',     20000,  35,  150,  30,  400, 5,  'The classic. Reliable in any warzone.'),
('rifle_m16',        'M16',            'rifle',     22000,  30,  130,  30,  450, 5,  'Burst fire. Surgical at range.'),
('sniper_basic',     'Sniper Rifle',   'sniper',    35000,  120, 1500, 5,   900, 7,  'One bullet. One body. Cross-map.'),
('explosive_grenade','Grenade',        'explosive', 15000,  150, 2000, 3,   200, 5,  'Area denial. Party ender.'),
('special_minigun',  'Minigun',        'special',   80000,  20,  80,   100, 300, 11, 'Godfather-tier. Hold the trigger.'),
('special_rocket',   'RPG',            'special',   100000, 250, 3000, 2,   600, 13, 'Reserved for the Godfather alone.');

-- Heist events log (per mission)
CREATE TABLE IF NOT EXISTS heist_events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  heist_id   INT NOT NULL,
  user_id    INT NOT NULL,
  event_type ENUM('breach','hack','secure','extract','guard_kill','alarm') NOT NULL,
  ts         DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (heist_id) REFERENCES heist_missions(id) ON DELETE CASCADE
);

-- Territory snapshots (end of each match)
CREATE TABLE IF NOT EXISTS territory_snapshots (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  room_id    INT NOT NULL,
  zone       VARCHAR(20) NOT NULL,
  faction    VARCHAR(20),
  held_for   INT DEFAULT 0,
  snapped_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Weekly faction standings
CREATE TABLE IF NOT EXISTS faction_standings (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  week_start   DATE NOT NULL,
  faction      VARCHAR(20) NOT NULL,
  total_kills  INT DEFAULT 0,
  total_wins   INT DEFAULT 0,
  territory_pts INT DEFAULT 0,
  heists_won   INT DEFAULT 0,
  UNIQUE KEY unique_week_faction (week_start, faction)
);

-- ── PHASE 3 ADDITIONS ─────────────────────────────────────────

-- Season pass
CREATE TABLE IF NOT EXISTS seasons (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  theme       VARCHAR(100),
  starts_at   DATETIME NOT NULL,
  ends_at     DATETIME NOT NULL,
  is_active   TINYINT(1) DEFAULT 0,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS season_tiers (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  season_id    INT NOT NULL,
  tier         INT NOT NULL,
  xp_required  INT NOT NULL,
  free_reward  VARCHAR(200),
  paid_reward  VARCHAR(200),
  reward_type  ENUM('weapon','cash','title','cosmetic') DEFAULT 'cash',
  reward_value VARCHAR(200),
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE,
  UNIQUE KEY unique_season_tier (season_id, tier)
);

CREATE TABLE IF NOT EXISTS player_seasons (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL,
  season_id       INT NOT NULL,
  season_xp       INT DEFAULT 0,
  current_tier    INT DEFAULT 0,
  has_premium     TINYINT(1) DEFAULT 0,
  rewards_claimed JSON,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_season (user_id, season_id)
);

-- Friends
CREATE TABLE IF NOT EXISTS friendships (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  friend_id   INT NOT NULL,
  status      ENUM('pending','accepted','blocked') DEFAULT 'pending',
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)   REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_friendship (user_id, friend_id)
);

-- Push subscriptions (Web Push API)
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL UNIQUE,
  endpoint    TEXT NOT NULL,
  p256dh      TEXT NOT NULL,
  auth        TEXT NOT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Spectators (tracked in memory but log here for analytics)
CREATE TABLE IF NOT EXISTS spectator_sessions (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id   INT NOT NULL,
  room_id   INT NOT NULL,
  joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  left_at   DATETIME DEFAULT NULL
);

-- Seed Season 1
INSERT IGNORE INTO seasons (id, name, theme, starts_at, ends_at, is_active) VALUES
(1, 'Season 1: Blood Streets', 'Urban Warfare', NOW(), DATE_ADD(NOW(), INTERVAL 90 DAY), 1);

INSERT IGNORE INTO season_tiers (season_id, tier, xp_required, free_reward, paid_reward, reward_type, reward_value) VALUES
(1, 1,  0,      '$500 Cash',           'Desert Eagle Pistol',  'weapon', 'pistol_desert'),
(1, 2,  500,    '$1,000 Cash',         '$5,000 Cash',           'cash',   '5000'),
(1, 3,  1500,   'Thug Title',          'Micro SMG',             'weapon', 'smg_micro'),
(1, 4,  3000,   '$2,000 Cash',         '$8,000 Cash',           'cash',   '8000'),
(1, 5,  5500,   '$3,000 Cash',         'Pump Shotgun',          'weapon', 'shotgun_pump'),
(1, 6,  9000,   'Enforcer Title',      '$12,000 Cash',          'cash',   '12000'),
(1, 7,  14000,  '$5,000 Cash',         'AK-47 Rifle',           'weapon', 'rifle_ak'),
(1, 8,  21000,  '$8,000 Cash',         '$20,000 Cash',          'cash',   '20000'),
(1, 9,  30000,  'Underboss Title',     'Sniper Rifle',          'weapon', 'sniper_basic'),
(1, 10, 45000,  '$15,000 Cash',        'SEASON CHAMPION Title', 'title',  'Season Champion');

-- ── PHASE 4 ADDITIONS ─────────────────────────────────────────

-- IP ban list
CREATE TABLE IF NOT EXISTS ip_bans (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  ip_address VARCHAR(45) NOT NULL UNIQUE,
  reason     TEXT,
  banned_by  INT,
  expires_at DATETIME DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ip (ip_address)
);

-- Cosmetics catalogue
CREATE TABLE IF NOT EXISTS cosmetics (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  cosmetic_id  VARCHAR(50) NOT NULL UNIQUE,
  name         VARCHAR(100) NOT NULL,
  type         ENUM('title','badge','kill_effect','profile_bg','faction_emblem') NOT NULL,
  rarity       ENUM('common','rare','epic','legendary') DEFAULT 'common',
  price_cash   INT DEFAULT 0,
  unlock_rank  INT DEFAULT 1,
  season_only  TINYINT(1) DEFAULT 0,
  description  TEXT,
  css_value    VARCHAR(200)
);

INSERT IGNORE INTO cosmetics (cosmetic_id, name, type, rarity, price_cash, unlock_rank, description, css_value) VALUES
('title_thug',        'Thug',              'title',       'common',    0,      2,  'Street level hustle.',             '#9a9590'),
('title_enforcer',    'Enforcer',          'title',       'rare',      0,      4,  'Muscle for hire.',                 '#60a5fa'),
('title_made_man',    'Made Man',          'title',       'rare',      5000,   6,  'Officially in the family.',        '#c9a84c'),
('title_underboss',   'Underboss',         'title',       'epic',      15000,  9,  'Second in command.',               '#c0392b'),
('title_godfather',   'The Godfather',     'title',       'legendary', 50000,  15, 'Ruler of the city.',              '#f97316'),
('title_ghost',       'Ghost',             'title',       'epic',      20000,  7,  'No one knows your face.',          '#9ca3af'),
('badge_heist_king',  'Heist King',        'badge',       'epic',      0,      1,  'Complete 10 heists.',              '🏦'),
('badge_warlord',     'Warlord',           'badge',       'legendary', 0,      1,  'Win 50 matches.',                  '⚔️'),
('badge_season_champ','Season Champion',   'badge',       'legendary', 0,      1,  'Win a season.',                    '👑'),
('kill_fire',         'Fire Kill',         'kill_effect', 'rare',      8000,   5,  'Enemies burst into flame.',        'fire'),
('kill_blood',        'Blood Splatter',    'kill_effect', 'common',    2000,   1,  'Extra blood on kills.',            'blood'),
('kill_skull',        'Skull Pop',         'kill_effect', 'epic',      12000,  8,  'A skull appears on kill.',         'skull'),
('kill_gold',         'Gold Strike',       'kill_effect', 'legendary', 30000,  12, 'Gold explosion on kill.',          'gold'),
('profile_dark',      'Dark City',         'profile_bg',  'common',    1000,   1,  'Dark city skyline background.',    '#0a0a0a'),
('profile_blood',     'Blood Red',         'profile_bg',  'rare',      5000,   4,  'Deep crimson profile background.', '#1a0000'),
('profile_gold',      'Gold Empire',       'profile_bg',  'legendary', 25000,  10, 'Gold empire profile.',             '#1a1200');

-- Player cosmetics inventory
CREATE TABLE IF NOT EXISTS player_cosmetics (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  cosmetic_id  VARCHAR(50) NOT NULL,
  acquired_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_player_cosmetic (user_id, cosmetic_id)
);

-- Equipped cosmetics (one slot per type per user)
CREATE TABLE IF NOT EXISTS equipped_cosmetics (
  user_id      INT NOT NULL,
  slot_type    VARCHAR(50) NOT NULL,
  cosmetic_id  VARCHAR(50) NOT NULL,
  PRIMARY KEY (user_id, slot_type),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Season hall of fame
CREATE TABLE IF NOT EXISTS season_hall_of_fame (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  season_id     INT NOT NULL,
  season_name   VARCHAR(100),
  user_id       INT,
  username      VARCHAR(30),
  faction       VARCHAR(20),
  final_tier    INT,
  total_kills   INT,
  heists_won    INT,
  season_xp     INT,
  rank          INT,
  archived_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Server error log
CREATE TABLE IF NOT EXISTS error_log (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  level      ENUM('info','warn','error','critical') DEFAULT 'error',
  message    TEXT NOT NULL,
  stack      TEXT,
  route      VARCHAR(255),
  user_id    INT DEFAULT NULL,
  ip         VARCHAR(45),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_level (level),
  INDEX idx_created (created_at)
);

-- Request log (sampled — only errors + slow requests)
CREATE TABLE IF NOT EXISTS request_log (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  method      VARCHAR(10),
  path        VARCHAR(255),
  status      INT,
  duration_ms INT,
  ip          VARCHAR(45),
  user_id     INT,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_path (path)
);

-- Admin mass messages
CREATE TABLE IF NOT EXISTS admin_broadcasts (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  admin_id   INT NOT NULL,
  message    TEXT NOT NULL,
  channel    ENUM('global','faction','premium') DEFAULT 'global',
  sent_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);
