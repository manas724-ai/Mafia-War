require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const path       = require('path');
const os         = require('os');

const { pool }              = require('./db/pool');
const { initSocketEngine }  = require('./socket/gameEngine');
const { ipBanMiddleware }   = require('./middleware/ipBan');
const { requestLogger, logError } = require('./middleware/logger');

const authRoutes     = require('./routes/auth');
const playerRoutes   = require('./routes/player');
const gameRoutes     = require('./routes/game');
const paymentRoutes  = require('./routes/payment');
const adminRoutes    = require('./routes/admin');
const shopRoutes     = require('./routes/shop');
const { router: heistRoutes } = require('./routes/heist');
const seasonRoutes   = require('./routes/season');
const seasonAdminRoutes = require('./routes/seasonAdmin');
const friendsRoutes  = require('./routes/friends');
const spectateRoutes = require('./routes/spectate');
const cosmeticsRoutes= require('./routes/cosmetics');
const monitorRoutes  = require('./routes/monitor');

const app    = express();
const server = http.createServer(app);
const PORT   = parseInt(process.env.PORT) || 3110;
const ORIGIN = process.env.FRONTEND_URL || 'https://mafia.nexusonlinegames.com';

// ── SOCKET.IO ─────────────────────────────────────────────────
const io = new Server(server, {
  cors: {
    origin:      [ORIGIN, 'http://localhost:5173', 'http://localhost:3000'],
    methods:     ['GET', 'POST'],
    credentials: true,
  },
  pingTimeout:  60000,
  pingInterval: 25000,
  maxHttpBufferSize: 1e6,
});
initSocketEngine(io);

// ── SECURITY HEADERS ──────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));
app.set('trust proxy', 1); // Trust Cloudflare/Nginx proxy for real IP

// ── CORS ──────────────────────────────────────────────────────
app.use(cors({
  origin:      [ORIGIN, 'http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
  methods:     ['GET','POST','PUT','DELETE','OPTIONS'],
}));

// ── STRIPE WEBHOOK (raw body — before json parser) ────────────
app.use('/api/payment/webhook', express.raw({ type: 'application/json' }));

// ── BODY PARSERS ──────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ── REQUEST LOGGER ────────────────────────────────────────────
app.use(requestLogger);

// ── IP BAN CHECK ──────────────────────────────────────────────
app.use('/api/', ipBanMiddleware);

// ── GLOBAL RATE LIMIT ─────────────────────────────────────────
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max:      500,
  message:  { error: 'Too many requests. Slow down.' },
  skip: (req) => req.path === '/api/health', // don't rate-limit health checks
}));

// ── ROUTES ────────────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/player',       playerRoutes);
app.use('/api/game',         gameRoutes);
app.use('/api/payment',      paymentRoutes);
app.use('/api/admin',        adminRoutes);
app.use('/api/shop',         shopRoutes);
app.use('/api/heist',        heistRoutes);
app.use('/api/season',       seasonRoutes);
app.use('/api/season-admin', seasonAdminRoutes);
app.use('/api/friends',      friendsRoutes);
app.use('/api/spectate',     spectateRoutes);
app.use('/api/cosmetics',    cosmeticsRoutes);
app.use('/api/monitor',      monitorRoutes);

// ── HEALTH CHECK ──────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({
      status: 'ok', game: 'Mafia War', version: '4.0.0',
      port: PORT, db: 'connected', ts: new Date().toISOString(),
      uptime: Math.floor(process.uptime()),
      memory_mb: Math.round(process.memoryUsage().rss / 1024 / 1024),
    });
  } catch (err) {
    res.status(500).json({ status: 'error', db: 'disconnected' });
  }
});

// ── FRONTEND ──────────────────────────────────────────────────
const frontendDist = path.join(__dirname, '../../frontend/dist');
app.use(express.static(frontendDist, {
  maxAge: '1h',
  etag:   true,
}));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  res.sendFile(path.join(frontendDist, 'index.html'));
});

// ── GLOBAL ERROR HANDLER ──────────────────────────────────────
app.use(async (err, req, res, next) => {
  await logError('error', err.message, {
    stack: err.stack, route: req.path,
    userId: req.user?.id, ip: req.ip,
  });
  console.error('[SERVER] Unhandled error:', err.message);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── START SERVER ──────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🔫 MAFIA WAR v4.0 RUNNING`);
  console.log(`   Port:    ${PORT}`);
  console.log(`   Origin:  ${ORIGIN}`);
  console.log(`   Env:     ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Node:    ${process.version}`);
  console.log(`   CPU:     ${os.cpus().length} cores`);
  console.log(`   © 2026 Aussi-Nexus Group\n`);
});

// ── GRACEFUL SHUTDOWN ─────────────────────────────────────────
const shutdown = async (signal) => {
  console.log(`\n[SERVER] ${signal} received — shutting down gracefully...`);
  server.close(async () => {
    await pool.end().catch(() => {});
    console.log('[SERVER] Connections closed. Goodbye.');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10000); // force exit after 10s
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('unhandledRejection', (err) => {
  logError('error', err?.message || String(err), { stack: err?.stack }).catch(() => {});
  console.error('[SERVER] Unhandled rejection:', err);
});
process.on('uncaughtException', (err) => {
  logError('critical', err?.message || String(err), { stack: err?.stack }).catch(() => {});
  console.error('[SERVER] Uncaught exception:', err);
});
