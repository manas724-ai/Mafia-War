import { useState, useEffect, useRef } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { io } from 'socket.io-client';
import { AuthProvider, useAuth } from './context/AuthContext';
import AgeGate        from './pages/AgeGate';
import Auth           from './pages/Auth';
import Lobby          from './pages/Lobby';
import Game           from './pages/Game';
import Admin          from './pages/Admin';
import Legal          from './pages/Legal';
import SeasonPass     from './pages/SeasonPass';
import Friends        from './pages/Friends';
import Spectate       from './pages/Spectate';
import { PaymentSuccess, PaymentCancel } from './pages/Payment';
import Cosmetics from './pages/Cosmetics';
import PWAInstallPrompt  from './components/PWAInstallPrompt';
import FriendInviteToast from './components/FriendInviteToast';

function PrivateRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ minHeight:'100vh', background:'#0a0a0a', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div className="animate-pulse" style={{ fontFamily:'Bebas Neue, sans-serif', fontSize:32, letterSpacing:6, color:'#c0392b' }}>
        LOADING...
      </div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

// Global socket for friend invites (persists across route changes)
function AppWithSocket({ children }) {
  const { user } = useAuth();
  const socketRef = useRef(null);
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    if (!user) { socketRef.current?.disconnect(); setSocket(null); return; }
    const token = localStorage.getItem('mw_access');
    const s = io('/', { auth: { token }, transports: ['websocket'] });
    socketRef.current = s;
    setSocket(s);
    // Admin broadcast toast
    const [adminMsg, setAdminMsg] = React.useState('');
    s.on('admin_broadcast', ({ message, from }) => {
      setAdminMsg(`📢 ${from}: ${message}`);
      setTimeout(() => setAdminMsg(''), 8000);
    });
    s.on('account_banned', ({ reason }) => {
      alert(`Your account has been suspended: ${reason}`);
      localStorage.clear();
      window.location.href = '/';
    });

    return () => s.disconnect();
  }, [user]);

  const [adminMsg, setAdminMsg] = useState('');
  useEffect(() => {
    if (!socketRef.current) return;
    socketRef.current.on('admin_broadcast', ({ message, from }) => {
      setAdminMsg(`📢 ${from}: ${message}`);
      setTimeout(() => setAdminMsg(''), 8000);
    });
  }, [socket]);

  return (
    <>
      {children}
      <FriendInviteToast socket={socket} />
      {adminMsg && (
        <div style={{
          position:'fixed', top:20, left:'50%', transform:'translateX(-50%)',
          background:'#1a0800', border:'1px solid #c9a84c', padding:'12px 24px',
          fontFamily:'Share Tech Mono, monospace', fontSize:13, color:'#c9a84c',
          zIndex:9998, maxWidth:500, textAlign:'center',
          boxShadow:'0 4px 24px rgba(0,0,0,0.6)',
        }}>
          {adminMsg}
          <button onClick={()=>setAdminMsg('')} style={{marginLeft:16,background:'none',border:'none',color:'#555',cursor:'pointer',fontSize:16}}>✕</button>
        </div>
      )}
    </>
  );
}

function AppInner() {
  const [ageOk, setAgeOk] = useState(!!sessionStorage.getItem('mw_age_ok'));
  if (!ageOk) return <AgeGate onConfirm={() => setAgeOk(true)} />;

  return (
    <BrowserRouter>
      <AppWithSocket>
        <PWAInstallPrompt />
        <Routes>
          <Route path="/"                element={<Navigate to="/lobby" replace />} />
          <Route path="/login"           element={<Auth mode="login" />} />
          <Route path="/register"        element={<Auth mode="register" />} />
          <Route path="/terms"           element={<Legal />} />
          <Route path="/payment/success" element={<PaymentSuccess />} />
          <Route path="/payment/cancel"  element={<PaymentCancel />} />

          <Route path="/lobby"    element={<PrivateRoute><Lobby /></PrivateRoute>} />
          <Route path="/game/:code" element={<PrivateRoute><Game /></PrivateRoute>} />
          <Route path="/spectate/:code" element={<PrivateRoute><Spectate /></PrivateRoute>} />
          <Route path="/season"   element={<PrivateRoute><SeasonPass /></PrivateRoute>} />
          <Route path="/friends"  element={<PrivateRoute><Friends /></PrivateRoute>} />
          <Route path="/admin"     element={<PrivateRoute><Admin /></PrivateRoute>} />
          <Route path="/cosmetics" element={<PrivateRoute><Cosmetics /></PrivateRoute>} />

          <Route path="*" element={<Navigate to="/lobby" replace />} />
        </Routes>
      </AppWithSocket>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}
